"""Explicit source-preserving repair attempts, with immutable failure provenance.

No schema relaxation, raw-response edits, automatic dispatch or failure-status
masking. A repaired response is cached as a repair, never as the original call.
"""
from __future__ import annotations
from pathlib import Path
import hashlib,json
from .inventory import load,save,digest,check_sources
from .contextual import validate_context_units,validate_context_section
from .extract import StructureInputBudget


def binding(path):
    path=Path(path).resolve();return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def checked(item):
    path=Path(item['path'])
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:raise ValueError('Repair-chain artifact changed: '+str(path))
    return path


def validator_for(audit_path,inventory_path):
    audit_path=Path(audit_path);audit=load(audit_path);inventory=load(inventory_path);check_sources(inventory);packet=json.loads(audit['messages'][1]['content'])
    from .message_compaction import decode
    packet=decode(packet)
    if packet['inventory_hash']!=inventory['inventory_hash']:raise ValueError('Repair inventory differs from original request')
    bundle_id=packet['context']['context_bundle_id'];home=audit_path.parent.parent.parent.parent;bundle_path=home/'context_bundles'/(bundle_id+'.json');bundle=load(bundle_path)
    if bundle['context_bundle_id']!=bundle_id or digest({k:v for k,v in bundle.items() if k!='context_bundle_id'})!=bundle_id:raise ValueError('Original context bundle changed')
    if audit['purpose'].startswith('structure_v2_unit_observation'):
        validate=lambda value:validate_context_units(value,packet['chunks'],inventory,bundle)
    elif audit['purpose'].startswith('structure_v2_section_observation'):
        validate=lambda value:validate_context_section(value,packet['section'],inventory,packet['unit_machine_states'],packet['child_machine_states'],bundle)
    else:raise ValueError('Explicit repair supports original v2 unit/section validators only')
    return validate,bundle_path,packet


def repair_attempt(failed_attempt_path,inventory_path,client,provider='sonnet',max_input_chars=1000000,validation_details=None):
    failed=Path(failed_attempt_path).resolve();old=load(failed/'audit.json');raw_path=failed/'response.raw.txt'
    if old.get('status')=='verified':raise ValueError('A verified attempt is not a repair target')
    if not raw_path.exists():raise ValueError('No retained model response to repair; do not assume an unknown dispatch returned')
    if not old.get('error'):raise ValueError('Original deterministic validation error is required')
    validate,bundle_path,packet=validator_for(failed/'audit.json',inventory_path)
    cache=failed.parent;attempts=sorted(cache.glob('[0-9][0-9][0-9]'))
    if attempts[-1]!=failed:raise ValueError('Repair the latest failed attempt; previous repair attempts cannot be bypassed')
    raw=raw_path.read_text();expected=[{'chunk_id':c['chunk_id'],'unit_instance_id':c['unit_instance_id']} for c in packet.get('chunks',[])]
    instruction='This is one explicitly authorized repair of the preceding failed response. Return the same original strict JSON contract and preserve all supplied source/scientific content. Fix only the deterministic validation defect; do not add keys, relax requirements, invent source IDs, edit the original quotations or claim human approval.\nValidation error:\n'+old['error']+'\nExpected chunk/source identities (mechanical, not a proposed rewrite):\n'+json.dumps(expected,ensure_ascii=False)
    if validation_details is not None:
        if not isinstance(validation_details,str):raise ValueError('validation_details must be exact diagnostic text')
        instruction+='\nDeterministic validation locations (not proposed replacement wording):\n'+validation_details
    messages=old['messages']+[{'role':'assistant','content':raw},{'role':'user','content':instruction}]
    if sum(len(m['content']) for m in messages)>max_input_chars:raise StructureInputBudget('Complete original+failed-response repair input exceeds explicit budget; no source truncated or dispatch')
    cfg=getattr(client,'config',{}).get('llm',{}).get(provider,{});actual_key=digest({'provider':provider,'model':cfg.get('model'),'max_output_tokens':cfg.get('max_output_tokens'),'messages':messages});attempt=cache/f'{len(attempts)+1:03d}';attempt.mkdir()
    original_key=old.get('original_request_hash',old['request_hash']);audit={'status':'reserved_explicit_repair','repair_kind':'explicit_validation_repair','request_hash':actual_key,'actual_request_hash':actual_key,'actual_messages_hash':digest(messages),'original_request_hash':original_key,'messages':messages,'provider':provider,'model':cfg.get('model'),'max_output_tokens':cfg.get('max_output_tokens'),'purpose':old['purpose'],'validation_details':validation_details,'response_file':str(attempt/'response.raw.txt'),'repair_of':{'attempt':str(failed),'audit':binding(failed/'audit.json'),'raw':binding(raw_path)},'semantic_cache_inheritance':'Original request source/schema scope only; this response was generated from the separately recorded repair messages.'};save(attempt/'audit.json',audit)
    try:
        response=client.complete(provider=provider,messages=messages,task_id='structure-repair:'+actual_key,purpose='structure_v2_explicit_repair:'+actual_key[:12],extract=True,response_format={'type':'json_object'})
        (attempt/'response.raw.txt').write_text(response);save(attempt/'metadata.json',getattr(client,'last_response_metadata',{}))
        if getattr(client,'last_response_metadata',{}).get('finish_reason') in ('length','max_tokens'):raise ValueError('Repair response reported truncation')
        parsed=json.loads(response);verified=validate(parsed);save(attempt/'parsed.json',parsed);save(attempt/'verified.json',verified)
        audit['status']='verified';save(attempt/'audit.json',audit)
        manifest={'schema':'structure-explicit-repair-1','status':'verified','original_request_hash':original_key,'actual_request_hash':actual_key,'actual_messages_hash':digest(messages),'failed_attempt':audit['repair_of'],'successful_attempt':str(attempt),'inventory':binding(inventory_path),'context_bundle':binding(bundle_path),'audit':binding(attempt/'audit.json'),'raw':binding(attempt/'response.raw.txt'),'parsed':binding(attempt/'parsed.json'),'verified':binding(attempt/'verified.json'),'metadata':binding(attempt/'metadata.json'),'schema_relaxed':False,'original_failure_modified':False,'human_approval':'pending'};save(attempt/'repair_manifest.json',manifest);return manifest
    except Exception as exc:
        audit.update(status='invalid_response' if (attempt/'response.raw.txt').exists() else 'failed',error_type=type(exc).__name__,error=str(exc));save(attempt/'audit.json',audit);raise


def verify_repair_chain(cache_folder,inventory_path):
    """Runner resume gate. Revalidate response, source, exact repair messages and every failure link."""
    cache=Path(cache_folder).resolve();attempts=sorted(cache.glob('[0-9][0-9][0-9]'))
    if not attempts:raise ValueError('No cached attempts')
    latest=attempts[-1];audit=load(latest/'audit.json')
    if audit.get('status')!='verified':raise ValueError('Latest cached request has no verified response')
    failed={str(p) for p in attempts[:-1] if load(p/'audit.json').get('status')!='verified'};covered=[];cursor=latest
    if not failed:return {'status':'verified_original','cache_folder':str(cache),'covered_failed_attempts':[]}
    visited=set()
    while load(cursor/'audit.json').get('repair_kind')=='explicit_validation_repair':
        if str(cursor) in visited:raise ValueError('Cyclic repair chain')
        visited.add(str(cursor));current=load(cursor/'audit.json')
        if current.get('status')=='verified':
            manifest=load(cursor/'repair_manifest.json')
            if manifest.get('schema')!='structure-explicit-repair-1' or manifest.get('status')!='verified':raise ValueError('Invalid explicit repair manifest')
            for key in ('inventory','context_bundle','audit','raw','parsed','verified','metadata'):checked(manifest[key])
            if Path(manifest['inventory']['path']).resolve()!=Path(inventory_path).resolve():raise ValueError('Repair inventory path changed')
            previous_binding=manifest['failed_attempt']
        else:
            # A failed repair remains failed. Its child already pinned its audit/raw;
            # follow its own immutable repair_of link without inventing a success.
            previous_binding=current.get('repair_of')
            if not previous_binding:raise ValueError('Incomplete failed-repair chain')
        previous=Path(previous_binding['attempt']).resolve()
        if previous.parent!=cache or int(previous.name)>=int(cursor.name):raise ValueError('Repair chain points outside/forward in its original cache')
        checked(previous_binding['audit']);checked(previous_binding['raw'])
        previous_audit=load(previous/'audit.json');messages=current['messages']
        if messages[:-2]!=previous_audit['messages'] or messages[-2]!={'role':'assistant','content':(previous/'response.raw.txt').read_text()} or previous_audit.get('error','') not in messages[-1]['content']:raise ValueError('Repair did not preserve original complete messages/raw/error chain')
        actual=digest({'provider':current['provider'],'model':current['model'],'max_output_tokens':current['max_output_tokens'],'messages':messages})
        if current.get('actual_request_hash')!=actual or current.get('actual_messages_hash')!=digest(messages):raise ValueError('Actual repair request/message hash changed')
        if current.get('status')=='verified':
            if manifest['actual_request_hash']!=actual or manifest['actual_messages_hash']!=digest(messages):raise ValueError('Repair manifest message binding changed')
            validate,_,_=validator_for(previous/'audit.json',inventory_path);raw=(cursor/'response.raw.txt').read_text();parsed=json.loads(raw)
            if parsed!=load(cursor/'parsed.json') or validate(parsed)!=load(cursor/'verified.json'):raise ValueError('Repaired response no longer passes the original validator')
        covered.append(str(previous));cursor=previous
    if not failed<=set(covered):raise ValueError('Failed attempts remain without an explicit verified repair chain')
    return {'status':'verified_repair','cache_folder':str(cache),'repair_manifest':str(latest/'repair_manifest.json'),'original_request_hash':load(latest/'repair_manifest.json')['original_request_hash'],'covered_failed_attempts':covered,'human_approval':'pending'}
