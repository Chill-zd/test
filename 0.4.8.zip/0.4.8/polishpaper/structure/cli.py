"""Separate commands for the new source-structure layer; legacy pipeline is unchanged."""
from __future__ import annotations
import copy,importlib,json
from pathlib import Path
import click,yaml
from .inventory import build,save,load,select,check_sources,digest


def runtime():
    from .. import cli
    return cli

def inventories(directory):
    directory=Path(directory);files=sorted(directory.glob('*.json'))
    if not files:raise click.ClickException('No structure inventories; run structure inventory first')
    result=[load(p) for p in files]
    for inventory in result:check_sources(inventory)
    return result

def defaults(inventory_dir,analysis_dir):
    data=runtime().DATA/'structure'
    return Path(inventory_dir or data/'inventory'),Path(analysis_dir or data/'analyses')

def choose_inventory(directory,paper):
    matches=[i for i in inventories(directory) if i['paper_id']==paper]
    if len(matches)!=1:raise click.ClickException('Expected one inventory for paper '+paper)
    return matches[0]

@click.group('structure')
def structure_group():
    """Inspect/analyze real sections, audit phrase coverage and prepare human review."""

@structure_group.command('inventory')
@click.option('--paper')
@click.option('--output-dir',type=click.Path(path_type=Path))
def inventory_cmd(paper,output_dir):
    output_dir=output_dir or runtime().DATA/'structure/inventory';results=[]
    for folder in runtime().corpus_roots():
        if paper and folder.name!=paper:continue
        meta=yaml.safe_load((folder/'meta.yaml').read_text()) if (folder/'meta.yaml').exists() else load(folder/'metadata.json')
        inventory=build(folder/meta['main'],meta['paper_id'],folder,meta);path=output_dir/(meta['paper_id']+'.json')
        if path.exists():
            old=load(path)
            if old['inventory_hash']!=inventory['inventory_hash']:save(output_dir/'_history'/meta['paper_id']/(old['inventory_hash']+'.json'),old)
        save(path,inventory);results.append({'paper_id':meta['paper_id'],'inventory_hash':inventory['inventory_hash'],'actual_sections':sum(s['kind']=='actual_section' for s in inventory['sections']),'units':len(inventory['units']),'path':str(path)})
    if not results:raise click.ClickException('No matching ready corpus paper')
    click.echo(json.dumps(results,ensure_ascii=False,indent=2))

def selection_options(function):
    options=[click.option('--paper',required=True),click.option('--section','selector',required=True,help='Exact full section path (e.g. Introduction/Background) or section_id.'),click.option('--inventory-dir',type=click.Path(path_type=Path)),click.option('--max-chunk-chars',type=click.IntRange(200),default=6000,show_default=True),click.option('--max-batch-chars',type=click.IntRange(200),default=12000,show_default=True),click.option('--max-batch-units',type=click.IntRange(1),default=1,show_default=True),click.option('--recursive/--no-recursive',default=True,show_default=True)]
    for option in reversed(options):function=option(function)
    return function

@structure_group.command('plan')
@selection_options
def plan_cmd(paper,selector,inventory_dir,max_chunk_chars,max_batch_chars,max_batch_units,recursive):
    from .extract import plan
    directory,_=defaults(inventory_dir,None);inventory=choose_inventory(directory,paper);section=select(inventory,selector);byid={s['section_id']:s for s in inventory['sections']};plans=[]
    def visit(node):
        if recursive:
            for child in node['children']:visit(byid[child])
        p=plan(inventory,node,max_chunk_chars,max_batch_chars,max_batch_units);plans.append({k:v for k,v in p.items() if k!='batches'})
    visit(section);click.echo(json.dumps({'paper_id':paper,'inventory_hash':inventory['inventory_hash'],'plans':plans,'planned_calls':sum(p['planned_unit_calls']+p['planned_synthesis_calls'] for p in plans),'model_calls_dispatched':0},ensure_ascii=False,indent=2))

@structure_group.command('analyze')
@selection_options
@click.option('--analysis-dir',type=click.Path(path_type=Path))
@click.option('--provider',type=click.Choice(['sonnet','gpt']),default='sonnet',show_default=True)
@click.option('--max-output-tokens',type=click.IntRange(1))
@click.option('--max-synthesis-chars',type=click.IntRange(1),default=200000,show_default=True)
@click.option('--retry-failed',is_flag=True,help='Explicitly authorize one new attempt for a retained failed request; no automatic failure retry.')
@click.option('--client-factory',help='Explicit trusted local module:function(config, ledger) returning a client; optional provider adapter.')
def analyze_cmd(paper,selector,inventory_dir,max_chunk_chars,max_batch_chars,max_batch_units,recursive,analysis_dir,provider,max_output_tokens,max_synthesis_chars,retry_failed,client_factory):
    from .extract import run
    from ..llm.client import LLMClient
    from ..llm.ledger import Ledger
    from ..llm.host_bridge import PendingHostCall
    invdir,analysis_dir=defaults(inventory_dir,analysis_dir);inventory=choose_inventory(invdir,paper);section=select(inventory,selector);config=copy.deepcopy(runtime().cfg());config['llm']['retry']=0
    if max_output_tokens is not None:config['llm'][provider]['max_output_tokens']=max_output_tokens
    ledger=Ledger(runtime().DATA/'ledger.sqlite')
    if client_factory:
        module,name=client_factory.rsplit(':',1);client=getattr(importlib.import_module(module),name)(config,ledger)
    else:client=LLMClient(config,ledger)
    parameters={'paper':paper,'section_id':section['section_id'],'inventory_hash':inventory['inventory_hash'],'provider':provider,'model':config['llm'][provider]['model'],'max_output_tokens':config['llm'][provider]['max_output_tokens'],'max_chunk_chars':max_chunk_chars,'max_batch_chars':max_batch_chars,'max_batch_units':max_batch_units,'max_synthesis_chars':max_synthesis_chars,'recursive':recursive,'retry_failed':retry_failed,'client_factory':client_factory,'network_retries':0}
    save(runtime().DATA/'structure/run_parameters'/(digest(parameters)+'.json'),parameters)
    try:result=run(inventory,section,client,analysis_dir/paper,provider,max_chunk_chars,max_batch_chars,max_synthesis_chars,recursive,retry_failed,max_batch_units)
    except (PendingHostCall,ValueError,RuntimeError) as exc:raise click.ClickException(str(exc))
    click.echo(json.dumps({'section_id':result['section_id'],'status':result['status'],'review_status':'machine_proposed','semantic_status':'pending_human','analysis_dir':str(analysis_dir/paper),'source_truncated':False},ensure_ascii=False,indent=2))

@structure_group.command('coverage')
@click.option('--inventory-dir',type=click.Path(path_type=Path))
@click.option('--analysis-dir',type=click.Path(path_type=Path))
@click.option('--output-dir',type=click.Path(path_type=Path))
def coverage_cmd(inventory_dir,analysis_dir,output_dir):
    from .review import coverage
    invdir,analysis_dir=defaults(inventory_dir,analysis_dir);result=coverage(inventories(invdir),analysis_dir,output_dir or runtime().DATA/'structure/coverage');click.echo(json.dumps(result['summary'],ensure_ascii=False,indent=2))

@structure_group.command('review-pack')
@click.option('--inventory-dir',type=click.Path(path_type=Path))
@click.option('--analysis-dir',type=click.Path(path_type=Path))
@click.option('--output-dir',type=click.Path(path_type=Path))
@click.option('--target-author')
@click.option('--phrase-audit',type=click.Path(exists=True,path_type=Path))
def review_cmd(inventory_dir,analysis_dir,output_dir,target_author,phrase_audit):
    from .review import review_pack
    invdir,analysis_dir=defaults(inventory_dir,analysis_dir);candidate=runtime().DATA/'structure/phrase_coverage/report.json'
    phrase_audit=phrase_audit or (candidate if candidate.exists() else None)
    click.echo(json.dumps(review_pack(inventories(invdir),analysis_dir,output_dir or runtime().DATA/'structure/review_packet',target_author,phrase_audit),ensure_ascii=False,indent=2))

@structure_group.command('audit-phrases')
@click.option('--raw-dir','raw_dirs',multiple=True,type=click.Path(exists=True,file_okay=False,path_type=Path))
@click.option('--inventory-dir',type=click.Path(path_type=Path))
@click.option('--output-dir',type=click.Path(path_type=Path))
@click.option('--target-author')
@click.option('--canonical-lexicon',type=click.Path(path_type=Path))
def audit_cmd(raw_dirs,inventory_dir,output_dir,target_author,canonical_lexicon):
    from .phrase_audit import audit
    invdir,_=defaults(inventory_dir,None);result=audit(list(raw_dirs) or [runtime().DATA/'knowledge/_raw'],inventories= inventories(invdir),output_dir=output_dir or runtime().DATA/'structure/phrase_coverage',target_author=target_author,canonical_shared_path=canonical_lexicon or runtime().DATA/'knowledge/lexicon.yaml');click.echo(json.dumps(result['summary'],ensure_ascii=False,indent=2))


@structure_group.command('stage-lexicon')
@click.option('--raw-dir','raw_dirs',multiple=True,required=True,type=click.Path(exists=True,file_okay=False,path_type=Path))
@click.option('--inventory-dir',type=click.Path(path_type=Path))
@click.option('--active-lexicon',type=click.Path(path_type=Path))
@click.option('--stage-dir',required=True,type=click.Path(path_type=Path))
@click.option('--target-group-author',required=True)
@click.option('--selection-policy',type=click.Choice(['shared_only','all_target_candidates']),default='shared_only',show_default=True)
def stage_lexicon_cmd(raw_dirs,inventory_dir,active_lexicon,stage_dir,target_group_author,selection_policy):
    from .lexicon_admission import stage
    invdir,_=defaults(inventory_dir,None)
    click.echo(json.dumps(stage(list(raw_dirs),inventories(invdir),active_lexicon or runtime().DATA/'knowledge/lexicon.yaml',stage_dir,target_group_author,selection_policy=selection_policy),ensure_ascii=False,indent=2))


@structure_group.command('activate-lexicon')
@click.option('--manifest',required=True,type=click.Path(exists=True,path_type=Path))
def activate_lexicon_cmd(manifest):
    from .lexicon_admission import activate
    click.echo(json.dumps(activate(manifest),ensure_ascii=False,indent=2))


@structure_group.command('rollback-lexicon')
@click.option('--manifest',required=True,type=click.Path(exists=True,path_type=Path))
def rollback_lexicon_cmd(manifest):
    from .lexicon_admission import rollback
    click.echo(json.dumps(rollback(manifest),ensure_ascii=False,indent=2))


@structure_group.command('stage-registry')
@click.option('--entries',required=True,type=click.Path(exists=True,path_type=Path),help='JSON list of exact analysis_path, inventory_path and explicit applicability concepts.')
@click.option('--output',required=True,type=click.Path(path_type=Path))
@click.option('--target-author',default='Wolfram Wiesemann')
def stage_registry_cmd(entries,output,target_author):
    from .delivery import stage_registry
    click.echo(json.dumps(stage_registry(load(entries),output,target_author),ensure_ascii=False,indent=2))


@structure_group.command('publish-registry')
@click.option('--staged',required=True,type=click.Path(exists=True,path_type=Path))
@click.option('--human-decisions',type=click.Path(exists=True,path_type=Path))
def publish_registry_cmd(staged,human_decisions):
    from .delivery import publish_registry
    click.echo(json.dumps(publish_registry(staged,runtime().DATA/'knowledge',human_decisions),ensure_ascii=False,indent=2))


def contextual_client(provider,max_output_tokens,client_factory):
    from ..llm.client import LLMClient
    from ..llm.ledger import Ledger
    config=copy.deepcopy(runtime().cfg());config['llm']['retry']=0
    if max_output_tokens is not None:config['llm'][provider]['max_output_tokens']=max_output_tokens
    ledger=Ledger(runtime().DATA/'ledger.sqlite')
    if client_factory:
        module,name=client_factory.rsplit(':',1);return getattr(importlib.import_module(module),name)(config,ledger)
    return LLMClient(config,ledger)


@structure_group.command('inventory-v2')
@click.option('--inventory-dir',type=click.Path(exists=True,path_type=Path))
@click.option('--output-dir',type=click.Path(path_type=Path))
def inventory_v2_cmd(inventory_dir,output_dir):
    from .context_sources import augment_inventory
    base,_=defaults(inventory_dir,None);destination=output_dir or runtime().DATA/'structure/context_v2/inventory';results=[]
    for original in inventories(base):
        result=augment_inventory(original);path=destination/(result['paper_id']+'.json')
        if path.exists() and load(path)!=result:raise click.ClickException('Refusing to replace a different v2 inventory; choose a new output directory')
        save(path,result);results.append({'paper_id':result['paper_id'],'inventory_hash':result['inventory_hash'],'objects':len(result['objects']),'path':str(path)})
    click.echo(json.dumps(results,ensure_ascii=False,indent=2))


@structure_group.command('context-plan')
@click.option('--paper',required=True)
@click.option('--inventory-dir',type=click.Path(path_type=Path))
@click.option('--max-input-chars',type=click.IntRange(1),default=1000000)
def context_plan_cmd(paper,inventory_dir,max_input_chars):
    from .context import prepare_scan
    invdir=inventory_dir or runtime().DATA/'structure/context_v2/inventory';prepared=prepare_scan(choose_inventory(invdir,paper),max_input_chars)
    click.echo(json.dumps({k:v for k,v in prepared.items() if k!='messages'},ensure_ascii=False,indent=2))


@structure_group.command('context-scan')
@click.option('--paper',required=True)
@click.option('--inventory-dir',type=click.Path(path_type=Path))
@click.option('--context-dir',type=click.Path(path_type=Path))
@click.option('--provider',type=click.Choice(['sonnet','gpt']),default='sonnet')
@click.option('--max-output-tokens',type=click.IntRange(1),default=16384)
@click.option('--max-input-chars',type=click.IntRange(1),default=1000000)
@click.option('--retry-failed',is_flag=True)
@click.option('--client-factory')
def context_scan_cmd(paper,inventory_dir,context_dir,provider,max_output_tokens,max_input_chars,retry_failed,client_factory):
    from .context import scan
    invdir=inventory_dir or runtime().DATA/'structure/context_v2/inventory';out=context_dir or runtime().DATA/'structure/context_v2/context';client=contextual_client(provider,max_output_tokens,client_factory)
    result=scan(choose_inventory(invdir,paper),client,out/paper,provider,max_input_chars,retry_failed=retry_failed)
    click.echo(json.dumps({'paper_id':paper,'scan_id':result['scan_id'],'entries':len(result['entries']),'summaries':len(result['section_summaries']),'coverage':result['coverage'],'semantic_status':result['semantic_status'],'ledger':str(out/paper/'source_ledger.json')},ensure_ascii=False,indent=2))


@structure_group.command('analyze-v2')
@selection_options
@click.option('--analysis-dir',type=click.Path(path_type=Path))
@click.option('--source-ledger',required=True,type=click.Path(exists=True,path_type=Path))
@click.option('--provider',type=click.Choice(['sonnet','gpt']),default='sonnet')
@click.option('--max-output-tokens',type=click.IntRange(1),default=16384)
@click.option('--max-input-chars',type=click.IntRange(1),default=1000000)
@click.option('--neighbor-count',type=click.IntRange(0,2),default=1)
@click.option('--retry-failed',is_flag=True)
@click.option('--client-factory')
def analyze_v2_cmd(paper,selector,inventory_dir,max_chunk_chars,max_batch_chars,max_batch_units,recursive,analysis_dir,source_ledger,provider,max_output_tokens,max_input_chars,neighbor_count,retry_failed,client_factory):
    from .contextual import run
    invdir=inventory_dir or runtime().DATA/'structure/context_v2/inventory';inventory=choose_inventory(invdir,paper);section=select(inventory,selector);out=analysis_dir or runtime().DATA/'structure/context_v2/analyses';client=contextual_client(provider,max_output_tokens,client_factory)
    result=run(inventory,section,client,out/paper,source_ledger,provider,max_chunk_chars,max_batch_chars,max_input_chars,recursive,retry_failed,max_batch_units,neighbor_count)
    click.echo(json.dumps({'section_id':result['section_id'],'status':result['status'],'review_status':'machine_proposed','semantic_status':'pending_human','context_version':2,'analysis_dir':str(out/paper)},ensure_ascii=False,indent=2))


@structure_group.command('repair-v2')
@click.option('--failed-attempt',required=True,type=click.Path(exists=True,file_okay=False,path_type=Path))
@click.option('--inventory',required=True,type=click.Path(exists=True,path_type=Path))
@click.option('--provider',type=click.Choice(['sonnet','gpt']),default='sonnet')
@click.option('--max-output-tokens',type=click.IntRange(1),default=16384)
@click.option('--max-input-chars',type=click.IntRange(1),default=1000000)
@click.option('--client-factory')
def repair_v2_cmd(failed_attempt,inventory,provider,max_output_tokens,max_input_chars,client_factory):
    from .repair import repair_attempt
    client=contextual_client(provider,max_output_tokens,client_factory)
    click.echo(json.dumps(repair_attempt(failed_attempt,inventory,client,provider,max_input_chars),ensure_ascii=False,indent=2))
