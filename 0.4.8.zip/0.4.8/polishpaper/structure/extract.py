"""Budgeted unit observation then whole-real-section synthesis, on a separate ledger path."""
from __future__ import annotations
import json
from pathlib import Path
from .inventory import digest,save,load,public_unit,chunk_unit,section_key,check_sources
from .contracts import UNIT_SCHEMA,SECTION_SCHEMA,validate_units,validate_section
from ..llm.host_bridge import PendingHostCall

PROMPTS=Path(__file__).parents[1]/'prompts'
class StoredStructureFailure(RuntimeError):pass
class StructureInputBudget(RuntimeError):pass

def plan(inventory,section,max_chunk_chars=6000,max_batch_chars=12000,max_batch_units=1):
    if max_chunk_chars<200 or max_batch_chars<max_chunk_chars:raise ValueError('Chunk budget must be >=200 and batch budget >=chunk budget')
    batches=[];batch=[];size=0;metadata=[]
    for item in section['direct_items']:
        if item['kind']=='child_section':
            if batch:batches.append(batch);batch=[];size=0
            continue
        unit=inventory['units'][item['item_id']]
        if unit['content_kind']=='source_metadata':metadata.append(item['item_id']);continue
        for chunk in chunk_unit(unit,max_chunk_chars):
            if batch and (size+len(chunk['text'])>max_batch_chars or (max_batch_units and chunk['unit_instance_id'] not in {c['unit_instance_id'] for c in batch} and len({c['unit_instance_id'] for c in batch})>=max_batch_units)):batches.append(batch);batch=[];size=0
            batch.append(chunk);size+=len(chunk['text'])
    if batch:batches.append(batch)
    return {'section_id':section['section_id'],'batches':batches,'unit_instances':[i['item_id'] for i in section['direct_items'] if i['kind']=='unit'],'direct_items':section['direct_items'],'child_sections':section['children'],'full_source_chars':sum(len(inventory['units'][uid]['prose_text']) for uid in section['all_unit_instances']),'planned_unit_calls':len(batches),'planned_synthesis_calls':1 if section['all_unit_instances'] else 0,'budget_chunk_chars':max_chunk_chars,'budget_batch_chars':max_batch_chars,'max_batch_units':max_batch_units,'metadata_units':metadata,'budget_meaning':'Chunk/batch output-analysis granularity; complete source-unit context is additionally supplied and measured. No source is truncated.','limitations':inventory['limitations']}

def prompt_messages(prompt_name,packet,schema):
    return [{'role':'system','content':(PROMPTS/prompt_name).read_text()},{'role':'user','content':json.dumps({**packet,'output_json_schema':schema},ensure_ascii=False)}]

def cached_call(client,provider,messages,directory,purpose,validator,retry_failed=False):
    cfg=getattr(client,'config',{}).get('llm',{}).get(provider,{})
    key=digest({'provider':provider,'model':cfg.get('model'),'max_output_tokens':cfg.get('max_output_tokens'),'messages':messages})
    folder=Path(directory)/'requests'/key;folder.mkdir(parents=True,exist_ok=True)
    attempts=sorted(folder.glob('[0-9][0-9][0-9]'))
    if attempts:
        latest=attempts[-1];audit=load(latest/'audit.json')
        if audit['status']=='verified':return validator(load(latest/'parsed.json'))
        if audit['status']=='pending_host':attempt=latest
        elif not retry_failed:raise StoredStructureFailure('Stored failed attempt retained; no automatic retry: '+str(latest))
        else:attempt=folder/f'{len(attempts)+1:03d}';attempt.mkdir()
    else:attempt=folder/'001';attempt.mkdir()
    audit={'status':'reserved','request_hash':key,'provider':provider,'model':cfg.get('model'),'messages':messages,'purpose':purpose,'response_file':str(attempt/'response.raw.txt')};save(attempt/'audit.json',audit)
    try:
        raw=client.complete(provider=provider,messages=messages,task_id='structure:'+key,purpose=purpose+':'+key[:12]+':attempt:'+attempt.name,extract=True,response_format={'type':'json_object'})
    except PendingHostCall:
        audit['status']='pending_host';save(attempt/'audit.json',audit);raise
    except Exception as exc:
        audit.update(status='failed',error_type=type(exc).__name__);save(attempt/'audit.json',audit);raise
    (attempt/'response.raw.txt').write_text(raw)
    metadata=getattr(client,'last_response_metadata',{});save(attempt/'metadata.json',metadata)
    try:
        if metadata.get('finish_reason') in ('length','max_tokens'):raise StoredStructureFailure('Provider reported truncation; raw response retained')
        parsed=json.loads(raw);verified=validator(parsed);save(attempt/'parsed.json',parsed);save(attempt/'verified.json',verified)
        audit['status']='verified';save(attempt/'audit.json',audit)
        return verified
    except Exception as exc:
        audit.update(status='invalid_response',error_type=type(exc).__name__,error=str(exc));save(attempt/'audit.json',audit);raise

def context_windows(inventory,chunks,max_chars=1000):
    ordered=list(inventory['units']);selected={c['unit_instance_id'] for c in chunks};windows=[]
    for uid in selected:
        at=ordered.index(uid)
        for delta in (-1,1):
            if not 0<=at+delta<len(ordered):continue
            other=ordered[at+delta]
            if other in selected or any(w['unit_instance_id']==other for w in windows):continue
            unit=inventory['units'][other];text=unit['prose_text'];start=max(0,len(text)-max_chars) if delta<0 else 0;end=min(len(text),start+max_chars)
            windows.append({'unit_instance_id':other,'start':start,'end':end,'text':text[start:end],'content_kind':unit['content_kind'],'context_is_complete_unit':start==0 and end==len(text)})
    return windows

def run(inventory,section,client,directory,provider='sonnet',max_chunk_chars=6000,max_batch_chars=12000,max_synthesis_chars=200000,recursive=True,retry_failed=False,max_batch_units=1):
    check_sources(inventory);directory=Path(directory);byid={s['section_id']:s for s in inventory['sections']};child_results={}
    for child in section['children']:
        if recursive:child_results[child]=run(inventory,byid[child],client,directory,provider,max_chunk_chars,max_batch_chars,max_synthesis_chars,recursive,retry_failed,max_batch_units)
    home=directory/section_key(section);home.mkdir(parents=True,exist_ok=True);planned=plan(inventory,section,max_chunk_chars,max_batch_chars,max_batch_units);save(home/'plan.json',planned)
    if not section['all_unit_instances']:
        result={'section_id':section['section_id'],'inventory_hash':inventory['inventory_hash'],'status':'skipped','review_status':'machine_proposed','semantic_status':'pending_human','reason':'Actual section contains no source units','units':[],'section_observation':None};save(home/'analysis.json',result);return result
    from .contracts import bind_quote
    records=[]
    for uid in planned['metadata_units']:
        unit=inventory['units'][uid];text=unit['prose_text'];start=len(text)-len(text.lstrip());end=len(text.rstrip());quote=bind_quote({'unit_instance_id':uid,'text':text[start:end],'start':start,'end':end},inventory,{uid})
        records.append({'chunk_id':uid+':metadata','unit_instance_id':uid,'status':'skipped','reading_task':{'observation':'Not applicable: pure source label anchor, not a natural paragraph.','reader_before':'not applicable','reader_after':'not applicable','evidence':[quote]},'segments':[],'context_links':{k:{'observation':'not applicable: source metadata','evidence':[]} for k in ('incoming','outgoing')},'scientific_slots':[{'kind':'reference_anchor','evidence':quote,'preserve':'Preserve the original label identifier exactly.'}],'limitations':['Pure label metadata; mechanically accounted, not rhetorically analyzed.'],'reason':'Pure label anchor: excluded from natural-paragraph analysis.','analysis_origin':'deterministic_source_metadata'})
    for batch_no,chunks in enumerate(planned['batches'],1):
        windows=context_windows(inventory,chunks);allowed={c['unit_instance_id'] for c in chunks}|{w['unit_instance_id'] for w in windows}
        source_metadata=[]
        for uid in dict.fromkeys(c['unit_instance_id'] for c in chunks):
            public=public_unit(inventory['units'][uid]);public.pop('prose_text');source_metadata.append(public)
        packet={'inventory_hash':inventory['inventory_hash'],'paper_id':inventory['paper_id'],'authorship':inventory['metadata'],'section':{k:section[k] for k in ('section_id','title','section_path','section_type')},'source_units_metadata':source_metadata,'complete_unit_contexts':[public_unit(inventory['units'][uid]) for uid in dict.fromkeys(c['unit_instance_id'] for c in chunks)],'chunks':chunks,'context_windows':windows,'effective_budgets':{k:planned[k] for k in ('budget_chunk_chars','budget_batch_chars','max_batch_units')}}
        messages=prompt_messages('paragraph_observe.md',packet,UNIT_SCHEMA)
        if sum(len(m['content']) for m in messages)>max_synthesis_chars:raise StructureInputBudget('Complete unit/context request exceeds explicit input budget; no text truncated or model call dispatched')
        result=cached_call(client,provider,messages,home,'structure_unit_observation',lambda value:validate_units(value,chunks,inventory,allowed),retry_failed)
        records.extend(result['records']);save(home/f'batch_{batch_no:03d}.json',{'inventory_hash':inventory['inventory_hash'],'records':result['records'],'semantic_status':'pending_human'})
    records.sort(key=lambda r:(inventory['units'][r['unit_instance_id']]['logical_order'],next((s['quote']['start'] for s in r['segments']),0)))
    unit_states={}
    for uid in planned['unit_instances']:
        statuses=[r['status'] for r in records if r['unit_instance_id']==uid]
        unit_states[uid]='analyzed' if statuses and all(s=='analyzed' for s in statuses) else 'partial' if any(s in ('analyzed','partial') for s in statuses) else statuses[0] if statuses else 'unresolved'
    child_states={cid:child_results[cid]['status'] if cid in child_results else 'unresolved' for cid in section['children']}
    packet={'inventory_hash':inventory['inventory_hash'],'paper_id':inventory['paper_id'],'authorship':inventory['metadata'],'section':section,'full_source_units':[public_unit(inventory['units'][uid]) for uid in section['all_unit_instances']],'verified_chunk_observations':records,'unit_machine_states':unit_states,'child_section_observations':child_results,'child_machine_states':child_states,'effective_budgets':{k:planned[k] for k in ('budget_chunk_chars','budget_batch_chars','max_batch_units')},'scope_warning':'Whole source is supplied. Source-specific judgments are pending human review; no universal sequence or author habit is established.'}
    messages=prompt_messages('section_observe.md',packet,SECTION_SCHEMA);input_chars=sum(len(m['content']) for m in messages)
    if input_chars>max_synthesis_chars:
        save(home/'pending_input_budget.json',{'status':'pending_input_budget','section_id':section['section_id'],'inventory_hash':inventory['inventory_hash'],'complete_input_chars':input_chars,'configured_limit':max_synthesis_chars,'source_truncated':False,'action':'Raise the explicit budget or design a separately reviewed complete hierarchical synthesis; no source was omitted and no synthesis call was dispatched.'})
        raise StructureInputBudget(f'Complete section input {input_chars} exceeds explicit budget {max_synthesis_chars}; source not truncated')
    observation=cached_call(client,provider,messages,home,'structure_section_observation',lambda value:validate_section(value,section,inventory,unit_states,child_states),retry_failed)
    result={'section_id':section['section_id'],'inventory_hash':inventory['inventory_hash'],'status':observation['status'],'review_status':'machine_proposed','semantic_status':'pending_human','units':records,'unit_states':unit_states,'child_states':child_states,'section_observation':observation,'complete_synthesis_input_chars':input_chars,'complete_source_supplied':True};save(home/'analysis.json',result);return result
