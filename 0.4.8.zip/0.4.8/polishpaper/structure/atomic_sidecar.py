"""Mechanical atomic-source coverage beside immutable, partial model analysis.

This does not complete a functional fragment map, verify scientific claims, or
approve a model judgment. Raw text is exclusively a human/audit artifact.
"""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import hashlib,json,re
from pylatexenc.latexwalker import LatexWalker
from ..corpus.parser import strip_comments
from .inventory import load,save,digest,check_sources
from .contracts import bind_quote


def binding(path):
    path=Path(path).resolve()
    return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def checked(item):
    p=Path(item['path']).resolve()
    if not p.is_file() or binding(p)['sha256']!=item['sha256']:raise ValueError('Atomic sidecar dependency changed: '+str(p))
    return p


def _sha(text):return hashlib.sha256(text.encode()).hexdigest()


def _view(inv):return {**inv,'units':{**inv['units'],**inv.get('objects',{})}}


def _quote(inv,uid,start,end):
    unit=_view(inv)['units'][uid]
    return bind_quote({'unit_instance_id':uid,'text':unit['prose_text'][start:end],'start':start,'end':end},_view(inv),{uid})


def _check_object(inv,obj):
    if obj.get('complete') is not True or obj.get('status')!='complete':raise ValueError('Atomic sidecar requires an existing complete static envelope')
    path=Path(inv['root'])/obj['file']
    with path.open(encoding='utf8',newline='') as handle:raw=handle.read()
    start,end=obj['offset_start'],obj['offset_end'];text=raw[start:end];prose=strip_comments(raw)[start:end]
    if text!=obj['text'] or _sha(text)!=obj['sha256'] or prose!=obj['prose_text'] or _sha(prose)!=obj['prose_sha256']:raise ValueError('Atomic envelope differs from exact physical source')
    if obj['line_start']!=raw.count('\n',0,start)+1 or obj['line_end']!=raw.count('\n',0,end-1)+1:raise ValueError('Atomic envelope line coordinates differ')


def _arguments(text,command):
    """Literal command + lexical balanced group, not general macro expansion."""
    walker=LatexWalker(text,tolerant_parsing=False);results=[];unknown=[]
    for match in re.finditer(r'(?<!\\)\\'+re.escape(command)+r'(?![A-Za-z])\*?',text):
        at=match.end()
        while at<len(text) and text[at].isspace():at+=1
        try:
            if at<len(text) and text[at]=='[':
                _,position,length=walker.get_latex_braced_group(at,brace_type='[');at=position+length
                while at<len(text) and text[at].isspace():at+=1
            node,position,length=walker.get_latex_braced_group(at,brace_type='{')
            end=position+length
            if position!=at or end>len(text) or not text[end-1:end]=='}':raise ValueError('No literal complete brace group')
            results.append((match.start(),end,text[at+1:end-1]))
        except Exception:
            unknown.append({'status':'UNK','command':command,'projection_start':match.start(),'reason':'Literal balanced argument could not be located; macro expansion is not evaluated.'})
    return results,unknown


def _anchors(inv,obj):
    anchors=[];unknown=[];labels=[]
    for command in ('caption','label'):
        values,errors=_arguments(obj['prose_text'],command);unknown+=errors
        for start,end,arg in values:
            anchors.append({'kind':command,'status':'located_literal_source','quote':_quote(inv,obj['object_id'],start,end)})
            if command=='label':labels.append(arg)
        if not values:unknown.append({'status':'UNK','command':command,'reason':'No literal '+command+' argument located in this envelope; no semantic absence claim.'})
    # References are literal source commands; their relationship in the argument
    # is mechanical, not a judgment of why the author included the object.
    for uid,unit in inv['units'].items():
        for command in ('ref','Cref','cref','eqref','autoref','pageref'):
            values,_=_arguments(unit['prose_text'],command)
            for start,end,arg in values:
                matched=sorted(set(a.strip() for a in arg.split(','))&set(labels))
                if matched:anchors.append({'kind':'reference_to_label','status':'located_literal_source','labels':matched,'quote':_quote(inv,uid,start,end),'logical_relation':'earlier' if unit['logical_order']<obj['logical_order'] else 'later' if unit['logical_order']>obj['logical_order'] else 'same_logical_unit'})
    return anchors,unknown


def _quote_check(value,inv):
    if isinstance(value,dict):
        if {'unit_instance_id','text','start','end','source'}<=set(value):
            if bind_quote({k:value[k] for k in ('unit_instance_id','text','start','end')},_view(inv))!=value:raise ValueError('Existing model quote/source binding changed')
        else:
            for child in value.values():_quote_check(child,inv)
    elif isinstance(value,list):
        for child in value:_quote_check(child,inv)


def _origin_records(analysis_path,records,origin_attempt):
    candidates=[Path(origin_attempt).resolve()] if origin_attempt else sorted((Path(analysis_path).parent/'requests').glob('*/*'))
    remaining={digest(r) for r in records};origins=[]
    for folder in candidates:
        if not (folder/'verified.json').exists():continue
        value=load(folder/'verified.json');matches=[i for i,r in enumerate(value.get('records',[])) if digest(r) in remaining]
        if not matches:continue
        if load(folder/'audit.json').get('status')!='verified':raise ValueError('A retained model origin is not verified')
        raw=json.loads((folder/'response.raw.txt').read_text())
        parsed=load(folder/'parsed.json')
        if raw!=parsed:raise ValueError('Origin raw response differs from parsed response')
        origins.append({'artifact':binding(folder/'verified.json'),'record_json_pointers':['/records/'+str(i) for i in matches],'audit':binding(folder/'audit.json'),'raw_response':binding(folder/'response.raw.txt'),'parsed':binding(folder/'parsed.json')})
        remaining-={digest(value['records'][i]) for i in matches}
    if remaining:raise ValueError('No exact retained verified model origin for every selected record')
    return origins


def build(inventory_path,analysis_path,object_id,output_dir,origin_attempt=None):
    """Create a separate sidecar; source/model artifacts are never written."""
    inv=load(inventory_path);check_sources(inv);analysis=load(analysis_path)
    if analysis['inventory_hash']!=inv['inventory_hash']:raise ValueError('Analysis and source inventory differ')
    obj=inv.get('objects',{}).get(object_id)
    if obj is None:raise ValueError('Unknown exact source object')
    _check_object(inv,obj)
    if analysis['section_id']!=obj['section_id']:raise ValueError('Object belongs to another actual section')
    covered=set(obj['covered_unit_instance_ids']);selected=[(i,r) for i,r in enumerate(analysis['units']) if r['unit_instance_id'] in covered]
    if not selected:raise ValueError('No existing model records for the atomic object')
    records=[deepcopy(r) for _,r in selected]
    for record in records:_quote_check(record,inv)
    origins=_origin_records(analysis_path,records,origin_attempt);anchors,unknown=_anchors(inv,obj)
    statuses={'original_section_status':analysis['status'],'original_record_statuses':{r['chunk_id']:r['status'] for r in records},'mechanical_source_coverage':'complete_exact_static_envelope','local_semantic_completion':'not_assessed_by_sidecar','semantic_status':'existing_machine_proposal_pending_human','scientific_content_verification':'unverified','original_fragment_map_completed':False,'original_analysis_modified':False,'human_approval':'pending','new_model_calls':0}
    source={k:deepcopy(obj[k]) for k in ('object_id','file','offset_start','offset_end','line_start','line_end','sha256','prose_sha256','section_id','section_path','section_type','env_kind','object_kind','covered_unit_instance_ids','boundary_limitation')}
    warnings=['Mechanical whole-object source coverage is separate from the original partial functional analysis; it does not repair or approve that analysis.','Existing model fields are copied verbatim, including local unknowns, unanchored statements and limitations. No new semantic claim is supplied.','Scientific content remains unverified; this is not counted as a language failure.','Static same-file envelope and literal balanced command arguments are not a general TeX expansion guarantee.']
    model_view={'schema':'atomic-source-model-view-1','statuses':statuses,'source_object':{**source,'prose_text':obj['prose_text']},'atomic_source_span':_quote(inv,object_id,0,len(obj['prose_text'])),'mechanical_anchors':anchors,'mechanical_unknowns':unknown,'existing_model_records':records,'warnings':warnings}
    result={'schema':'atomic-source-sidecar-1','inventory':binding(inventory_path),'analysis':binding(analysis_path),'inventory_hash':inv['inventory_hash'],'original_record_json_pointers':['/units/'+str(i) for i,_ in selected],'model_origins':origins,'model_view':model_view,'human_source':{**source,'raw_text':obj['text'],'raw_usage':'Human source inspection and hash verification only; not part of model_view.'},'source_file':{'path':str((Path(inv['root'])/obj['file']).resolve()),'sha256':inv['source_files'][obj['file']]}}
    result['sidecar_id']=digest(result);home=Path(output_dir)/result['sidecar_id'][:20];home.mkdir(parents=True,exist_ok=True);path=home/'atomic_sidecar.json'
    if path.exists() and load(path)!=result:raise ValueError('Existing sidecar differs')
    if not path.exists():save(path,result)
    verify(path);_render(result,home/'review.md');return {**result,'artifact_path':str(path.resolve())}


def verify(sidecar_path):
    """Hash/source gate for optional delivery; return the validated complete sidecar."""
    value=load(sidecar_path)
    if value.get('schema')!='atomic-source-sidecar-1' or value.get('sidecar_id')!=digest({k:v for k,v in value.items() if k!='sidecar_id'}):raise ValueError('Atomic sidecar fingerprint changed')
    inv=load(checked(value['inventory']));check_sources(inv);analysis=load(checked(value['analysis']));checked(value['source_file'])
    obj=inv['objects'][value['model_view']['source_object']['object_id']];_check_object(inv,obj)
    if analysis['inventory_hash']!=value['inventory_hash'] or value['inventory_hash']!=inv['inventory_hash']:raise ValueError('Atomic source/analysis inventory changed')
    selected=[analysis['units'][int(p.rsplit('/',1)[1])] for p in value['original_record_json_pointers']]
    if selected!=value['model_view']['existing_model_records']:raise ValueError('Sidecar changed an existing model judgment')
    for origin in value['model_origins']:
        for field in ('artifact','audit','raw_response','parsed'):checked(origin[field])
        if json.loads(Path(origin['raw_response']['path']).read_text())!=load(origin['parsed']['path']):raise ValueError('Original model raw/parsed mismatch')
    bound={digest(r) for origin in value['model_origins'] for pointer in origin['record_json_pointers'] for r in [load(origin['artifact']['path'])['records'][int(pointer.rsplit('/',1)[1])]]}
    if bound!={digest(r) for r in selected}:raise ValueError('Sidecar origin record binding changed')
    for r in selected:_quote_check(r,inv)
    model=value['model_view'];_quote_check(model,inv)
    if model['source_object']['prose_text']!=obj['prose_text'] or value['human_source']['raw_text']!=obj['text']:raise ValueError('Sidecar source changed')
    if model['atomic_source_span']!=_quote(inv,obj['object_id'],0,len(obj['prose_text'])):raise ValueError('Atomic source span is incomplete')
    anchors,unknown=_anchors(inv,obj)
    if model['mechanical_anchors']!=anchors or model['mechanical_unknowns']!=unknown:raise ValueError('Literal anchor map changed')
    expected={'original_section_status':analysis['status'],'original_record_statuses':{r['chunk_id']:r['status'] for r in selected},'mechanical_source_coverage':'complete_exact_static_envelope','local_semantic_completion':'not_assessed_by_sidecar','semantic_status':'existing_machine_proposal_pending_human','scientific_content_verification':'unverified','original_fragment_map_completed':False,'original_analysis_modified':False,'human_approval':'pending','new_model_calls':0}
    if model['statuses']!=expected:raise ValueError('Sidecar changed or promoted completion/approval/science status')
    expected_source={k:deepcopy(obj[k]) for k in ('object_id','file','offset_start','offset_end','line_start','line_end','sha256','prose_sha256','section_id','section_path','section_type','env_kind','object_kind','covered_unit_instance_ids','boundary_limitation')}
    if {k:model['source_object'][k] for k in expected_source}!=expected_source or {k:value['human_source'][k] for k in expected_source}!=expected_source:raise ValueError('Sidecar source locator changed')
    return value


def _render(value,path):
    m=value['model_view'];s=m['statuses'];source=m['source_object']
    lines=['# Atomic source coverage beside original model analysis','',f"Original section: **{s['original_section_status']}**. Original functional map is unchanged. Human approval: **pending**.",'',f"Mechanical source coverage: **{s['mechanical_source_coverage']}**. Local semantic completion: **not assessed by this sidecar**. Scientific content: **unverified**.",'','Scientific non-verification is not a language failure. No model was called.','',f"Source: `{source['file']}` lines {source['line_start']}–{source['line_end']}, offsets {source['offset_start']}–{source['offset_end']}.",'','## Complete comment-free source','','```tex',source['prose_text'],'```','','## Existing Sonnet observations — verbatim, pending human','']
    for record in m['existing_model_records']:
        lines += [f"### {record['chunk_id']} — original {record['status']}",'']
        for name in ('observation','reader_before','reader_after'):lines += [f"**{name}**",'',record['reading_task'][name],'']
        for name,item in record['context_links'].items():lines += [f'**{name}**','',item['observation'],'',f"Source quotes: {len(item['evidence'])}. An empty quote list is retained; no new support is inferred.",'']
        lines += ['**Original limitations**','']+['- '+text for text in record['limitations']]+['','**Original reason**','',record['reason'],'']
    lines += ['## Literal source anchors','']
    for a in m['mechanical_anchors']:lines += ['- '+a['kind']+': `'+a['quote']['text'].replace('`','\\`')+'`']
    lines += ['','## Audit links','', '[Full sidecar JSON including raw human-only source](atomic_sidecar.json)','']
    Path(path).write_text('\n'.join(lines))
