"""Explicit source-bound structure registry transport. No semantic admission is inferred."""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
from .inventory import check_sources, digest, load, save, public_unit
from .contracts import bind_quote

class StructureRegistryError(ValueError):
    """An explicitly selected registry is unavailable, changed, or falsely reviewed."""


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _read_bound(binding):
    path=Path(binding['path'])
    if not path.is_file() or file_hash(path)!=binding['sha256']:
        raise StructureRegistryError('Bound structure artifact changed or missing: '+str(path))
    return load(path)


def _binding(path):
    path=Path(path).resolve()
    return {'path':str(path),'sha256':file_hash(path)}


def _quotes(value):
    if isinstance(value,dict):
        if 'unit_instance_id' in value and 'text' in value and 'start' in value and 'end' in value:
            yield value
        else:
            for child in value.values():yield from _quotes(child)
    elif isinstance(value,list):
        for child in value:yield from _quotes(child)


def _source(inventory,source_id):
    """Resolve a physical source unit or complete object without inventing coverage."""
    unit=inventory['units'].get(source_id)
    obj=inventory.get('objects',{}).get(source_id)
    if unit is not None and obj is not None:raise StructureRegistryError('Ambiguous unit/object source ID')
    source=unit if unit is not None else obj
    if source is None:raise StructureRegistryError('Quoted/dependent source is not supplied: '+source_id)
    if obj is not None and not obj.get('complete'):
        raise StructureRegistryError('Quoted/dependent object has an incomplete source envelope: '+source_id)
    relative=source['file']
    if relative not in inventory['source_files']:
        raise StructureRegistryError('Source envelope file is not pinned by inventory: '+relative)
    path=(Path(inventory['root'])/relative).resolve()
    if not path.is_relative_to(Path(inventory['root']).resolve()):
        raise StructureRegistryError('Source envelope escapes inventory root')
    from ..corpus.parser import strip_comments
    with path.open(encoding='utf8',newline='') as handle:raw=handle.read()
    start,end=source['offset_start'],source['offset_end']
    if not 0<=start<end<=len(raw):raise StructureRegistryError('Source envelope has false physical offsets')
    text=raw[start:end];prose=strip_comments(raw)[start:end]
    if (source['text']!=text or source['prose_text']!=prose or
            source['sha256']!=hashlib.sha256(text.encode()).hexdigest() or
            source['prose_sha256']!=hashlib.sha256(prose.encode()).hexdigest()):
        raise StructureRegistryError('Source envelope raw/prose text or hash differs from original file')
    return source


def _public_source(inventory,source_id):
    source=_source(inventory,source_id)
    if source_id in inventory.get('objects',{}):
        return {**{k:copy.deepcopy(v) for k,v in source.items() if k!='text'},'source_kind':'complete_object_envelope','raw_text_policy':'Original raw text is checked against the bound source file; only the complete comment-free projection is model evidence.'}
    return {**{k:copy.deepcopy(v) for k,v in source.items() if k!='text'},'source_kind':'physical_source_unit'}


def _check_quote(quote,inventory):
    source_id=quote['unit_instance_id'];_source(inventory,source_id)
    # The compatibility view is local and read-only; it does not alter inventory
    # hashes or treat object envelopes as natural paragraph units.
    view={**inventory,'units':{**inventory['units'],**inventory.get('objects',{})}}
    if not all(k in quote for k in ('text','start','end','source')):
        raise StructureRegistryError('Quote lacks exact offsets or original source binding')
    bound=bind_quote({k:quote[k] for k in ('unit_instance_id','text','start','end')},view)
    if quote['source']!=bound['source']:raise StructureRegistryError('Quote source binding changed')


def _context_payload(analysis,inventory):
    provenance=analysis.get('context_provenance')
    if not provenance:return None
    if provenance.get('version')!=2:
        raise StructureRegistryError('Unsupported context provenance version; cannot omit contextual dependencies')
    ledger_binding=provenance.get('source_ledger')
    bindings=provenance.get('artifact_bindings',[])
    if not ledger_binding or not any(b.get('kind')=='source_ledger' and all(b.get(k)==ledger_binding.get(k) for k in ('path','sha256')) for b in bindings):
        raise StructureRegistryError('Context provenance omits its exact source-ledger dependency')
    from .context import assert_context_fresh,load_bound_context
    assert_context_fresh(provenance,inventory)
    payload=load_bound_context(provenance)
    if not payload:raise StructureRegistryError('Context provenance supplied no complete dependency payload')
    for quote in _quotes(payload):_check_quote(quote,inventory)
    _source_payload_ids(payload,inventory)
    return payload


def _source_payload_ids(value,inventory):
    """Find complete source envelopes in bound context, beyond explicit quotes."""
    ids=set()
    if isinstance(value,dict):
        source_id=value.get('object_id') or value.get('instance_id')
        if source_id and 'prose_text' in value:
            canonical=_source(inventory,source_id)
            if value['prose_text']!=canonical['prose_text']:
                raise StructureRegistryError('Bound context source envelope differs from original projection')
            for key in ('file','offset_start','offset_end','sha256','prose_sha256'):
                if key in value and value[key]!=canonical[key]:
                    raise StructureRegistryError('Bound context source envelope provenance differs from original')
            ids.add(source_id)
        for child in value.values():ids.update(_source_payload_ids(child,inventory))
    elif isinstance(value,list):
        for child in value:ids.update(_source_payload_ids(child,inventory))
    return ids


def _check_analysis(analysis,inventory):
    check_sources(inventory)
    if analysis.get('inventory_hash')!=inventory['inventory_hash']:
        raise StructureRegistryError('Analysis is bound to another source inventory')
    section=next((s for s in inventory['sections'] if s['section_id']==analysis['section_id']),None)
    if section is None:raise StructureRegistryError('Analysis real section is missing')
    observation=analysis.get('section_observation')
    if not observation:raise StructureRegistryError('Analysis has no section observation')
    for obj in (analysis,observation):
        if obj.get('review_status')!='machine_proposed' or obj.get('semantic_status')!='pending_human':
            raise StructureRegistryError('Code/model artifacts cannot self-approve semantic observations')
    if observation.get('section_id')!=section['section_id'] or observation.get('observation_scope')!='single_source':
        raise StructureRegistryError('Observation lost its real single-source section binding')
    if [(i['kind'],i['item_id']) for i in observation['ordered_items']]!=[(i['kind'],i['item_id']) for i in section['direct_items']]:
        raise StructureRegistryError('Section map omits, merges, or reorders real items')
    if not analysis.get('units'):raise StructureRegistryError('Section analysis has no unit observations')
    if observation.get('status')=='analyzed' and not observation['section_task'].get('evidence'):
        raise StructureRegistryError('Analyzed section task lacks original source evidence')
    for item in observation['ordered_items']:
        if item.get('status')=='analyzed' and not item.get('evidence'):
            raise StructureRegistryError('Analyzed section item lacks original source evidence')
    for item in observation.get('observations',[]):
        if not item.get('evidence'):raise StructureRegistryError('Section observation lacks original source evidence')
    for item in observation.get('transitions',[]):
        if item.get('status')=='observed' and not item.get('evidence'):
            raise StructureRegistryError('Observed transition lacks original source evidence')
    for record in analysis['units']:
        if record.get('status')=='analyzed' and (not record.get('segments') or not record['reading_task'].get('evidence')):
            raise StructureRegistryError('Analyzed unit lacks original source support')
        if record['unit_instance_id'] not in section['all_unit_instances']:
            raise StructureRegistryError('Unit observation belongs to another section')
    for quote in _quotes(analysis):
        _check_quote(quote,inventory)
    _context_payload(analysis,inventory)
    return section


def _atomic_sidecars(entry):
    from .atomic_sidecar import verify
    checked=[]
    for binding in entry.get('atomic_sidecars',[]):
        _read_bound(binding);sidecar=verify(binding['path'])
        if sidecar['inventory']!=entry['inventory'] or sidecar['analysis']!=entry['analysis']:
            raise StructureRegistryError('Atomic sidecar is bound to another exact analysis or inventory')
        checked.append({'binding':binding,'sidecar_id':sidecar['sidecar_id'],'model_view':sidecar['model_view']})
    return checked


def stage_registry(entries,output_path,target_author='Wolfram Wiesemann'):
    """Freeze exact analyses + inventories. Entry concepts are explicit applicability tags.

    This writes a candidate registry only; publish_registry is a separate activation.
    """
    frozen=[]
    for entry in entries:
        analysis_binding=_binding(entry['analysis_path']);inventory_binding=_binding(entry['inventory_path'])
        analysis=_read_bound(analysis_binding);inventory=_read_bound(inventory_binding)
        section=_check_analysis(analysis,inventory)
        concepts=entry.get('concepts',[])
        if not isinstance(concepts,list) or any(not isinstance(c,str) or not c.strip() for c in concepts):
            raise StructureRegistryError('Applicability concepts must be explicit nonempty strings')
        identity={'analysis':analysis_binding,'inventory':inventory_binding,'section_id':section['section_id'],'paper_id':inventory['paper_id'],'section_type':section['section_type'],'concepts':sorted(set(concepts))}
        if entry.get('atomic_sidecar_paths'):
            identity['atomic_sidecars']=[_binding(p) for p in entry['atomic_sidecar_paths']]
            _atomic_sidecars(identity)
        frozen.append({'entry_id':digest(identity)[:24],**identity})
    if len({e['entry_id'] for e in frozen})!=len(frozen):raise StructureRegistryError('Duplicate registry entry')
    registry={'schema':'structure-delivery-1','target_author':target_author,'review_status':'machine_proposed','semantic_status':'pending_human','entries':frozen}
    registry['packet_hash']=digest(registry)
    path=Path(output_path)
    if path.exists() and load(path)!=registry:raise StructureRegistryError('Refusing to overwrite a different staged registry')
    save(path,registry)
    return registry


def _load_registry(path):
    registry=load(path)
    if registry.get('schema')!='structure-delivery-1' or digest({k:v for k,v in registry.items() if k!='packet_hash'})!=registry.get('packet_hash'):
        raise StructureRegistryError('Structure registry packet hash/schema mismatch')
    if registry.get('review_status')!='machine_proposed' or registry.get('semantic_status')!='pending_human':
        raise StructureRegistryError('Registry cannot declare itself approved')
    resolved=[]
    for entry in registry['entries']:
        analysis=_read_bound(entry['analysis']);inventory=_read_bound(entry['inventory']);section=_check_analysis(analysis,inventory)
        if any(entry[k]!=v for k,v in [('section_id',section['section_id']),('section_type',section['section_type']),('paper_id',inventory['paper_id'])]):
            raise StructureRegistryError('Registry source/section metadata mismatch')
        _atomic_sidecars(entry)
        resolved.append((entry,analysis,inventory,section))
    return registry,resolved


def publish_registry(staged_path,knowledge_dir,human_decisions_path=None):
    """Activate an exact pending packet; optional actual human decision remains separate.

    A decision file is an externally supplied attestation, not program-verifiable human
    identity. Models/code must never manufacture it. Absence means pending, not approval.
    """
    registry,_=_load_registry(staged_path)
    pointer={'schema':'structure-active-1','registry':_binding(staged_path),'packet_hash':registry['packet_hash']}
    if human_decisions_path:pointer['human_decisions']=_binding(human_decisions_path)
    _review_states(pointer,registry)
    save(Path(knowledge_dir)/'structure_active.json',pointer)
    return pointer


def _review_states(pointer,registry):
    states={e['entry_id']:'pending_human' for e in registry['entries']}
    if 'human_decisions' not in pointer:return states
    decisions=_read_bound(pointer['human_decisions'])
    if decisions.get('packet_hash')!=registry['packet_hash'] or decisions.get('decision_origin')!='human' or not decisions.get('reviewer') or not decisions.get('reviewed_at'):
        raise StructureRegistryError('Human decision provenance is absent or not bound to exact packet')
    byid={e['entry_id']:e for e in registry['entries']}
    for decision in decisions.get('decisions',[]):
        entry=byid.get(decision['entry_id'])
        if not entry or decision.get('analysis_sha256')!=entry['analysis']['sha256'] or decision.get('inventory_sha256')!=entry['inventory']['sha256']:
            raise StructureRegistryError('Human decision is not bound to exact source and analysis')
        if decision.get('decision') not in ('approved','rejected','pending_human'):raise StructureRegistryError('Unknown human decision')
        states[entry['entry_id']]=decision['decision']
    return states


def _compact(value,source_refs):
    """Deduplicate quote provenance only; exact quoted text and every observation stay."""
    if isinstance(value,list):return [_compact(v,source_refs) for v in value]
    if isinstance(value,dict):
        is_quote=all(k in value for k in ('unit_instance_id','text','start','end','source'))
        result={k:_compact(v,source_refs) for k,v in value.items() if not (is_quote and k=='source')}
        if is_quote:
            key=digest(value['source'])[:24];source_refs[key]=value['source'];result['source_ref']=key
        return result
    return value


def _compact_source_envelopes(value,inventory):
    """Lossless source-only envelope projections into the shared complete pool."""
    if isinstance(value,list):return [_compact_source_envelopes(v,inventory) for v in value]
    if not isinstance(value,dict):return value
    source_id=value.get('object_id') or value.get('instance_id')
    if source_id and 'prose_text' in value:
        canonical=_source(inventory,source_id)
        if 'text' in value:raise StructureRegistryError('Raw source text cannot enter a model context envelope')
        if all(k in canonical and canonical[k]==v for k,v in value.items()):
            return {'source_envelope_ref':source_id,'source_fields':list(value)}
    return {k:_compact_source_envelopes(v,inventory) for k,v in value.items()}


def _walk(value):
    if isinstance(value,dict):
        yield value
        for child in value.values():yield from _walk(child)
    elif isinstance(value,list):
        for child in value:yield from _walk(child)


def _context_closure(analysis,records,inventory,artifacts,extra_records=None,include_section=True):
    """Mechanical model view; complete canonical artifacts remain bound for audit.

    No observation or source passage is shortened. Unreferenced artifact content
    is excluded with an explicit manifest, while all artifact hashes remain pinned.
    """
    if artifacts is None:return None
    context_records=records+list(extra_records or [])
    observation=analysis['section_observation'];roots=([observation]if include_section else [])+[context_records]
    bundles=[a for a in artifacts.values() if a['kind']=='context_bundle']
    by_bundle={a['content'].get('context_bundle_id'):a for a in bundles}
    section_bid=observation.get('context_bundle_id')if include_section else None
    if include_section and(not section_bid or section_bid not in by_bundle):
        raise StructureRegistryError('Selected section lacks its exact complete context bundle')
    chosen={section_bid}if include_section else set();chunk_ids={r['chunk_id'] for r in context_records if r.get('analysis_origin')!='deterministic_source_metadata'}
    for chunk in chunk_ids:
        matches=[a for a in bundles if chunk in a['content'].get('target_chunk_ids',[])]
        if len(matches)!=1:raise StructureRegistryError('Selected unit chunk has missing or ambiguous context bundle: '+chunk)
        chosen.add(matches[0]['content']['context_bundle_id'])
    selected=[by_bundle[b] for b in sorted(chosen)]
    entries={};non_src=set()
    # Index only typed entries; INF statements can never stand in for a SRC ID.
    for node in _walk([artifacts,roots]):
        key=node.get('entry_id') or node.get('assertion_id')
        if not key:continue
        if node.get('epistemic_status')!='SRC':non_src.add(key);continue
        if not node.get('evidence'):raise StructureRegistryError('SRC entry has no original source evidence: '+key)
        if key in entries and entries[key]!=node:
            raise StructureRegistryError('Conflicting canonical content for SRC ID: '+key)
        entries[key]=node
    summaries={};neighbors={};objects={};dependencies={};unknowns={};bundle_views=[];omitted_incremental=0
    required={d for node in _walk(roots) for d in node.get('depends_on_src_ids',[])}
    for artifact in selected:
        bundle=artifact['content'];bid=bundle['context_bundle_id']
        selected_chunk_ids={observation['section_id']+':section_context'} if bid==section_bid else chunk_ids & set(bundle.get('target_chunk_ids',[]))
        prior_views={}
        for chunk,prior in bundle.get('prior_by_chunk',{}).items():
            if chunk not in selected_chunk_ids:continue
            # Summaries are direct prior-section context, retained completely and
            # with their transitive SRC basis. Prior unreferenced unit INF history
            # stays in the canonical bundle rather than becoming implicit rules.
            for summary in prior.get('prior_section_summary_cards',[]):
                sid=summary.get('section_id',digest(summary));key=str(sid)+':'+digest(summary)[:16];summaries[key]=summary
                required.update(summary.get('depends_on_src_ids',[]))
            omitted_incremental+=len(prior.get('incremental_INF_observations',[]))
            prior_views[chunk]={k:v for k,v in prior.items() if k not in ('source_entries','prior_section_summary_cards','incremental_INF_observations')}
        for unit in bundle.get('neighbor_prose_units',[]):neighbors[unit['instance_id']]=unit
        for obj in bundle.get('complete_preservation_objects',[]):objects[obj['object_id']]=obj
        for dependency in bundle.get('dependency_sources',[]):dependencies[digest(dependency)]=dependency
        for unknown in bundle.get('dependency_unknowns',[]):unknowns[digest(unknown)]=unknown
        keep=('context_version','inventory_hash','ledger_scan_id','ledger_scope','absence_rule','future_dependency_rule','known_limitations')
        bundle_views.append({**{k:bundle[k] for k in keep if k in bundle},'context_bundle_id':bid,'artifact_binding':{k:artifact[k] for k in ('kind','path','sha256')},'selected_chunk_ids':sorted(selected_chunk_ids),'prior_by_chunk':prior_views})
    closure={};visiting=set()
    def include(key):
        if key in closure:return
        if key in visiting:raise StructureRegistryError('Cyclic SRC dependency: '+key)
        if key not in entries or key in non_src:
            raise StructureRegistryError('Missing dependency or INF/UNK used as SRC: '+key)
        visiting.add(key);entry=entries[key]
        for dependency in entry.get('depends_on_src_ids',[]):include(dependency)
        closure[key]=entry;visiting.remove(key)
    for key in sorted(required):include(key)
    # Check true source positions, not merely declared established_position.
    from .contextual import position
    def dependency_positions(key,seen=None):
        seen=set() if seen is None else seen
        if key in seen:return []
        seen.add(key);entry=closure[key]
        return [position(q,inventory) for q in _quotes(entry)]+[p for d in entry.get('depends_on_src_ids',[]) for p in dependency_positions(d,seen)]
    for artifact in selected:
        bundle=artifact['content'];bid=bundle['context_bundle_id']
        selected_chunk_ids={observation['section_id']+':section_context'} if bid==section_bid else chunk_ids & set(bundle.get('target_chunk_ids',[]))
        for chunk,prior in bundle.get('prior_by_chunk',{}).items():
            if chunk not in selected_chunk_ids:continue
            cutoff=tuple(prior.get('cutoff',[]))
            if len(cutoff)!=2:raise StructureRegistryError('Prior context lacks its exact chronological cutoff')
            for summary in prior.get('prior_section_summary_cards',[]):
                positions=[position(q,inventory) for q in _quotes(summary)]
                positions += [p for d in summary.get('depends_on_src_ids',[]) for p in dependency_positions(d)]
                if summary.get('section_complete_position',cutoff[0])>=cutoff[0] or any(p>cutoff for p in positions):
                    raise StructureRegistryError('Future source or unfinished section summary cannot establish prior-reader context')
    for record in context_records:
        unit=inventory['units'][record['unit_instance_id']]
        own=[s['quote'] for s in record.get('segments',[]) if s['quote']['unit_instance_id']==record['unit_instance_id']]
        before=(unit['logical_order'],min((q['start'] for q in own),default=0))
        after=(unit['logical_order'],max((q['end'] for q in own),default=len(unit['prose_text'])))
        # A trimmed final prose quotation may omit the physical unit's trailing
        # newline. Its full-unit SRC container then ends after the quote without
        # adding any reader content. Extend reader_after only across an actual,
        # source-checked whitespace suffix; never cross another chunk boundary.
        suffix=unit['prose_text'][after[1]:]
        later_chunk=any(other.get('chunk_id')!=record.get('chunk_id') and
            other['unit_instance_id']==record['unit_instance_id'] and
            any(s['quote']['unit_instance_id']==record['unit_instance_id'] and s['quote']['start']>=after[1]
                for s in other.get('segments',[])) for other in analysis['units'])
        if suffix and suffix.isspace() and not later_chunk:
            checked_unit=_source(inventory,record['unit_instance_id'])
            after=(unit['logical_order'],len(checked_unit['prose_text']))
        for assertion in record.get('context_assertions',[]):
            cutoff=before if assertion.get('role')=='reader_before' else after if assertion.get('role')=='reader_after' else None
            positions=[position(q,inventory) for q in _quotes(assertion)]
            positions += [p for d in assertion.get('depends_on_src_ids',[]) for p in dependency_positions(d)]
            if cutoff is not None and any(p>cutoff for p in positions):
                raise StructureRegistryError('Future source dependency cannot establish prior-reader knowledge')
    included=set(closure)
    manifest={'schema':'structure-context-closure-1','selected_bundle_ids':sorted(chosen),'included_src_ids':sorted(included),'included_summary_ids':sorted(summaries),'omitted_src_ids':sorted(set(entries)-included),'omitted_incremental_inf_count':omitted_incremental,'omitted_artifacts':[{'kind':a['kind'],'path':a['path'],'sha256':a['sha256'],'reason':'Unselected bundle or generation history; only its actual SRC dependency closure is delivered.'} for a in artifacts.values() if a['kind']!='context_bundle' or a['content'].get('context_bundle_id') not in chosen],'missing_dependencies':[],'whole_section_observation_included':include_section,'source_policy':('Complete selected section observation and chosen unit chunks; complete source dependencies and conditions, no new summary or source truncation. Canonical artifact bindings remain subject to freshness checks.'if include_section else 'Whole-section interpretation is withheld by its independent human decision. Complete approved unit observations and their original source dependencies are delivered; canonical artifacts remain bound and unchanged.')}
    return {'schema':'structure-selected-context-1','bundle_contexts':bundle_views,'src_entries':closure,'prior_section_summaries':summaries,'neighbor_prose_units':list(neighbors.values()),'complete_preservation_objects':list(objects.values()),'reference_dependencies':list(dependencies.values()),'dependency_unknowns':list(unknowns.values()),'closure_manifest':manifest}


def validate_source_references(value,source):
    """Reject dangling model-view references before writing/reviewing a packet."""
    pool=source.get('source_units',{});quotes=source.get('quote_sources',{})
    for node in _walk(value):
        if 'source_envelope_ref' in node:
            key=node['source_envelope_ref'];fields=node.get('source_fields')
            if key not in pool or not isinstance(fields,list) or any(k not in pool[key] for k in fields):
                raise StructureRegistryError('Missing complete source envelope or source field projection: '+str(key))
        if 'source_ref' in node:
            key=node['source_ref']
            if key not in quotes:raise StructureRegistryError('Missing exact quote-source reference: '+str(key))
            if all(k in node for k in ('unit_instance_id','text','start','end')):
                uid=node['unit_instance_id'];unit=pool.get(uid);bound=quotes[key]
                if unit is None or unit['prose_text'][node['start']:node['end']]!=node['text'] or bound.get('unit_instance_id')!=uid or bound.get('projection_start')!=node['start'] or bound.get('projection_end')!=node['end'] or bound.get('projection_span_sha256')!=hashlib.sha256(node['text'].encode()).hexdigest():
                    raise StructureRegistryError('Quote reference does not resolve to its exact complete source projection')


def _packet_chars(items,audit):
    audit['delivered_packet_chars']=0
    for _ in range(5):
        count=len(json.dumps({'items':items,'structure':audit},ensure_ascii=False))
        if count==audit['delivered_packet_chars']:return count
        audit['delivered_packet_chars']=count
    return count


def assert_delivered_structure_references(changes,evidence):
    delivered={item['evidence_id'] for item in evidence.get('items',[])}
    references={source for change in changes for source in change.get('sources',[]) if isinstance(source,str) and source.startswith('structure:')}
    if not references<=delivered:
        raise StructureRegistryError('Change cites structure evidence that was not delivered: '+', '.join(sorted(references-delivered)))
    for item in evidence.get('items',[]):
        if item['evidence_id'] not in references:continue
        sid=item.get('provenance',{}).get('structure_source_id')
        source=evidence.get('structure',{}).get('sources',{}).get(sid)
        if source is None:raise StructureRegistryError('Referenced structure evidence is missing its complete source dictionary')
        validate_source_references([source,item],source)

def select_evidence(card,knowledge_dir,max_items,max_packet_chars=250000,*,source_filter=None):
    """Deliver complete source-bound views with independent section/unit human scope."""
    pointer_path=Path(knowledge_dir)/'structure_active.json'
    audit={'status':'absent','selected':[],'rejected':[],'not_delivered':[],'sources':{},'warnings':[],'delivered_ids':[],'max_packet_chars':max_packet_chars}
    if not pointer_path.exists():
        audit['delivered_packet_chars']=0
        return [],audit
    try:
        pointer=load(pointer_path)
        if pointer.get('schema')!='structure-active-1':raise StructureRegistryError('Invalid active registry pointer')
        _read_bound(pointer['registry']);registry,resolved=_load_registry(pointer['registry']['path'])
        if pointer.get('packet_hash')!=registry['packet_hash']:raise StructureRegistryError('Active packet hash mismatch')
        states=_review_states(pointer,registry)
        from ..knowledge.human_review import load_review
        human_overlay=load_review(knowledge_dir,registry)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        raise StructureRegistryError('Explicit active structure registry failed validation; no fallback: '+str(exc)) from exc
    audit.update(status='active',packet_hash=registry['packet_hash'],registry_sha256=pointer['registry']['sha256'],active_pointer_sha256=file_hash(pointer_path))
    reviewed={e['entry_id']:e for e in human_overlay['structure_entries']}if human_overlay else {}
    if human_overlay:audit['human_review']={'overlay_hash':human_overlay['overlay_hash'],'active_pointer_sha256':human_overlay['active_pointer_sha256'],'section_approval_cascades':False}
    candidates=[];concepts={c.casefold() for c in card.get('concepts',[])};requested=set(card.get('reference_paper_ids',[]))
    for entry,analysis,inventory,section in resolved:
        eid=entry['entry_id'];reason=None;human=reviewed.get(eid)
        if source_filter is not None and not source_filter(inventory,eid):
            audit['rejected'].append({'entry_id':eid,'reason':'evaluation_source_exclusion'});continue
        if states[eid]=='rejected':reason='human_rejected'
        elif entry['section_type']!=card['section_type']:reason='different_real_section_type'
        elif not (concepts & {c.casefold() for c in entry['concepts']} or inventory['paper_id'] in requested):reason='no_concept_or_explicit_source_fit'
        if reason:audit['rejected'].append({'entry_id':eid,'reason':reason});continue
        # Match actual source units; a shared category never establishes universal order.
        scores=[]
        for uid in dict.fromkeys(r['unit_instance_id'] for r in analysis['units']):
            records=[r for r in analysis['units'] if r['unit_instance_id']==uid]
            if all(r['status']=='skipped' for r in records):continue
            if human and human['unit_decisions'].get(uid,{}).get('decision')!='approve':
                audit['rejected'].append({'entry_id':eid,'unit_instance_id':uid,'reason':'unit_not_independently_human_approved','human_decision':human['unit_decisions'].get(uid,{}).get('decision','pending_human')});continue
            unit=inventory['units'][uid]
            score=len(concepts & {c.casefold() for c in unit.get('concepts',[])})
            score+=sum(c in unit['prose_text'].casefold() for c in concepts)
            scores.append((score,-unit['logical_order'],uid,records))
        if not scores:audit['rejected'].append({'entry_id':eid,'reason':'no_non_skipped_unit_observation'});continue
        best=max(scores,key=lambda row:(row[0],row[1]))
        if best[0]==0 and inventory['paper_id'] not in requested:
            audit['rejected'].append({'entry_id':eid,'reason':'no_relevant_unit_concept_support'});continue
        candidates.append((best[0],eid,entry,analysis,inventory,section,best[2],best[3]))
    items=[]
    for _,eid,entry,analysis,inventory,section,uid,records in sorted(candidates,key=lambda row:(-row[0],row[1])):
        human=reviewed.get(eid);include_section=not human or human['section_decision']['decision']=='approve';needed=2 if include_section else 1
        if len(items)+needed>max_items:audit['rejected'].append({'entry_id':eid,'reason':'source_slot_budget_requires_selected_reviewed_view'if human else 'overall_source_unit_slot_budget_requires_section_and_unit_pair'});continue
        sidecars=_atomic_sidecars(entry)
        extra_records=[r for sidecar in sidecars for r in sidecar['model_view']['existing_model_records']]
        full_context=_context_payload(analysis,inventory)
        viewed_analysis=analysis
        if human:
            from .human_review import section_view
            viewed_analysis={**analysis,'section_observation':section_view(analysis['section_observation'],human['unit_decisions'])}
            extra_records=[r for r in extra_records if human['unit_decisions'].get(r['unit_instance_id'],{}).get('decision')=='approve']
        context=_context_closure(viewed_analysis,records,inventory,full_context,extra_records,include_section=include_section)
        refs={};section_observation=viewed_analysis['section_observation']if include_section else None;obs=_compact(section_observation,refs);unit_obs=_compact(records,refs)
        context_payload=_compact(_compact_source_envelopes(context,inventory),refs)
        atomic_payload=_compact(_compact_source_envelopes(sidecars,inventory),refs)
        # Complete original prose for every quoted dependency, including neighbouring units.
        dependencies={q['unit_instance_id'] for q in _quotes([section_observation,records,context,sidecars])}|{uid}|_source_payload_ids([context,sidecars],inventory)
        source={'paper_id':inventory['paper_id'],'metadata':inventory['metadata'],'inventory_hash':inventory['inventory_hash'],'analysis':entry['analysis'],'inventory':entry['inventory'],'source_files':inventory['source_files'],'quote_sources':refs,'source_units':{u:_public_source(inventory,u) for u in sorted(dependencies)},'section':section,'analysis_context':{k:v for k,v in analysis.items() if k not in ('units','section_observation')}}
        if context_payload is not None:
            source['context_artifacts']=context_payload
            source['source_envelope_ref_policy']='Every source_envelope_ref resolves to source_units[id]; source_fields lists the exact original metadata/prose fields of that complete envelope. No original source content was shortened.'
        if atomic_payload:source['atomic_sidecars']=atomic_payload
        tag='coauthor_text' if registry['target_author'] in inventory['metadata'].get('authors',[]) else 'author_text'
        conditions=['Single-source observation; compare reader task and scientific context before transfer.','Shared section type does not establish a universal paragraph order.']
        if sidecars:conditions.append('Atomic sidecar provides complete mechanical source only: original_fragment_map_completed=false; original partial semantic observations and scientific unverified status are unchanged.')
        section_status=('approved'if include_section else human['section_decision']['decision'])if human else states[eid]
        unit_status='approved'if human else states[eid]
        if not human and states[eid]!='approved':conditions.append('Pending human semantic review: proposal only; not an accepted Level 3 rule.')
        if human:conditions+=['Human section and unit decisions are independent; complete source dependencies are context, not endorsed writing guidance.','Scientific truth and transfer to another manuscript remain unverified.']
        provenance={'structure_source_id':eid,'packet_hash':registry['packet_hash'],'review_status':section_status,'observation_scope':'single_source'}
        if human:provenance.update(human_review_overlay_hash=human_overlay['overlay_hash'],review_scope='section_organization_only',unit_approval_cascades=False)
        pair=[]
        if include_section:pair.append({'evidence_id':f'structure:{eid}:section','source_tag':tag,'text':'Source-specific section organization observation; human-excluded unit interpretations, if any, are explicit withheld placeholders.','conditions':conditions,'provenance':provenance,'structure_observation':obs})
        pair.append({'evidence_id':f'structure:{eid}:unit:{uid}','source_tag':tag,'text':inventory['units'][uid]['prose_text'],'conditions':conditions,'provenance':{**provenance,'review_status':unit_status,'review_scope':'independently_reviewed_unit'if human else 'pending_source_specific_observation'},'unit_observations':unit_obs})
        if human:source['human_review_scope']={'section_decision':human['section_decision']['decision'],'unit_decision':human['unit_decisions'][uid]['decision'],'nonendorsed_unit_ids':[u for u,d in human['unit_decisions'].items()if d['decision']!='approve'],'context_is_not_endorsed_guidance':True,'whole_section_map_delivered':include_section}
        validate_source_references([source,pair],source)
        proposed=copy.deepcopy(audit);proposed['sources'][eid]=source
        proposed['selected'].append({'entry_id':eid,'section_id':section['section_id'],'unit_instance_id':uid,'selection_reason':'matching_real_section_type_and_concept_or_explicit_source','review_status':section_status,'unit_review_status':unit_status,'whole_section_map_delivered':include_section,'source_files':inventory['source_files'],'analysis_sha256':entry['analysis']['sha256'],'context_closure':{'source_id':eid,'manifest_path':'context_artifacts.closure_manifest','included_src_count':len(context['closure_manifest']['included_src_ids'])} if context else None})
        if not include_section:proposed['warnings'].append('Whole-section interpretation withheld by its own human decision; only an independently approved unit is delivered.')
        elif not human and states[eid]!='approved':proposed['warnings'].append('Structure '+eid+' is pending human review; no accepted Level 3 rule is established.')
        proposed['delivered_ids']=[i['evidence_id'] for i in items+pair]
        required=_packet_chars(items+pair,proposed)
        if required>max_packet_chars:
            audit['rejected'].append({'entry_id':eid,'reason':'complete_packet_char_budget_no_truncation'})
            audit['not_delivered'].append({'entry_id':eid,'status':'not_delivered','reason':'Complete mandatory section/unit/source closure exceeds explicit packet budget; no structure evidence IDs were delivered.','required_packet_chars':required})
            continue
        items.extend(pair);audit=proposed
    audit['delivered_ids']=[i['evidence_id'] for i in items]
    if _packet_chars(items,audit)>max_packet_chars:
        raise StructureRegistryError('Complete structure packet audit exceeds explicit budget; no packet delivered')
    return items,audit


def assert_fresh(evidence,knowledge_dir):
    """Validate cached evidence before reuse; never replace its frozen knowledge silently."""
    pointer_path=Path(knowledge_dir)/'structure_active.json'
    recorded=evidence.get('structure',{})
    if not pointer_path.exists():
        if recorded.get('status')=='active':raise StructureRegistryError('Cached structure evidence lost its active registry')
        return
    if recorded.get('status')!='active' or recorded.get('active_pointer_sha256')!=file_hash(pointer_path):
        raise StructureRegistryError('Cached evidence differs from active structure registry; prepare a new task packet')
    try:
        pointer=load(pointer_path);_read_bound(pointer['registry'])
        registry,_=_load_registry(pointer['registry']['path']);_review_states(pointer,registry)
        from ..knowledge.human_review import load_review
        overlay=load_review(knowledge_dir,registry)
        if overlay:
            human=recorded.get('human_review',{})
            if human.get('overlay_hash')!=overlay['overlay_hash']or human.get('active_pointer_sha256')!=overlay['active_pointer_sha256']:raise StructureRegistryError('Cached structure evidence predates current human decisions')
        elif recorded.get('human_review'):raise StructureRegistryError('Cached structure evidence lost its human-review overlay')
        for sid,source in recorded.get('sources',{}).items():
            related=[item for item in evidence.get('items',[]) if item.get('provenance',{}).get('structure_source_id')==sid]
            validate_source_references([source,related],source)
        if recorded.get('packet_hash')!=registry['packet_hash'] or recorded.get('registry_sha256')!=pointer['registry']['sha256']:
            raise StructureRegistryError('Cached evidence registry binding changed')
    except (OSError,ValueError,KeyError,TypeError) as exc:
        raise StructureRegistryError('Cached structure evidence failed freshness validation: '+str(exc)) from exc
