"""Read-only literal coverage audit. Occurrence is neither stylistic nor admission approval."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

import yaml

from ..corpus.parser import strip_comments
from .inventory import check_sources, digest, save


def _sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _normalize(text, *, fold=True):
    """Whitespace normalization with a character-level inverse projection."""
    chars, spans = [], []
    for match in re.finditer(r"\s+|\S", text):
        value = " " if match.group().isspace() else match.group()
        value = value.casefold() if fold else value
        chars.extend(value)
        spans.extend([(match.start(), match.end())] * len(value))
    start = 1 if chars and chars[0] == " " else 0
    end = len(chars) - (1 if chars and chars[-1] == " " else 0)
    return "".join(chars[start:end]), spans[start:end]


def _paper_root(paper_id):
    # Only arXiv's explicit version suffix is collapsed; arbitrary names stay distinct.
    arxiv = r"arxiv_(?:\d{4}\.\d{4,5}|\d{7}|[a-z-]+[._/]\d{7})v\d+"
    return re.sub(r"v\d+$", "", paper_id) if re.fullmatch(arxiv, paper_id) else paper_id


def _read_text(path):
    with Path(path).open(encoding="utf8", newline="") as handle:
        return handle.read()


def _from_parsed(parsed_dir, metadata_dir):
    if metadata_dir is None:
        raise ValueError("metadata_dir (raw paper source roots) is required with parsed_dir")
    inventories = []
    for path in sorted(Path(parsed_dir).glob("*.jsonl")):
        units = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        if not units:
            continue
        paper_id = path.stem
        root = Path(metadata_dir) / paper_id
        meta_path = root / "meta.yaml"
        metadata = yaml.safe_load(meta_path.read_text()) if meta_path.exists() else {}
        inventories.append({"paper_id": paper_id, "root": str(root.resolve()), "metadata": metadata,
                            "units": {u["unit_id"]: u for u in units}, "parsed_path": str(path.resolve())})
    return inventories


def _prepare(inventories, target_author):
    sources, by_claim, papers = [], {}, {}
    for inv in inventories:
        paper_id = inv["paper_id"]
        root = Path(inv["root"]).resolve()
        if "inventory_hash" in inv and inv["inventory_hash"] != digest({k: v for k, v in inv.items() if k not in ("root", "inventory_hash")}):
            raise ValueError("Inventory hash mismatch: " + paper_id)
        if "source_files" in inv:
            check_sources(inv)
        metadata = inv.get("metadata") or {}
        if metadata.get("paper_id", paper_id) != paper_id:
            raise ValueError("Metadata paper_id mismatch: " + paper_id)
        # Compare against the actual metadata file when supplied, rather than trusting a cached copy.
        meta_path = root / "meta.yaml"
        if meta_path.exists():
            actual = yaml.safe_load(meta_path.read_text()) or {}
            if actual.get("paper_id", paper_id) != paper_id:
                raise ValueError("Metadata paper_id mismatch: " + str(meta_path))
            if metadata and metadata != actual:
                raise ValueError("Inventory metadata differs from source metadata: " + paper_id)
            metadata = actual
        authors = metadata.get("authors")
        known = isinstance(authors, list) and bool(authors) and all(isinstance(a, str) and a.strip() for a in authors)
        member = "unknown" if not known or not target_author else ("target_group" if target_author.casefold() in {a.casefold() for a in authors} else "external")
        flags = []
        if member == "target_group" and metadata.get("source_tag") == "author_text":
            flags.append("source_tag author_text conflicts with explicit target-author membership; review attribution")
        paper = {"paper_id": paper_id, "independent_paper_id": _paper_root(paper_id),
                 "authors": authors if known else None, "group_attribution": metadata.get("group_attribution"),
                 "source_tag": metadata.get("source_tag"), "source_url": metadata.get("source_url"),
                 "title": metadata.get("title"), "target_group_membership": member,
                 "metadata_path": str(meta_path) if meta_path.exists() else None,
                 "metadata_file_checked": meta_path.exists(), "attribution_flags": flags}
        if paper_id in papers and papers[paper_id] != paper:
            raise ValueError("Conflicting metadata for " + paper_id)
        papers[paper_id] = paper
        files = {}
        for instance, unit in inv["units"].items():
            if unit.get("paper_id") != paper_id:
                raise ValueError("Unit paper_id mismatch: " + unit.get("unit_id", instance))
            path = (root / unit["file"]).resolve()
            if not path.is_relative_to(root) or not path.is_file():
                raise ValueError("Missing or escaping source: " + str(path))
            if path not in files:
                file_text = _read_text(path)
                files[path] = (file_text, strip_comments(file_text), _sha(file_text))
            text, file_projection, file_hash = files[path]
            start, end = unit["offset_start"], unit["offset_end"]
            if not isinstance(start, int) or not isinstance(end, int) or not 0 <= start < end <= len(text):
                raise ValueError("Invalid unit offsets: " + unit["unit_id"])
            raw = text[start:end]
            clean = file_projection[start:end]
            if unit.get("text") != raw or unit.get("sha256") != _sha(raw):
                raise ValueError("Raw source/hash mismatch: " + unit["unit_id"])
            if unit.get("prose_text") != clean or unit.get("prose_sha256") != _sha(clean):
                raise ValueError("Prose source/hash mismatch: " + unit["unit_id"])
            if unit.get("line_start") != text.count("\n", 0, start) + 1 or unit.get("line_end") != text.count("\n", 0, end - 1) + 1:
                raise ValueError("Unit line mismatch: " + unit["unit_id"])
            normalized, mapping = _normalize(clean)
            source = {"unit": unit, "instance_id": instance, "path": str(path), "file_text": text,
                      "normalized": normalized, "mapping": mapping, "paper": paper,
                      "file_hash": file_hash, "adjacent": unit.get("adjacent_direct_units", {})}
            previous = by_claim.get((paper_id, unit["unit_id"]))
            if previous and previous["unit"] != unit:
                # Repeated include instances legitimately differ in structural context.
                fields = ("text", "prose_text", "sha256", "prose_sha256", "file", "offset_start", "offset_end")
                if any(previous["unit"].get(k) != unit.get(k) for k in fields):
                    raise ValueError("Conflicting source units: " + unit["unit_id"])
            by_claim[(paper_id, unit["unit_id"])] = source
            sources.append(source)
    return sources, by_claim, papers


def _validate_example(example, by_claim):
    if not isinstance(example, dict) or not isinstance(example.get("source"), dict) or not isinstance(example.get("text"), str):
        raise ValueError("example requires text and bound source")
    claim = example["source"]
    source = by_claim.get((claim.get("paper_id"), claim.get("unit_id")))
    if source is None:
        raise ValueError("claimed source unit is absent from checked corpus")
    for field in ("file", "line_start", "line_end", "sha256"):
        if claim.get(field) != source["unit"].get(field):
            raise ValueError("false or stale example source " + field)
    quote = _normalize(example["text"], fold=False)[0]
    if not quote or quote not in _normalize(source["unit"]["prose_text"], fold=False)[0]:
        raise ValueError("example text is absent from comment-free source")
    return source


def _canonical(path):
    if path is None:
        return {"checked": False, "shared_term_phrase_count": None, "shared_concept_count": None, "path": None}
    path = Path(path)
    if not path.is_file():
        raise ValueError("Canonical lexicon missing: " + str(path))
    data = yaml.safe_load(path.read_text()) or []
    pairs = {(item["term"].casefold(), _normalize(entry["phrase"])[0]) for item in data
             for entry in item.get("entries", []) if entry.get("scope") == "shared"}
    return {"checked": True, "path": str(path.resolve()), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "shared_term_phrase_count": len(pairs), "shared_concept_count": len({t for t, _ in pairs}),
            "meaning": "Existing canonical merged shared scope; not the recomputed literal coverage count."}


def audit(raw_dirs, inventories=None, output_dir=None, target_author=None, *, parsed_dir=None,
          metadata_dir=None, canonical_shared_path=None):
    """Audit verified lexicon candidates across checked, immutable source units.

    Use inventories OR parsed_dir plus metadata_dir (raw paper directories). No LLM,
    source mutation, semantic certification, or promotion to the active lexicon occurs.
    """
    if inventories is None:
        if parsed_dir is None:
            raise ValueError("inventories or parsed_dir is required")
        inventories = _from_parsed(parsed_dir, metadata_dir)
    elif parsed_dir is not None:
        raise ValueError("Choose inventories or parsed_dir, not both")
    inventories = list(inventories)
    raw_dirs = list(raw_dirs)
    sources, by_claim, papers = _prepare(inventories, target_author)
    if not papers:
        raise ValueError("No source papers supplied")
    candidates, rejected, input_files = {}, [], []
    ignored_patterns = 0
    for raw_dir in sorted({str(Path(p).resolve()) for p in raw_dirs}):
        if not Path(raw_dir).is_dir():
            raise ValueError("Raw extraction directory missing: " + raw_dir)
        for path in sorted(Path(raw_dir).glob("*.verified.json")):
            input_files.append({"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
            records = json.loads(path.read_text())
            if not isinstance(records, list):
                raise ValueError("Verified extraction must be an array: " + str(path))
            for record_index, record in enumerate(records):
                if record.get("kind") != "lexicon":
                    ignored_patterns += len(record.get("items", [])) if record.get("kind") == "patterns" else 0
                    continue
                if str(record.get("admission_status", "")).startswith("diagnostic"):
                    continue
                for index, item in enumerate(record.get("items", [])):
                    origin = {"path": str(path), "record_index": record_index, "item_index": index}
                    try:
                        term, phrase = item.get("term"), item.get("phrase")
                        if not isinstance(term, str) or not term.strip() or not isinstance(phrase, str) or not phrase.strip():
                            raise ValueError("nonempty term and phrase required")
                        examples = item.get("examples")
                        if not isinstance(examples, list) or not examples:
                            raise ValueError("bound examples required")
                        for example in examples:
                            _validate_example(example, by_claim)
                        normalized_phrase = _normalize(phrase)[0]
                        pattern = re.compile(r"(?<!\w)" + re.escape(normalized_phrase) + r"(?!\w)")
                        if not any(pattern.search(_normalize(e["text"])[0]) for e in examples):
                            raise ValueError("phrase lacks literal word-boundary evidence in examples")
                        key = (term.strip().casefold(), normalized_phrase)
                        candidate = candidates.setdefault(key, {"term": term.strip(), "phrase": phrase.strip(),
                            "normalized_term": key[0], "normalized_phrase": key[1], "candidate_sources": [], "verified_examples": []})
                        candidate["candidate_sources"].append(origin)
                        candidate["verified_examples"].extend(examples)
                    except (ValueError, KeyError, TypeError, AttributeError) as exc:
                        rejected.append({**origin, "reason": str(exc), "item": item})
    phrases = []
    for key, candidate in sorted(candidates.items()):
        pattern = re.compile(r"(?<!\w)" + re.escape(key[1]) + r"(?!\w)")
        occurrences, seen = [], {}
        for source in sources:
            unit = source["unit"]
            for match in pattern.finditer(source["normalized"]):
                begin, end = source["mapping"][match.start()][0], source["mapping"][match.end() - 1][1]
                absolute_start, absolute_end = unit["offset_start"] + begin, unit["offset_start"] + end
                unique = (unit["paper_id"], source["path"], absolute_start, absolute_end)
                if unique in seen:
                    instances = seen[unique]["unit_instance_ids"]
                    if source["instance_id"] not in instances:
                        instances.append(source["instance_id"])
                        seen[unique]["logical_sections"].append({"unit_instance_id": source["instance_id"],
                            "section_id": unit.get("section_id"), "section_path": unit.get("section_path", []),
                            "section_type": unit.get("section_type")})
                    continue
                occurrence = {"paper_id": unit["paper_id"], "independent_paper_id": _paper_root(unit["paper_id"]),
                    "unit_id": unit["unit_id"], "unit_instance_id": source["instance_id"], "file": unit["file"],
                    "unit_instance_ids": [source["instance_id"]],
                    "section_id": unit.get("section_id"), "section_path": unit.get("section_path", []),
                    "section_type": unit.get("section_type"),
                    "logical_sections": [{"unit_instance_id": source["instance_id"], "section_id": unit.get("section_id"),
                        "section_path": unit.get("section_path", []), "section_type": unit.get("section_type")}],
                    "source_path": source["path"], "unit_sha256": unit["sha256"], "prose_sha256": unit["prose_sha256"],
                    "source_file_sha256": source["file_hash"],
                    "projection_span": [begin, end], "normalized_span": [match.start(), match.end()],
                    "raw_offset_start": absolute_start, "raw_offset_end": absolute_end,
                    "line_start": source["file_text"].count("\n", 0, absolute_start) + 1,
                    "line_end": source["file_text"].count("\n", 0, absolute_end - 1) + 1,
                    "quote": unit["prose_text"][begin:end], "raw_quote": unit["text"][begin:end],
                    "context_before": unit["prose_text"][max(0, begin - 180):begin],
                    "context_after": unit["prose_text"][end:end + 180],
                    "adjacent_unit_instances": source["adjacent"], "attribution": source["paper"]}
                occurrences.append(occurrence)
                seen[unique] = occurrence
        ids = sorted({o["paper_id"] for o in occurrences})
        independent = sorted({_paper_root(p) for p in ids})
        group = sorted({_paper_root(p) for p in ids if papers[p]["target_group_membership"] == "target_group"})
        external = sorted({_paper_root(p) for p in ids if papers[p]["target_group_membership"] == "external"})
        unknown = sorted({_paper_root(p) for p in ids if papers[p]["target_group_membership"] == "unknown"})
        phrases.append({**candidate, "occurrence_count": len(occurrences), "paper_ids": ids,
            "independent_paper_ids": independent, "independent_paper_count": len(independent),
            "target_group_paper_count": len(group), "target_group_paper_ids": group,
            "external_paper_count": len(external), "external_paper_ids": external,
            "unknown_attribution_paper_ids": unknown, "literal_shared_ge3": len(independent) >= 3,
            "target_group_shared_ge3": len(group) >= 3, "occurrences": occurrences,
            "semantic_suitability": "not_certified", "human_approval": "not_certified", "admission_status": "audit_only"})
    shared = [p for p in phrases if p["literal_shared_ge3"]]
    summary = {"candidate_term_phrase_count": len(phrases), "distinct_concept_count": len({p["normalized_term"] for p in phrases}),
        "distinct_literal_phrase_count": len({p["normalized_phrase"] for p in phrases}),
        "literal_shared_ge3_term_phrase_count": len(shared),
        "literal_shared_ge3_distinct_phrase_count": len({p["normalized_phrase"] for p in shared}),
        "literal_shared_ge3_concept_count": len({p["normalized_term"] for p in shared}),
        "target_group_shared_ge3_term_phrase_count": sum(p["target_group_shared_ge3"] for p in phrases),
        "threshold_15_literal_shared_phrases_met": len({p["normalized_phrase"] for p in shared}) >= 15,
        "independent_corpus_paper_count": len({_paper_root(p) for p in papers}), "source_version_count": len(papers),
        "rejected_candidate_record_count": len(rejected), "ignored_pattern_item_count": ignored_patterns,
        "pattern_coverage": "not_audited", "semantic_suitability": "not_certified", "human_approval": "not_certified",
        "active_lexicon_changed": False}
    report = {"schema_version": 1, "audit_type": "literal_shared_phrase_coverage", "summary": summary,
        "matching_policy": {"case": "Unicode casefold, case-insensitive", "whitespace": "runs collapsed to one ASCII space; edges stripped",
            "boundary": "Python Unicode word boundaries: (?<!\\w)literal(?!\\w)",
            "scope": "Each supplied source unit's comment-free, offset-preserving projection; no matching across unit boundaries",
            "excluded_transforms": ["stemming", "plural expansion", "hyphen normalization", "LaTeX stripping", "synonyms"],
            "independence": "Modern and legacy arxiv_ paper version IDs collapse to one arXiv root; other paper IDs unchanged",
            "occurrence_deduplication": "Repeated includes count once per physical source span; logical unit instance IDs retained"},
        "target_group": {"explicit_author": target_author, "membership_basis": "Exact casefold author name in actual metadata authors list; missing authors remain unknown",
            "interpretation": "Explicitly chosen coauthor group for this audit; no claim about an individual's stylistic habit"},
        "verification": {"raw_unit_hashes_checked": True, "prose_hashes_checked": True, "raw_offsets_and_lines_checked": True,
            "candidate_examples_rechecked": True, "source_files_immutable": True,
            "inventory_hashes_checked": all("inventory_hash" in inv for inv in inventories)},
        "canonical_merged_shared": _canonical(canonical_shared_path), "papers": list(papers.values()),
        "input_files": input_files, "phrases": phrases, "rejected_candidates": rejected,
        "limitations": ["Occurrence counts do not certify semantic suitability, writing preference, human approval, or active admission.",
            "Concepts, literal phrases, and patterns are different objects; patterns are excluded from phrase coverage.",
            "Coverage applies only to supplied checked units, not unparsed source regions."]}
    if output_dir is not None:
        output = Path(output_dir)
        # Refuse output destinations inside any source or extraction directory.
        protected = [Path(inv["root"]).resolve() for inv in inventories] + [Path(p).resolve() for p in raw_dirs]
        if any(output.resolve().is_relative_to(p) for p in protected):
            raise ValueError("Audit output must be outside immutable source/extraction directories")
        save(output / "report.json", report)
        lines = ["# Literal shared-phrase audit", "", f"{len(shared)} term/phrase candidates ({summary['literal_shared_ge3_distinct_phrase_count']} distinct literal phrases) occur in at least three independent papers.",
            f"15-phrase literal coverage threshold met: {summary['threshold_15_literal_shared_phrases_met']}.",
            f"Target-group shared candidates: {summary['target_group_shared_ge3_term_phrase_count']}; explicit author: {target_author or 'unspecified'}.",
            f"Existing canonical merged shared count: {report['canonical_merged_shared']['shared_term_phrase_count']} (None means not checked).", "",
            "Unicode casefold matching; whitespace collapsed; strict word boundaries. No stemming, plural/hyphen/LaTeX normalization, or synonyms. Comments excluded. ArXiv versions count once.", "",
            "Occurrence is not semantic suitability, human approval, personal style attribution, or active lexicon admission. Patterns are not audited.", "",
            "| Concept | Phrase | Independent papers | Target group | External |", "|---|---|---:|---:|---:|"]
        for p in phrases:
            escape = lambda value: str(value).replace("|", "\\|").replace("\n", " ")
            lines.append(f"| {escape(p['term'])} | {escape(p['phrase'])} | {p['independent_paper_count']} | {p['target_group_paper_count']} | {p['external_paper_count']} |")
        (output / "report.md").write_text("\n".join(lines) + "\n")
    return report
