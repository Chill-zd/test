"""Coverage and review artifacts. This module never grants human approval."""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import json,yaml
from .inventory import MAIN_TYPES,check_sources,section_key,digest,save,load
from .render import unit_markdown,section_markdown,context_markdown
from .delivery import _read_bound


def analysis_home(analysis_dir,inventory,section):
    root=Path(analysis_dir);candidates=[root/inventory['paper_id']/section_key(section),root/section_key(section)]
    existing=[p for p in candidates if (p/'analysis.json').exists() or list(p.glob('batch_*.json'))]
    if len(existing)>1 and existing[0]!=existing[1]:raise ValueError('Ambiguous analysis directories for '+section['section_id'])
    return existing[0] if existing else candidates[0]


def current_analysis(analysis_dir,inventory,section,analysis_paths=None):
    if analysis_paths is not None:
        path=analysis_paths.get((inventory['inventory_hash'],section['section_id']))
        if path is None:return None,Path(analysis_dir or '.')/section_key(section)
        path=Path(path);home=path.parent
        from .delivery import _check_analysis
        result=load(path);_check_analysis(result,inventory)
        if result['section_id']!=section['section_id']:raise ValueError('Explicit analysis belongs to another section')
        return result,home
    home=analysis_home(analysis_dir,inventory,section);path=home/'analysis.json'
    if not path.exists():return None,home
    result=load(path)
    if result.get('inventory_hash')!=inventory['inventory_hash']:return None,home
    if result.get('review_status')!='machine_proposed' or result.get('semantic_status')!='pending_human':raise ValueError('Machine artifacts cannot claim human approval: '+str(path))
    if result.get('context_provenance'):
        from .delivery import _context_payload
        _context_payload(result,inventory)
    return result,home


def coverage(inventories,analysis_dir,output_dir=None,analysis_paths=None,partial_batches=None):
    rows=[];types={kind:{'section_type':kind,'actual_sections':0,'machine_analyzed_sections':0,'source_units':0,'prose_fragments':0,'insertion_objects':0,'source_metadata':0,'human_approved':0} for kind in (*MAIN_TYPES,'appendix','unknown')};units=[]
    for inventory in inventories:
        check_sources(inventory)
        for section in inventory['sections']:
            result,home=current_analysis(analysis_dir,inventory,section,analysis_paths);batches=[_read_bound(b) for b in (partial_batches or {}).get((inventory['inventory_hash'],section['section_id']),[])] if analysis_paths is not None else [load(p) for p in sorted(home.glob('batch_*.json')) if load(p).get('inventory_hash')==inventory['inventory_hash']]
            status=result['status'] if result else 'partial' if batches else 'not_analyzed'
            direct=[i['item_id'] for i in section['direct_items'] if i['kind']=='unit'];counts=Counter(inventory['units'][uid]['content_kind'] for uid in direct)
            row={'paper_id':inventory['paper_id'],'section_id':section['section_id'],'section_path':section['section_path'],'section_type':section['section_type'],'kind':section['kind'],'logical_order':section['logical_order'],'direct_items':section['direct_items'],'direct_source_units':len(direct),'descendant_source_units':len(section['all_unit_instances']),'prose_fragments':counts['prose_fragment'],'insertion_objects':counts['insertion_object'],'source_metadata':counts['source_metadata'],'child_section_placeholders':len(section['children']),'machine_status':status,'semantic_status':'pending_human' if result or batches else 'not_proposed','human_approval':None,'inventory_hash':inventory['inventory_hash'],'analysis_path':str(Path(analysis_paths[(inventory['inventory_hash'],section['section_id'])]).resolve()) if result and analysis_paths is not None else str(home/'analysis.json') if result else None,'partial_unit_batches':len(batches),'boundary_limitations':inventory['limitations']}
            rows.append(row)
            for uid in direct:
                unit=inventory['units'][uid];state=result.get('unit_states',{}).get(uid,'not_analyzed') if result else 'partial' if any(r['unit_instance_id']==uid for b in batches for r in b['records']) else 'not_analyzed'
                units.append({'paper_id':inventory['paper_id'],'section_id':section['section_id'],'unit_instance_id':uid,'source_id':unit['unit_id'],'content_kind':unit['content_kind'],'machine_status':state,'semantic_status':'not_applicable_source_metadata' if unit['content_kind']=='source_metadata' else 'pending_human' if result else 'not_proposed','file':unit['file'],'line_start':unit['line_start'],'line_end':unit['line_end'],'raw_sha256':unit['sha256'],'projection_sha256':unit['prose_sha256'],'boundary_limitation':unit['boundary_limitation']})
            if section['kind']=='actual_section':
                aggregate=types[section['section_type']];aggregate['actual_sections']+=1;aggregate['machine_analyzed_sections']+=status=='analyzed';aggregate['source_units']+=len(direct)
                for key in ('prose_fragments','insertion_objects','source_metadata'):aggregate[key]+=row[key]
    actual=[r for r in rows if r['kind']=='actual_section'];analyzed=sum(r['machine_status']=='analyzed' for r in actual)
    result={'schema_version':1,'classification':'Machine source/analysis coverage, not semantic approval','sections':rows,'units':units,'types':list(types.values()),'summary':{'papers':len(inventories),'actual_sections':len(actual),'machine_analyzed_sections':analyzed,'machine_analyzed_ratio':analyzed/max(1,len(actual)),'human_approved_sections':0,'total_source_units':len(units),'content_kinds':dict(Counter(u['content_kind'] for u in units)),'missing_main_type_observations':[kind for kind in MAIN_TYPES if not types[kind]['machine_analyzed_sections']],'raw_missing_main_types':[kind for kind in MAIN_TYPES if not types[kind]['actual_sections']]},'interpretation':['Actual-section coverage and eight-type coverage are separate tables.','Source units and parser prose fragments are not certified natural paragraphs.','Pure label metadata is retained and may be skipped as not applicable; it is not a natural paragraph.','Machine analyzed means mechanical source/ordered coverage passed; semantic functions and relationships remain pending human review.']}
    if output_dir:
        directory=Path(output_dir);save(directory/'coverage.json',result)
        lines=['# Real-section coverage','','Machine coverage is separate from human semantic approval.','','| Paper | Real section path | Source units | Prose fragments | Insertions | Metadata | Child slots | Machine status |','|---|---|---:|---:|---:|---:|---:|---|']
        for r in rows:lines.append('| '+' | '.join(str(v).replace('|','\\|').replace('\n',' ') for v in (r['paper_id'],' / '.join(r['section_path']) or '[front matter]',r['direct_source_units'],r['prose_fragments'],r['insertion_objects'],r['source_metadata'],r['child_section_placeholders'],r['machine_status']))+' |')
        lines+=['','## Eight main types (separate from actual-section coverage)','','| Type | Actual sections | Machine analyzed | Human approved |','|---|---:|---:|---:|']
        for kind in MAIN_TYPES:lines.append(f"| {kind} | {types[kind]['actual_sections']} | {types[kind]['machine_analyzed_sections']} | 0 |")
        lines+=['','Missing machine observations: '+', '.join(result['summary']['missing_main_type_observations']),'',*['- '+s for s in result['interpretation']]]
        (directory/'coverage.md').write_text('\n'.join(lines)+'\n')
    return result


def text_metadata(value):return value if isinstance(value,str) else json.dumps(value,ensure_ascii=False)

def review_pack(inventories,analysis_dir,output_dir,target_author=None,phrase_audit=None,atomic_sidecar_paths=None,analysis_paths=None,partial_batches=None):
    report=coverage(inventories,analysis_dir,analysis_paths=analysis_paths,partial_batches=partial_batches);observations=[]
    for inventory in inventories:
        for section in inventory['sections']:
            result,home=current_analysis(analysis_dir,inventory,section,analysis_paths)
            if result and result.get('section_observation'):observations.append((inventory,section,result))
    phrase_report=load(phrase_audit) if phrase_audit else None
    sidecars=[]
    if atomic_sidecar_paths:
        from .atomic_sidecar import verify,binding
        for path in atomic_sidecar_paths:
            value=verify(path)
            if value['inventory_hash'] not in {i['inventory_hash'] for i in inventories}:raise ValueError('Atomic sidecar is not from a reviewed inventory')
            matching=[r for inv,section,r in observations if inv['inventory_hash']==value['inventory_hash'] and section['section_id']==value['model_view']['source_object']['section_id']]
            if len(matching)!=1 or digest(matching[0])!=digest(load(value['analysis']['path'])):raise ValueError('Atomic sidecar is not bound to the exact reviewed analysis')
            sidecars.append({'binding':binding(path),'value':value})
    fingerprint_data={'phrase_audit':digest(phrase_report) if phrase_report else None,'inventories':[i['inventory_hash'] for i in inventories],'analyses':[digest(r) for _,_,r in observations],'target_author':target_author}
    if analysis_paths is not None:
        from .delivery import _binding
        fingerprint_data['explicit_analyses']=[{'inventory_hash':key[0],'section_id':key[1],**_binding(path)} for key,path in sorted(analysis_paths.items())]
    if partial_batches:fingerprint_data['partial_batches']=[{'inventory_hash':k[0],'section_id':k[1],'bindings':v} for k,v in sorted(partial_batches.items())]
    if sidecars:fingerprint_data['atomic_sidecars']=[row['binding'] for row in sidecars]
    fingerprint=digest(fingerprint_data)
    directory=Path(output_dir)/fingerprint[:20];directory.mkdir(parents=True,exist_ok=True);coverage(inventories,analysis_dir,directory,analysis_paths=analysis_paths,partial_batches=partial_batches)
    cards={};decisions={'packet_fingerprint':fingerprint,'human_name':None,'reviewed_at':None,'overall_decision':None,'section_decisions':{},'unit_decisions':{},'function_decisions':{},'phrase_decisions':{},'instructions':'Human only: approve / revise / reject / single_source_reference, with comments/date/signature. Machine output does not grant approval.'}
    for inventory in inventories:
        paper=directory/'sources'/inventory['paper_id'];paper.mkdir(parents=True,exist_ok=True)
        for section in inventory['sections']:
            result,home=current_analysis(analysis_dir,inventory,section,analysis_paths);key=section_key(section)
            partial=[_read_bound(b) for b in (partial_batches or {}).get((inventory['inventory_hash'],section['section_id']),[])]
            source={'paper_id':inventory['paper_id'],'authorship':inventory['metadata'],'section':section,'inventory_hash':inventory['inventory_hash'],'units':[inventory['units'][uid] for uid in section['all_unit_instances']],'machine_analysis':result,'partial_unit_batches':partial,'partial_batch_bindings':(partial_batches or {}).get((inventory['inventory_hash'],section['section_id']),[]),'source_warning':'Raw text preserves comments for provenance only; only prose_text is author-prose evidence. This snapshot is for human inspection, never a prompt input.'};save(paper/(key+'.json'),source)
            lines=['# '+('/'.join(section['section_path']) or '[front matter]'),'',f"Source: `{inventory['paper_id']}`; status: `{result['status'] if result else 'partial_units_only' if partial else 'not_analyzed'}`; human approval: pending.",'', 'Authorship metadata: '+json.dumps(inventory['metadata'],ensure_ascii=False),'','Original source projections follow in logical order. These are source units, not certified natural paragraphs. Raw/hash snapshot: `'+key+'.json`.','']
            if result and result.get('context_provenance'):
                from .delivery import _context_payload
                context=_context_payload(result,inventory)
                save(paper/(key+'_context.json'),{'provenance':result['context_provenance'],'complete_bound_context_artifacts':context})
                context_lines=['# Complete bound context for '+('/'.join(section['section_path']) or '[front matter]'),'','All semantic interpretations remain pending human review. SRC denotes a direct source statement, not verified scientific truth; INF remains an interpretation supported by cited SRC entries; UNK does not establish absence in the paper.','',*context_markdown(result['context_provenance'],2,'Exact contextual source bindings'),*context_markdown(context,2,'Complete source ledger, prior summaries and reference dependencies')]
                (paper/(key+'_context.md')).write_text('\n'.join(context_lines)+'\n')
                lines+=['## Prior-reader context and source dependencies','',f'[Complete readable SRC / INF / UNK context and source dependencies]({key}_context.md)',f'[Exact complete context snapshot]({key}_context.json)','','The reading tasks below must be assessed against these source-bound prior commitments; no missing entry is evidence that the article omitted the information.','']
            if partial:lines+=['## Partial unit batches only','','No completed section observation exists. These source-bound unit proposals do not establish a whole-section map or complete contextual synthesis. Semantic status remains pending human.','']
            for uid in section['all_unit_instances']:
                u=inventory['units'][uid];records=[r for r in result['units'] if r['unit_instance_id']==uid] if result else [r for b in partial for r in b['records'] if r['unit_instance_id']==uid]
                lines+=unit_markdown(u,records)
            if result and result.get('section_observation'):lines+=section_markdown(result['section_observation'])
            else:lines+=['No completed current-source section observation exists. This section is missing; no schema card is fabricated.','']
            lines+=['## Audit links','',f'[Raw source/hash and machine result JSON]({key}.json)','']
            (paper/(key+'.md')).write_text('\n'.join(lines))
    for inventory,section,result in observations:
        sid=section['section_id'];meta=inventory['metadata'];authors=meta.get('authors');authors=authors if isinstance(authors,list) else []
        observation=result['section_observation'];kind=section['section_type'];cards.setdefault(kind,[]).append({'paper_id':inventory['paper_id'],'section_id':sid,'section_path':section['section_path'],'authors':authors,'group_attribution':meta.get('group_attribution'),'author_group':meta.get('author_group'),'source_tag':meta.get('source_tag'),'target_author_listed':None if target_author is None else target_author in authors,'observation':observation})
        decisions['section_decisions'][sid]={'decision':None,'comments':'','reviewed_at':None,'signature':None}
        for row in result['units']:decisions['unit_decisions'][row['chunk_id']]={'decision':None,'comments':'','reviewed_at':None,'signature':None}
        for item in observation['observations']:decisions['function_decisions'][sid+':'+item['observation_id']]={'decision':None,'comments':'','reviewed_at':None,'signature':None}
    sidecar_links=[]
    for row in sidecars:
        value=row['value'];sid=value['sidecar_id'];home=directory/'atomic_sidecars'/sid[:20];home.mkdir(parents=True,exist_ok=True)
        save(home/'atomic_sidecar.json',value)
        lines=['# Mechanical atomic source sidecar — separate from original semantic completion','','Original observations and fragment maps are unchanged. Mechanical source coverage does not complete semantic analysis, verify scientific content, approve a schema or establish M8 acceptance.','',*context_markdown(row['binding'],2,'Exact sidecar binding'),*context_markdown(value['model_view'],2,'Model-visible complete source and unchanged observations'),'## Human-only original raw source','','```latex',value['human_source']['raw_text'],'```','']
        (home/'review.md').write_text('\n'.join(lines)+'\n')
        sidecar_links.append(f'- [{sid[:20]} — source coverage only, original fragment map remains incomplete](atomic_sidecars/{sid[:20]}/review.md)')
    card_dir=directory/'type_cards';card_dir.mkdir(exist_ok=True)
    for kind,sources in cards.items():
        papers=sorted({s['paper_id'] for s in sources});external=target_author is not None and all(s['target_author_listed'] is False for s in sources)
        card={'section_type':kind,'review_status':'machine_proposed','human_approval':None,'source_scope':'single_source' if len(papers)==1 else 'multiple_source_observations','authorship_scope':'external_author_only' if external else 'target_author_evidence_present' if target_author is not None else 'not_evaluated','source_papers':papers,'sources':sources,'applicability':'Only source-specific observations are established; relevance and generalization require human review.','limitations':['Literal quote validation and complete ordered coverage do not establish semantic correctness.','No universal function order, mandatory function or independent-author-group stability is inferred.'],'counterexample_status':'Not examined; no counterexamples invented.'};save(card_dir/(kind+'.json'),card)
        card_lines=['# '+kind,'',f"Review status: `{card['review_status']}`; human approval: pending; source scope: `{card['source_scope']}`; attribution scope: `{card['authorship_scope']}`.",'',card['applicability'],'',*['- '+v for v in card['limitations']],'',card['counterexample_status'],'']
        for source in sources:
            observed_section=next(s for inv in inventories if inv['paper_id']==source['paper_id'] for s in inv['sections'] if s['section_id']==source['section_id'])
            card_lines += ['## '+source['paper_id'],'',f"Authors: {', '.join(source['authors'])}",'Group attribution: '+text_metadata(source.get('group_attribution')),'',f"[Full source units and paragraph observations](../sources/{source['paper_id']}/{section_key(observed_section)}.md)",'',*section_markdown(source['observation'])]
        (card_dir/(kind+'.md')).write_text('\n'.join(card_lines)+'\n')
    if phrase_report:
        import shutil
        save(directory/'phrase_coverage/report.json',phrase_report)
        markdown=Path(phrase_audit).with_suffix('.md')
        if markdown.exists():shutil.copyfile(markdown,directory/'phrase_coverage/report.md')
        for phrase in phrase_report['phrases']:
            phrase_id=digest({'term':phrase['normalized_term'],'phrase':phrase['normalized_phrase']})
            decisions['phrase_decisions'][phrase_id]={'term':phrase['term'],'phrase':phrase['phrase'],'decision':None,'semantic_fit':None,'comments':'','reviewed_at':None,'signature':None}
    if not (directory/'human_decisions.yaml').exists():(directory/'human_decisions.yaml').write_text(yaml.safe_dump(decisions,sort_keys=False,allow_unicode=True))
    manifest={'packet_directory':str(directory),'packet_fingerprint':fingerprint,'type_cards_present':sorted(cards),'missing_main_type_cards':[t for t in MAIN_TYPES if t not in cards],'missing_auxiliary_type_cards':[t for t in ('appendix','unknown') if t not in cards],'source_sections_with_observations':len(observations),'human_approval':'pending','no_automatic_approval':True,'atomic_sidecars':[row['binding'] for row in sidecars]};save(directory/'manifest.json',manifest)
    lines=['# Paragraph and real-section human review','','**Human approved: 0. Machine proposals are not accepted writing rules.**','',f"Actual sections machine analyzed: {report['summary']['machine_analyzed_sections']}/{report['summary']['actual_sections']}.",'','Missing main-type cards: '+', '.join(manifest['missing_main_type_cards']),'Missing auxiliary cards: '+', '.join(manifest['missing_auxiliary_type_cards']),'','[Full actual-section and eight-type coverage](coverage.md) · [Empty human decisions](human_decisions.yaml) · [Machine manifest](manifest.json)','','## Type observations','']
    lines += [f'- [{kind}](type_cards/{kind}.md)' for kind in sorted(cards)]
    if sidecar_links:lines+=['','## Optional atomic sidecars — pending human, original partial status unchanged','',*sidecar_links]
    if phrase_report:lines+=['','## Shared phrase coverage audit','','[Literal candidate coverage](phrase_coverage/report.md) · [Every span/provenance record](phrase_coverage/report.json)','','These are literal occurrence candidates, not semantic approval or canonical admission. Concept and pattern counts remain separate.']
    lines += ['','## Every actual source section','']
    for inv in inventories:
        for section in inv['sections']:lines.append(f"- [{inv['paper_id']} / {' / '.join(section['section_path']) or '[front matter]'}](sources/{inv['paper_id']}/{section_key(section)}.md)")
    (directory/'index.md').write_text('\n'.join(lines)+'\n')
    manifest['index']=str(directory/'index.md');save(directory/'manifest.json',manifest);save(Path(output_dir)/'latest_packet.json',manifest);return manifest
