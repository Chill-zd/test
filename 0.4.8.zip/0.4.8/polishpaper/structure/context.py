"""V2 source-only context scan and temporally filtered SRC/INF/UNK ledger.

Source statements are not verified scientific truths. Interpretation remains
pending human review; a selected ledger's absence is never source absence.
"""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import json
from .inventory import digest,save,load,check_sources,public_unit
from .contracts import QUOTE,contract,bind_quote,StructureValidationError
from .extract import cached_call,StructureInputBudget

SCAN_PROMPT=Path(__file__).parents[1]/'prompts/context_scan.md'
ENTRY={'type':'object','required':['entry_id','category','epistemic_status','statement','evidence','condition_evidence','attribution','limitations'],'properties':{'entry_id':{'type':'string','minLength':1},'category':{'enum':['definition','notation','claim','contribution','open_question']},'epistemic_status':{'const':'SRC'},'statement':{'type':'string','minLength':1},'evidence':{'type':'array','minItems':1,'items':QUOTE},'condition_evidence':{'type':'array','items':QUOTE},'attribution':{'type':'string','minLength':1},'limitations':{'type':'array','items':{'type':'string'}}},'additionalProperties':False}
SUMMARY={'type':'object','required':['section_id','epistemic_status','task','commitments','unresolved','depends_on_src_ids','evidence','missing_information'],'properties':{'section_id':{'type':'string'},'epistemic_status':{'enum':['INF','UNK']},'task':{'type':'string'},'commitments':{'type':'array','items':{'type':'string'}},'unresolved':{'type':'array','items':{'type':'string'}},'depends_on_src_ids':{'type':'array','items':{'type':'string'}},'evidence':{'type':'array','items':QUOTE},'missing_information':{'type':'string'}},'additionalProperties':False}
SCAN_SCHEMA={'type':'object','required':['review_status','coverage','entries','section_summaries','limitations'],'properties':{'review_status':{'const':'machine_proposed'},'coverage':{'const':'selected_not_exhaustive'},'entries':{'type':'array','items':ENTRY},'section_summaries':{'type':'array','items':SUMMARY},'limitations':{'type':'array','items':{'type':'string'}}},'additionalProperties':False}


def source_stream(inventory):
    byid={s['section_id']:s for s in inventory['sections']};stream=[]
    def visit(section):
        if section['kind']=='actual_section':stream.append({'kind':'section_heading','section_id':section['section_id'],'section_path':section['section_path'],'section_type':section['section_type'],'title':section['title']})
        for item in section['direct_items']:
            if item['kind']=='child_section':visit(byid[item['item_id']])
            else:
                unit=inventory['units'][item['item_id']]
                stream.append({'kind':'source_unit','unit_instance_id':unit['instance_id'],'source_id':unit['unit_id'],'logical_order':unit['logical_order'],'content_kind':unit['content_kind'],'section_id':unit['section_id'],'file':unit['file'],'line_start':unit['line_start'],'line_end':unit['line_end'],'raw_sha256':unit['sha256'],'projection_sha256':unit['prose_sha256'],'text':unit['prose_text']})
    for section in inventory['sections']:
        if section['parent_id'] is None:visit(section)
    if [row['unit_instance_id'] for row in stream if row['kind']=='source_unit']!=list(inventory['units']):raise ValueError('Whole-paper source stream lost/reordered source units')
    return stream


def scan_messages(inventory,summary_section_ids=None):
    requested=list(summary_section_ids) if summary_section_ids is not None else [s['section_id'] for s in inventory['sections'] if s['kind']=='actual_section' and s['parent_id'] is None]
    sections={s['section_id']:s for s in inventory['sections']}
    if len(set(requested))!=len(requested) or not set(requested)<=set(sections):raise ValueError('Invalid requested summary section IDs')
    packet={'paper_id':inventory['paper_id'],'inventory_hash':inventory['inventory_hash'],'authorship':inventory['metadata'],'input_scope':'Every parsed body source unit and actual heading in complete logical include order; comment-free, no source-unit truncation. Preamble configuration is not published body prose.','source_coverage':'complete_supplied_paper','ledger_selection':'selected_not_exhaustive','full_logical_source':source_stream(inventory),'requested_section_summary_ids':requested,'preservation_object_map':[{'object_id':oid,'file':obj['file'],'offset_start':obj['offset_start'],'offset_end':obj['offset_end'],'complete':obj.get('complete',False),'covered_unit_instance_ids':obj.get('covered_unit_instance_ids',[])} for oid,obj in inventory.get('objects',{}).items()],'output_json_schema':SCAN_SCHEMA}
    return [{'role':'system','content':SCAN_PROMPT.read_text()},{'role':'user','content':json.dumps(packet,ensure_ascii=False)}],requested


def prepare_scan(inventory,max_input_chars=1000000,summary_section_ids=None):
    check_sources(inventory);messages,requested=scan_messages(inventory,summary_section_ids);chars=sum(len(m['content']) for m in messages)
    return {'paper_id':inventory['paper_id'],'inventory_hash':inventory['inventory_hash'],'source_units':len(inventory['units']),'requested_summary_section_ids':requested,'input_chars':chars,'max_input_chars':max_input_chars,'within_budget':chars<=max_input_chars,'source_units_omitted':0,'source_truncated':False,'ledger_coverage':'selected_not_exhaustive','model_calls_dispatched':0,'messages':messages}


def quote_position(quote,inventory):
    uid=quote['unit_instance_id'];unit=inventory['units'].get(uid) or inventory.get('objects',{}).get(uid)
    if unit is None:raise StructureValidationError('Unknown quote position')
    return (unit['logical_order'],quote['end'])


def validate_scan(value,inventory,requested,scan_id):
    contract(value,SCAN_SCHEMA);allowed=set(inventory['units']);entries=[];ids={};sections={s['section_id']:s for s in inventory['sections']}
    for index,entry in enumerate(value['entries']):
        if entry['entry_id'] in ids:raise StructureValidationError('Duplicate source-ledger entry ID')
        qualified='SRC:'+scan_id[:16]+':'+entry['entry_id'];ids[entry['entry_id']]=qualified
        evidence=[bind_quote(q,inventory,allowed) for q in entry['evidence']];conditions=[bind_quote(q,inventory,allowed) for q in entry['condition_evidence']]
        established=max(quote_position(q,inventory) for q in evidence+conditions)
        entries.append({**entry,'entry_id':qualified,'original_entry_id':entry['entry_id'],'evidence':evidence,'condition_evidence':conditions,'established_position':list(established),'model_entry_order':index,'truth_status':'direct_source_statement_not_verified_scientific_truth','semantic_status':'pending_human'})
    if [s['section_id'] for s in value['section_summaries']]!=requested:raise StructureValidationError('Missing/duplicate/reordered requested section summary cards')
    summaries=[]
    for summary in value['section_summaries']:
        if summary['epistemic_status']=='INF' and (not summary['depends_on_src_ids'] or not summary['evidence']):raise StructureValidationError('INF section summary requires SRC dependencies and source evidence')
        if summary['epistemic_status']=='UNK' and not summary['missing_information'].strip():raise StructureValidationError('UNK section summary requires missing-information explanation')
        if not set(summary['depends_on_src_ids'])<=set(ids):raise StructureValidationError('Section summary depends on nonexistent SRC entry')
        node=sections[summary['section_id']];evidence=[bind_quote(q,inventory,set(node['all_unit_instances'])) for q in summary['evidence']]
        summaries.append({**summary,'depends_on_src_ids':[ids[i] for i in summary['depends_on_src_ids']],'evidence':evidence,'semantic_status':'pending_human','source_scope':'single_source','section_complete_position':max((inventory['units'][uid]['logical_order'] for uid in node['all_unit_instances']),default=-1)})
    return {**value,'entries':entries,'section_summaries':summaries,'paper_id':inventory['paper_id'],'inventory_hash':inventory['inventory_hash'],'scan_id':scan_id,'semantic_status':'pending_human','truth_status':'Source statements and model interpretations are not verified scientific facts.'}


def scan(inventory,client,directory,provider='sonnet',max_input_chars=1000000,summary_section_ids=None,retry_failed=False):
    prepared=prepare_scan(inventory,max_input_chars,summary_section_ids);directory=Path(directory);save(directory/'scan_plan.json',{k:v for k,v in prepared.items() if k!='messages'})
    if not prepared['within_budget']:
        save(directory/'pending_input_budget.json',{k:v for k,v in prepared.items() if k!='messages'})
        raise StructureInputBudget('Complete paper scan exceeds explicit budget; no source trimmed or call dispatched')
    messages=prepared['messages'];scan_id=digest({'inventory_hash':inventory['inventory_hash'],'messages':messages})
    result=cached_call(client,provider,messages,directory,'structure_context_source_scan',lambda value:validate_scan(value,inventory,prepared['requested_summary_section_ids'],scan_id),retry_failed)
    save(directory/'source_ledger.json',result);return result


def prior_context(inventory,ledger,unit_instance_id,chunk_start=0):
    """Only source-established positions before the target can enter prior knowledge."""
    if ledger['inventory_hash']!=inventory['inventory_hash']:raise ValueError('Source ledger belongs to another inventory version')
    unit=inventory['units'][unit_instance_id];cutoff=(unit['logical_order'],chunk_start)
    entries=[e for e in ledger['entries'] if tuple(e['established_position'])<=cutoff]
    known={e['entry_id'] for e in entries};summaries=[s for s in ledger['section_summaries'] if s['section_complete_position']<unit['logical_order'] and set(s['depends_on_src_ids'])<=known]
    return {'ledger_coverage':'selected_not_exhaustive','absence_policy':'No ledger entry means not supplied by this selected ledger, never that the preceding paper did not establish it.','target_unit_instance_id':unit_instance_id,'cutoff':list(cutoff),'source_entries':entries,'prior_section_summary_cards':summaries,'semantic_status':'pending_human'}


def artifact_binding(path,kind):
    import hashlib
    path=Path(path).resolve()
    return {'kind':kind,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def _check_supplemental_assets(bundle,inventory=None):
    """Follow typed original/render bindings; old bundles need no asset envelope."""
    import hashlib
    if 'supplemental_source_provenance' not in bundle:return
    provenance=bundle['supplemental_source_provenance']
    if not isinstance(provenance,dict) or not isinstance(provenance.get('assets'),list):
        raise ValueError('Malformed supplemental source asset provenance')
    for asset in provenance['assets']:
        if not isinstance(asset,dict) or not isinstance(asset.get('file'),dict):
            raise ValueError('Malformed original supplemental asset binding')
        rendered={'rendered_image','rendered_image_path','render_locator'}
        if rendered & set(asset) and (not rendered<=set(asset) or not isinstance(asset.get('rendered_image_path'),str)
                or not isinstance(asset.get('render_locator'),(str,dict)) or not asset['render_locator']):
            raise ValueError('Malformed supplemental render binding/locator')
        bindings=[asset['file']]
        if rendered<=set(asset):
            bindings.append(asset['rendered_image'])
            if not isinstance(asset['rendered_image'],dict) or asset['rendered_image'].get('path')!=str(Path(asset['rendered_image_path']).resolve()):
                raise ValueError('Supplemental render path differs from its exact binding')
        if inventory is not None:
            root=Path(inventory['root']).resolve()
            relative=asset.get('relative_path')
            if not isinstance(relative,str):raise ValueError('Supplemental asset lacks original relative path')
            original=(root/relative).resolve()
            if not original.is_relative_to(root) or asset['file'].get('path')!=str(original):
                raise ValueError('Supplemental original asset escapes/differs from inventory source root')
        for binding in bindings:
            if not isinstance(binding,dict) or not isinstance(binding.get('path'),str) or not isinstance(binding.get('sha256'),str):
                raise ValueError('Malformed supplemental asset file binding')
            path=Path(binding['path'])
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=binding['sha256']:
                raise ValueError('Supplemental source asset changed or missing: '+str(path))


def assert_context_fresh(provenance,inventory):
    """Revalidate exact external context dependencies, not just the analysis JSON."""
    import hashlib
    check_sources(inventory)
    if provenance.get('inventory_hash')!=inventory['inventory_hash']:raise ValueError('Context provenance inventory changed')
    bindings=provenance.get('artifact_bindings',[])
    if not bindings:raise ValueError('Missing bound context artifacts')
    for binding in bindings:
        path=Path(binding['path'])
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=binding['sha256']:raise ValueError('Context artifact changed: '+str(path))
        value=load(path)
        if binding['kind'] in ('source_ledger','context_bundle') and value.get('inventory_hash')!=inventory['inventory_hash']:raise ValueError('Bound context belongs to another source inventory')
        if binding['kind']=='context_bundle':_check_supplemental_assets(value,inventory)
    return True


def load_bound_context(provenance):
    """Lossless bound JSON payloads for downstream writer/reviewer transport."""
    import hashlib
    result={}
    for binding in provenance.get('artifact_bindings',[]):
        path=Path(binding['path'])
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=binding['sha256']:raise ValueError('Context artifact changed: '+str(path))
        value=load(path)
        if binding['kind']=='context_bundle':_check_supplemental_assets(value)
        result[binding['sha256']]={**binding,'content':value}
    return result
