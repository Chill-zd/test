from __future__ import annotations
import hashlib,json,re
from pathlib import Path
from ..corpus.parser import parse_events

MAIN_TYPES=('introduction','related_work','preliminaries','model_setup','theory','algorithm','experiments','conclusion')
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def load(path):return json.loads(Path(path).read_text())

def build(main,paper_id,root=None,metadata=None):
    root=Path(root or Path(main).parent).resolve();events=parse_events(main,paper_id,root);sections=[];units={};stack=[];occurrences={};files={}
    front={'section_id':paper_id+':front_matter','title':'Front matter','section_path':[],'section_type':'unknown','level':0,'kind':'front_matter','parent_id':None,'direct_items':[],'children':[],'logical_order':0}
    sections.append(front)
    for event in events:
        file=event['file'] if event['kind']=='section' else event['unit']['file']
        files[file]=hashlib.sha256((root/file).read_bytes()).hexdigest()
        if event['kind']=='section':
            while stack and stack[-1]['level']>=event['level']:stack.pop()
            base=f"{paper_id}:section:{event['file']}:{event['offset_start']}:{event['sha256'][:12]}";occurrences[base]=occurrences.get(base,0)+1
            sid=base if occurrences[base]==1 else base+':occurrence:'+str(occurrences[base])
            parent=stack[-1] if stack else None
            section={**event,'kind':'actual_section','section_id':sid,'parent_id':parent['section_id'] if parent else None,'direct_items':[],'children':[],'logical_order':len(sections)}
            if parent:
                parent['children'].append(sid);parent['direct_items'].append({'kind':'child_section','item_id':sid})
            sections.append(section);stack.append(section)
        else:
            section=stack[-1] if stack else front;unit=event['unit'];instance=f"{section['section_id']}:unit:{len(section['direct_items'])+1}"
            units[instance]={**unit,'instance_id':instance,'section_id':section['section_id'],'logical_order':len(units),'content_kind':'source_metadata' if re.fullmatch(r'(?:\\label\s*\{[^{}]*\}\s*)+',unit['prose_text'].strip()) else 'prose_fragment' if unit['env_kind'] is None else 'insertion_object','boundary_limitation':'Parser source unit, not certified natural paragraph; blank lines, includes and atomic objects can split or join rhetorical paragraphs.'}
            section['direct_items'].append({'kind':'unit','item_id':instance})
    byid={s['section_id']:s for s in sections}
    def collect(section):
        return [uid for item in section['direct_items'] for uid in ([item['item_id']] if item['kind']=='unit' else collect(byid[item['item_id']]))]
    for section in sections:
        section['all_unit_instances']=collect(section)
        direct=[i['item_id'] for i in section['direct_items'] if i['kind']=='unit']
        for index,uid in enumerate(direct):
            units[uid]['adjacent_direct_units']={'before':direct[index-1] if index else None,'after':direct[index+1] if index+1<len(direct) else None}
    inventory={'schema_version':1,'paper_id':paper_id,'root':str(root),'main':str(Path(main).resolve().relative_to(root)),'metadata':metadata or {},'source_files':files,'sections':sections,'units':units,'limitations':['Logical source order follows input/include expansion.','Prose fragments are parser units; natural-paragraph boundaries and semantic labels require review.','Insertion objects retain scientific source but are not interpreted as natural paragraphs.']}
    inventory['inventory_hash']=digest({k:v for k,v in inventory.items() if k not in ('root','inventory_hash')})
    return inventory

def check_sources(inventory):
    if digest({k:v for k,v in inventory.items() if k not in ('root','inventory_hash')})!=inventory['inventory_hash']:raise ValueError('Inventory fingerprint changed')
    for relative,expected in inventory['source_files'].items():
        path=(Path(inventory['root'])/relative).resolve()
        if not path.is_relative_to(Path(inventory['root']).resolve()) or not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise ValueError('Inventory source changed: '+relative)

def select(inventory,selector):
    matches=[s for s in inventory['sections'] if s['section_id']==selector or '/'.join(s['section_path'])==selector]
    if len(matches)!=1:raise ValueError(f'Expected one exact section ID or full path; found {len(matches)}')
    return matches[0]

def public_unit(unit):
    return {k:unit[k] for k in ('instance_id','unit_id','file','line_start','line_end','offset_start','offset_end','sha256','prose_sha256','prose_text','content_kind','env_kind','boundary_limitation','section_id')}

def section_key(section):return hashlib.sha256(section['section_id'].encode()).hexdigest()[:20]

def chunk_unit(unit,max_chars):
    text=unit['prose_text'];parts=[];start=0
    while start<len(text):
        end=min(len(text),start+max_chars)
        if end<len(text):
            split=max(text.rfind('\n',start+max_chars//2,end),text.rfind(' ',start+max_chars//2,end))
            if split>start:end=split+1
        parts.append({'chunk_id':unit['instance_id']+':chunk:'+str(len(parts)+1),'unit_instance_id':unit['instance_id'],'start':start,'end':end,'text':text[start:end],'content_kind':unit['content_kind'],'split_limitation':'Budget chunk; not asserted to be a rhetorical or sentence boundary.' if start or end<len(text) else unit['boundary_limitation']});start=end
    return parts
