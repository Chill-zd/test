"""Mechanical source/coverage checks; semantic judgments remain pending human review."""
from __future__ import annotations
import hashlib
from jsonschema import Draft202012Validator

STATUSES=('analyzed','partial','unresolved','skipped')
QUOTE={'type':'object','required':['unit_instance_id','text'],'properties':{'unit_instance_id':{'type':'string'},'text':{'type':'string','minLength':1},'start':{'type':'integer','minimum':0},'end':{'type':'integer','minimum':1}},'additionalProperties':False}
EVIDENCE={'type':'array','items':QUOTE}
OBS={'type':'object','required':['observation','evidence'],'properties':{'observation':{'type':'string','minLength':1},'evidence':EVIDENCE},'additionalProperties':False}
SLOT={'type':'object','required':['kind','evidence','preserve'],'properties':{'kind':{'type':'string'},'evidence':QUOTE,'preserve':{'type':'string','minLength':1}},'additionalProperties':False}
SEGMENT={'type':'object','required':['segment_id','quote','function','advances_from_previous'],'properties':{'segment_id':{'type':'string'},'quote':QUOTE,'function':{'type':'string','minLength':1},'advances_from_previous':{'type':'string','minLength':1}},'additionalProperties':False}
READING_TASK={**OBS,'required':OBS['required']+['reader_before','reader_after'],'properties':{**OBS['properties'],'reader_before':{'type':'string','minLength':1},'reader_after':{'type':'string','minLength':1}}}
UNIT_RECORD={'type':'object','required':['chunk_id','unit_instance_id','status','reading_task','segments','context_links','scientific_slots','limitations','reason'],'properties':{'chunk_id':{'type':'string'},'unit_instance_id':{'type':'string'},'status':{'enum':list(STATUSES)},'reading_task':READING_TASK,'segments':{'type':'array','items':SEGMENT},'context_links':{'type':'object','required':['incoming','outgoing'],'properties':{'incoming':OBS,'outgoing':OBS},'additionalProperties':False},'scientific_slots':{'type':'array','items':SLOT},'limitations':{'type':'array','items':{'type':'string'}},'reason':{'type':'string'}},'additionalProperties':False}
UNIT_SCHEMA={'type':'object','required':['review_status','records'],'properties':{'review_status':{'const':'machine_proposed'},'records':{'type':'array','items':UNIT_RECORD}},'additionalProperties':False}
ITEM={'type':'object','required':['item_id','kind','status','reading_task','evidence'],'properties':{'item_id':{'type':'string'},'kind':{'enum':['unit','child_section']},'status':{'enum':list(STATUSES)},'reading_task':{'type':'string','minLength':1},'evidence':EVIDENCE},'additionalProperties':False}
SECTION_SCHEMA={'type':'object','required':['section_id','review_status','observation_scope','status','section_task','ordered_items','observations','transitions','order_variants','limitations','unresolved'],'properties':{'section_id':{'type':'string'},'review_status':{'const':'machine_proposed'},'observation_scope':{'const':'single_source'},'status':{'enum':list(STATUSES)},'section_task':OBS,'ordered_items':{'type':'array','items':ITEM},'observations':{'type':'array','items':{'type':'object','required':['observation_id','function','concrete_observation','item_ids','evidence','applicability','limitations'],'properties':{'observation_id':{'type':'string'},'function':{'type':'string'},'concrete_observation':{'type':'string','minLength':1},'item_ids':{'type':'array','items':{'type':'string'}},'evidence':EVIDENCE,'applicability':{'type':'string'},'limitations':{'type':'array','items':{'type':'string'}}},'additionalProperties':False}},'transitions':{'type':'array','items':{'type':'object','required':['from_item_id','to_item_id','observation','evidence','status'],'properties':{'from_item_id':{'type':'string'},'to_item_id':{'type':'string'},'observation':{'type':'string'},'evidence':EVIDENCE,'status':{'enum':['observed','unknown','not_applicable']}},'additionalProperties':False}},'order_variants':{'type':'array','items':OBS},'limitations':{'type':'array','items':{'type':'string'}},'unresolved':{'type':'array','items':{'type':'string'}}},'additionalProperties':False}

class StructureValidationError(ValueError):pass

def contract(value,schema):
    errors=list(Draft202012Validator(schema).iter_errors(value))
    if errors:raise StructureValidationError('; '.join('.'.join(map(str,e.path))+': '+e.message for e in errors))

def bind_quote(quote,inventory,allowed=None,cursor=None):
    uid=quote['unit_instance_id']
    if uid not in inventory['units'] or (allowed is not None and uid not in allowed):raise StructureValidationError('Quote refers to an unavailable unit instance')
    unit=inventory['units'][uid];text=unit['prose_text'];needle=quote['text']
    if 'start' in quote or 'end' in quote:
        if not all(k in quote for k in ('start','end')):raise StructureValidationError('Quote offsets require both start and end')
        start,end=quote['start'],quote['end']
        if not 0<=start<end<=len(text) or text[start:end]!=needle:raise StructureValidationError('False quote or offsets')
    elif cursor is not None:
        start=text.find(needle,cursor);end=start+len(needle)
        if start<0:raise StructureValidationError('Segment quote is not a continuous ordered source span')
    else:
        start=text.find(needle);end=start+len(needle)
        if start<0 or text.find(needle,start+1)>=0:raise StructureValidationError('Quote missing or ambiguous; use a unique quote or explicit offsets')
    raw=unit['text'][start:end]
    source={k:unit[k] for k in ('unit_id','file','sha256','prose_sha256','section_id')}
    source.update({'unit_instance_id':uid,'projection_start':start,'projection_end':end,'offset_start':unit['offset_start']+start,'offset_end':unit['offset_start']+end,'line_start':unit['line_start']+unit['text'].count('\n',0,start),'line_end':unit['line_start']+unit['text'].count('\n',0,end-1),'raw_span_sha256':hashlib.sha256(raw.encode()).hexdigest(),'projection_span_sha256':hashlib.sha256(needle.encode()).hexdigest()})
    return {'unit_instance_id':uid,'text':needle,'start':start,'end':end,'source':source}

def bind_observation(observation,inventory,allowed,require=False):
    if require and not observation['evidence']:raise StructureValidationError('Analyzed judgment requires source evidence')
    return {**observation,'evidence':[bind_quote(q,inventory,allowed) for q in observation['evidence']]}

def validate_units(result,chunks,inventory,allowed):
    contract(result,UNIT_SCHEMA)
    if [r['chunk_id'] for r in result['records']]!=[c['chunk_id'] for c in chunks]:raise StructureValidationError('Missing, duplicate or out-of-order unit chunks')
    verified=[]
    for record,chunk in zip(result['records'],chunks):
        uid=chunk['unit_instance_id'];unit=inventory['units'][uid]
        if record['unit_instance_id']!=uid:raise StructureValidationError('Chunk mapped to another unit')
        if record['status']!='analyzed' and not record['reason'].strip():raise StructureValidationError('Partial/unresolved/skipped records require a reason')
        if unit['content_kind']=='insertion_object' and not any('insert' in text.lower() or '插入' in text for text in record['limitations']):raise StructureValidationError('Insertion object must be explicitly marked as such, not a natural paragraph')
        cursor=chunk['start'];segments=[];ids=set()
        for segment in record['segments']:
            if segment['segment_id'] in ids:raise StructureValidationError('Duplicate segment ID')
            ids.add(segment['segment_id'])
            if segment['quote']['unit_instance_id']!=uid:raise StructureValidationError('Functional fragment must quote its own unit')
            quote=bind_quote(segment['quote'],inventory,{uid},cursor=cursor)
            if quote['start']<cursor or quote['end']>chunk['end']:raise StructureValidationError('Overlapping/outside-budget functional fragments')
            if record['status']=='analyzed' and unit['prose_text'][cursor:quote['start']].strip():raise StructureValidationError('Analyzed fragment map leaves uncovered source text')
            cursor=quote['end'];segments.append({**segment,'quote':quote})
        if record['status']=='analyzed' and (not segments or unit['prose_text'][cursor:chunk['end']].strip()):raise StructureValidationError('Analyzed fragment map does not cover the complete source chunk')
        verified.append({**record,'segments':segments,'reading_task':bind_observation(record['reading_task'],inventory,allowed,record['status']=='analyzed'),'context_links':{k:bind_observation(v,inventory,allowed) for k,v in record['context_links'].items()},'scientific_slots':[{**slot,'evidence':bind_quote(slot['evidence'],inventory,{uid})} for slot in record['scientific_slots']]})
    return {'review_status':'machine_proposed','semantic_status':'pending_human','records':verified}

def validate_section(result,section,inventory,unit_states,child_states):
    contract(result,SECTION_SCHEMA)
    if result['section_id']!=section['section_id']:raise StructureValidationError('Wrong real section')
    expected=section['direct_items']
    if [(i['item_id'],i['kind']) for i in result['ordered_items']]!=[(i['item_id'],i['kind']) for i in expected]:raise StructureValidationError('Missing, duplicate, merged or reordered direct unit/child-section placeholders')
    allowed=set(section['all_unit_instances']);item_ids={i['item_id'] for i in expected};items=[]
    for item in result['ordered_items']:
        states=unit_states if item['kind']=='unit' else child_states
        if item['status']=='analyzed' and states.get(item['item_id'])!='analyzed':raise StructureValidationError('Synthesis claims analysis of an incomplete/unresolved item')
        if item['status']=='analyzed' and not item['evidence'] and (item['kind']=='unit' or inventory['units'] and allowed):raise StructureValidationError('Analyzed item requires evidence')
        items.append({**item,'evidence':[bind_quote(q,inventory,allowed) for q in item['evidence']]})
    if result['status']=='analyzed' and any(i['status']!='analyzed' and not (i['kind']=='unit' and inventory['units'][i['item_id']]['content_kind']=='source_metadata' and i['status']=='skipped') for i in items):raise StructureValidationError('Section claimed analyzed despite incomplete items')
    observations=[]
    for observation in result['observations']:
        if not observation['item_ids'] or not set(observation['item_ids'])<=item_ids or not observation['evidence']:raise StructureValidationError('Section observation lacks supported direct items/evidence')
        observations.append({**observation,'evidence':[bind_quote(q,inventory,allowed) for q in observation['evidence']]})
    expected_pairs=[(expected[i]['item_id'],expected[i+1]['item_id']) for i in range(len(expected)-1)]
    if [(t['from_item_id'],t['to_item_id']) for t in result['transitions']]!=expected_pairs:raise StructureValidationError('Each adjacent direct-item pair requires exactly one ordered transition check, including unknown/not_applicable')
    transitions=[]
    for transition in result['transitions']:
        if transition['from_item_id'] not in item_ids or transition['to_item_id'] not in item_ids:raise StructureValidationError('Transition refers to absent items')
        if transition['status']=='observed' and not transition['evidence']:raise StructureValidationError('Observed transition requires evidence')
        if not transition['observation'].strip():raise StructureValidationError('Every adjacent-pair check requires an explanation, including unknown/not_applicable')
        transitions.append({**transition,'evidence':[bind_quote(q,inventory,allowed) for q in transition['evidence']]})
    return {**result,'section_task':bind_observation(result['section_task'],inventory,allowed,result['status']=='analyzed'),'ordered_items':items,'observations':observations,'transitions':transitions,'order_variants':[bind_observation(v,inventory,allowed) for v in result['order_variants']],'semantic_status':'pending_human'}
