"""Explicit order-only historical replay; never rewrite paid prompts or responses.

Only source_anchors and complete_preservation_objects are lookup collections.
Narrative order, chunks, evidence, INF observations and all source content remain
strictly ordered. A discarded descendant is diagnosed, never treated equivalent.
"""
from __future__ import annotations
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from pathlib import Path
import hashlib,json
from .inventory import digest,load,save

_POLICY=ContextVar('structure_order_migration',default=None)
CORE='polishpaper/structure/contextual.py'


def binding(path):
    path=Path(path).resolve()
    return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def checked(item):
    path=Path(item['path']).resolve()
    if not path.is_file() or binding(path)['sha256']!=item['sha256']:raise ValueError('Order-migration artifact changed: '+str(path))
    return path


def expected_core(old):
    """Only the reviewed deterministic iteration and exact-replay hook are permitted."""
    old=old.replace("own_ids={oid for uid in dependency_units for oid in inventory['units'][uid].get('envelope_refs',[])}", "own_ids=sorted({oid for uid in dependency_units for oid in inventory['units'][uid].get('envelope_refs',[])})")
    old=old.replace("bundle=make_bundle(inventory,ledger,chunks,incremental,neighbor_count);bundle_path=home/'context_bundles'/(bundle['context_bundle_id']+'.json');save(bundle_path,bundle);bindings.append(artifact_binding(bundle_path,'context_bundle'))", "bundle=make_bundle(inventory,ledger,chunks,incremental,neighbor_count)")
    return old.replace("call_messages=messages('paragraph_context_observe.md',packet,UNIT_V2)\n", "call_messages=messages('paragraph_context_observe.md',packet,UNIT_V2)\n        from .order_migration import select_historical\n        call_messages,bundle=select_historical(call_messages,bundle,home,client,provider)\n        bundle_path=home/'context_bundles'/(bundle['context_bundle_id']+'.json')\n        if bundle_path.exists() and load(bundle_path)!=bundle:raise ValueError('Existing exact context bundle differs')\n        if not bundle_path.exists():save(bundle_path,bundle)\n        bindings.append(artifact_binding(bundle_path,'context_bundle'))\n")


def normalized_bundle(bundle):
    value=deepcopy(bundle);bundle_id=value.pop('context_bundle_id')
    if digest(value)!=bundle_id:raise ValueError('Invalid context bundle ID')
    for field,key in [('source_anchors','entry_id'),('complete_preservation_objects','object_id')]:
        ids=[v[key] for v in value[field]]
        if len(ids)!=len(set(ids)):raise ValueError('Duplicate lookup object: '+field)
        value[field]=sorted(value[field],key=lambda v:v[key])
    return value


def normalized_messages(messages):
    if len(messages)!=2 or messages[0]['role']!='system' or messages[1]['role']!='user':raise ValueError('Expected original two-message source request')
    packet=json.loads(messages[1]['content']);context=packet['context'];context=deepcopy(context);context.pop('context_bundle_id')
    for field,key in [('source_anchors','entry_id'),('complete_preservation_objects','object_id')]:
        ids=[v[key] for v in context[field]]
        if len(ids)!=len(set(ids)):raise ValueError('Duplicate compact source lookup')
        context[field]=sorted(context[field],key=lambda v:v[key])
    packet['context']=context
    return {'system':messages[0],'user_role':messages[1]['role'],'packet':packet}


def _cache(folder,inventory_path):
    from .repair import validator_for,verify_repair_chain
    folder=Path(folder).resolve();attempts=sorted(folder.glob('[0-9][0-9][0-9]'))
    if not attempts:raise ValueError('Missing historical attempts')
    first=load(attempts[0]/'audit.json');last=load(attempts[-1]/'audit.json')
    if first['request_hash']!=folder.name:raise ValueError('Original cache key does not match audit')
    if last['status']!='verified':raise ValueError('Selected historical response is not verified')
    proof=verify_repair_chain(folder,inventory_path)
    validate,bundle_path,packet=validator_for(attempts[0]/'audit.json',inventory_path)
    parsed=json.loads((attempts[-1]/'response.raw.txt').read_text())
    if parsed!=load(attempts[-1]/'parsed.json') or validate(parsed)!=load(attempts[-1]/'verified.json'):raise ValueError('Historical response no longer passes its original validator')
    bundle=load(bundle_path);normalized_bundle(bundle)
    from .contextual import compact_bundle
    if packet['context']!=compact_bundle(bundle):raise ValueError('Original compact/full bundle differ')
    return {'folder':folder,'first':first,'last':last,'packet':packet,'bundle':bundle,'bundle_path':bundle_path,'proof':proof,'records':load(attempts[-1]/'verified.json').get('records',[]),'latest':attempts[-1]}


def _snapshot(value):return load(value) if isinstance(value,(str,Path)) else value


def _base(manifest_path):
    path=Path(manifest_path).resolve();m=load(path)
    if m.get('schema')!='structure-order-migration-1' or m.get('approval')!='explicit_coordinator_order_only':raise ValueError('Not an explicit order-only migration')
    if m.get('manifest_id')!=digest({k:v for k,v in m.items() if k!='manifest_id'}):raise ValueError('Migration manifest changed')
    for item in m['artifacts']:checked(item)
    old=checked(m['old_core']);new=checked(m['new_core'])
    if new.read_bytes()!=expected_core(old.read_text()).encode():raise ValueError('Core migration contains an unapproved change')
    if Path(__file__).resolve()!=checked(m['migration_module']):raise ValueError('Migration verifier implementation differs')
    bound={str(checked(item)) for item in m['artifacts']}
    for folder in m['selected_cache_folders']+[m['order_pair']['duplicate_cache'],m['descendant_pair']['discarded_cache']]:
        if not {str(p.resolve()) for p in Path(folder).rglob('*') if p.is_file()}<=bound:raise ValueError('Historical cache contains unbound artifacts')
    inventory=checked(m['inventory']);selected=[_cache(p,inventory) for p in m['selected_cache_folders']]
    selected_by={str(c['folder']):c for c in selected}
    oldbranch=selected_by[m['order_pair']['selected_cache']];duplicate=_cache(m['order_pair']['duplicate_cache'],inventory)
    if normalized_messages(oldbranch['first']['messages'])!=normalized_messages(duplicate['first']['messages']) or normalized_bundle(oldbranch['bundle'])!=normalized_bundle(duplicate['bundle']):raise ValueError('Earliest duplicate is not exactly order-equivalent')
    descendant=selected_by[m['descendant_pair']['selected_cache']]
    discarded=Path(m['descendant_pair']['discarded_cache']).resolve()
    # Failed diagnostic response stays failed and never passes as an equivalent answer.
    bad=load(discarded/'001/audit.json')
    if bad['status']!='invalid_response' or len(list(discarded.glob('[0-9][0-9][0-9]')))!=1:raise ValueError('Discarded failure scope changed')
    from .repair import validator_for
    _,badbundlepath,badpacket=validator_for(discarded/'001/audit.json',inventory)
    badbundle=load(badbundlepath)
    _prove_descendant(descendant,bad,badbundle,oldbranch,duplicate,load(inventory))
    return m,selected


def _incremental(records,inventory):
    entries=[]
    for r in records:
        unit=inventory['units'][r['unit_instance_id']];evidence=r['reading_task']['evidence']
        entries.append({'entry_id':'INF:unit:'+digest(r)[:24],'epistemic_status':'INF','statement':r['reading_task']['observation'],'evidence':evidence,'established_position':[unit['logical_order'],max((q['end'] for q in evidence if q['unit_instance_id']==unit['instance_id']),default=len(unit['prose_text']))],'semantic_status':'pending_human','scope':'Editorial interpretation from actual source-bound Sonnet observation; never a scientific SRC fact.'})
    return entries


def _remove_branch(value,entries):
    value=deepcopy(value);found=set()
    for prior in value['prior_by_chunk'].values():
        current=prior['incremental_INF_observations'];keep=[]
        for item in current:
            if item in entries:found.add(item['entry_id'])
            else:keep.append(item)
        prior['incremental_INF_observations']=keep
    if found!={e['entry_id'] for e in entries}:raise ValueError('Diagnostic descendant does not derive from the bound earlier response')
    return value


def _prove_descendant(selected,bad,badbundle,oldbranch,duplicate,inventory):
    a=normalized_messages(selected['first']['messages']);b=normalized_messages(bad['messages'])
    oldentries=_incremental(oldbranch['records'],inventory);newentries=_incremental(duplicate['records'],inventory)
    if oldentries==newentries:raise ValueError('Expected distinct unused diagnostic INF branch')
    a['packet']['context']=_remove_branch(a['packet']['context'],oldentries)
    b['packet']['context']=_remove_branch(b['packet']['context'],newentries)
    if a!=b:raise ValueError('Discarded descendant differs beyond exact bound duplicate-response INF')
    if _remove_branch(normalized_bundle(selected['bundle']),oldentries)!=_remove_branch(normalized_bundle(badbundle),newentries):raise ValueError('Discarded full context differs beyond diagnostic branch')


def verify_order_migration(manifest_path,original_snapshot,current_snapshot,run_dir):
    m,selected=_base(manifest_path);original=_snapshot(original_snapshot);current=_snapshot(current_snapshot)
    if Path(run_dir).resolve()!=Path(m['run_dir']).resolve():raise ValueError('Migration run directory changed')
    checked(m['original_snapshot'])
    if load(m['original_snapshot']['path'])!=original:raise ValueError('Original snapshot differs')
    oldsha=m['old_core']['sha256'];newsha=m['new_core']['sha256']
    if original['code_and_prompts'].get(CORE)!=oldsha or current['code_and_prompts'].get(CORE)!=newsha:raise ValueError('Snapshot core hash differs from reviewed old/new source bytes')
    # Runner owns its separately authorized implementation change. No other input may drift.
    left=deepcopy(original);right=deepcopy(current)
    for value in (left,right):
        value['code_and_prompts'].pop(CORE,None);value['code_and_prompts'].pop('scripts/run_structure_expansion.py',None)
    if left!=right:raise ValueError('A source, prompt, setting, signature or other core changed during migration')
    return {'status':'verified_order_only_migration','manifest':binding(manifest_path),'approved_core_changes':{CORE:{'old_sha256':oldsha,'new_sha256':newsha}},'selected_cache_folders':[str(c['folder']) for c in selected],'excluded_failed_cache_folders':[m['descendant_pair']['discarded_cache']],'unused_verified_duplicate':m['order_pair']['duplicate_cache'],'source_and_response_modified':False,'diagnostic_descendant_equivalent':False,'network_dispatches':0}


@contextmanager
def replay_policy(manifest_path):
    m,selected=_base(manifest_path)
    token=_POLICY.set((m,selected,binding(manifest_path)))
    try:yield
    finally:_POLICY.reset(token)


def select_historical(messages,bundle,home,client,provider):
    policy=_POLICY.get()
    if policy is None:return messages,bundle
    m,selected,manifest_binding=policy;checked(manifest_binding)
    packet=json.loads(messages[1]['content']);ids=[c['chunk_id'] for c in packet['chunks']]
    matches=[c for c in selected if c['folder'].parent.parent==Path(home).resolve() and [v['chunk_id'] for v in c['packet']['chunks']]==ids]
    if not matches:return messages,bundle
    if len(matches)!=1:raise ValueError('Ambiguous explicit historical selection')
    chosen=matches[0]
    if normalized_messages(messages)!=normalized_messages(chosen['first']['messages']) or normalized_bundle(bundle)!=normalized_bundle(chosen['bundle']):raise ValueError('Current input is not order-equivalent to selected exact historical request; no model dispatched')
    cfg=client.config['llm'][provider]
    key=digest({'provider':provider,'model':cfg.get('model'),'max_output_tokens':cfg.get('max_output_tokens'),'messages':chosen['first']['messages']})
    if key!=chosen['folder'].name:raise ValueError('Provider/model/output budget differs from historical dispatch')
    receipt={'schema':'exact-historical-order-replay-1','manifest':manifest_binding,'candidate_messages_sha256':digest(messages),'candidate_context_bundle_id':bundle['context_bundle_id'],'selected_original_audit':binding(chosen['folder']/'001/audit.json'),'selected_latest_audit':binding(chosen['latest']/'audit.json'),'selected_context_bundle':binding(chosen['bundle_path']),'selected_original_messages_sha256':digest(chosen['first']['messages']),'comparison':'Only source_anchors and complete_preservation_objects lookup order and their derived bundle ID may differ. All other ordered fields/source/INF are exact.','response_rewritten':False,'network_dispatches':0}
    save(Path(home)/'order_replays'/(bundle['context_bundle_id']+'-'+chosen['folder'].name+'.json'),receipt)
    return deepcopy(chosen['first']['messages']),deepcopy(chosen['bundle'])
