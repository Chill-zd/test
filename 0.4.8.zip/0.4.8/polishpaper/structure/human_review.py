"""Reviewed semantic views; immutable originals and complete source text stay separate."""
from __future__ import annotations
import copy

def section_view(observation,unit_decisions):
    excluded={uid for uid,d in unit_decisions.items()if d['decision']!='approve'}
    result=copy.deepcopy(observation);omissions=[]
    for i,item in enumerate(result.get('ordered_items',[])):
        if item['item_id']in excluded:
            omissions.append({'kind':'ordered_item_interpretation','item_id':item['item_id'],'human_decision':unit_decisions[item['item_id']]['decision']})
            result['ordered_items'][i]={'item_id':item['item_id'],'kind':item['kind'],'status':'human_interpretation_withheld','human_decision':unit_decisions[item['item_id']]['decision'],'meaning':'Source position retained; unit interpretation is not endorsed or supplied as guidance.'}
    def ids(value):
        if isinstance(value,str):return {value}if value in excluded else set()
        if isinstance(value,list):return set().union(*(ids(x)for x in value))if value else set()
        if isinstance(value,dict):return set().union(*(ids(x)for x in value.values()))if value else set()
        return set()
    for key in ['observations','transitions','order_variants','context_assertions']:
        keep=[]
        for record in result.get(key,[]):
            blocked=ids(record)
            if blocked:omissions.append({'kind':key,'excluded_item_ids':sorted(blocked),'reason':'Interpretation references a unit not independently approved'})
            else:keep.append(record)
        if key in result:result[key]=keep
    if ids(result.get('section_task',{})):
        result['section_task']={'human_interpretation_withheld':True,'reason':'Task interpretation depends on a unit not independently approved'}
    result['human_review_scope']={'section_organization_only':True,'unit_approval_cascades':False,'excluded_unit_ids':sorted(excluded),'omissions':omissions,'source_context_policy':'Complete original English source may remain as dependency context; it is not an endorsed unit interpretation.'}
    return result
