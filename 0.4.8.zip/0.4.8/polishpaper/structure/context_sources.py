"""Conservative, source-bound TeX object envelopes and explicit references.

This is a static source inventory, not a TeX macro expansion or scientific
interpretation. Unbalanced, ambiguous and cross-file constructions stay unresolved.
"""
from __future__ import annotations

import copy
import hashlib
import re
from pathlib import Path

from ..corpus.parser import strip_comments
from .inventory import check_sources, digest


STANDARD = {
    **{name: "formula" for name in ("equation", "align", "alignat", "flalign", "gather", "multline", "displaymath", "eqnarray", "subequations", "aligned", "alignedat", "split", "cases", "array")},
    **{name: "theorem_statement" for name in ("theorem", "lemma", "proposition", "corollary", "definition", "assumption", "remark", "observation", "example", "proof")},
    **{name: "algorithm" for name in ("algorithm", "algorithmic", "algorithmicx")},
    "figure": "figure", "table": "table", "itemize": "list", "enumerate": "list", "description": "list",
}
THEOREM = re.compile(r"\\newtheorem\*?\s*\{(?P<name>[^{}]+)\}\s*(?:\[[^\[\]]*\]\s*)?\{(?P<title>[^{}]+)\}(?:\s*\[[^\[\]]*\])?")
TAG = re.compile(r"\\(?P<action>begin|end)\s*\{(?P<name>[^{}]+)\}|(?P<display>\\\[|\\\]|(?<!\\)\$\$)")
LABEL = re.compile(r"\\label\s*\{([^{}]+)\}")
REFERENCE = re.compile(r"\\(?:[cC]ref|[cC]refrange|[eE]qref|[aA]utoref|[vV]ref|ref|pageref)\*?\s*\{([^{}]+)\}")
FORMAT = re.compile(r"(?:\\(?:label|bibliography|bibliographystyle|addbibresource)\s*\{[^{}]*\}|\\(?:newpage|clearpage|cleardoublepage|pagebreak|nopagebreak|smallskip|medskip|bigskip|noindent|centering)\b(?:\s*\[[^\[\]]*\])?|\\(?:vskip|hskip)\s*[+-]?(?:\d+(?:\.\d*)?|\.\d+)\s*(?:pt|pc|in|bp|cm|mm|dd|cc|sp|em|ex)(?:\s+(?:plus|minus)\s*[+-]?(?:\d+(?:\.\d*)?|\.\d+)\s*(?:pt|pc|in|bp|cm|mm|dd|cc|sp|em|ex))?|\\(?:vspace|hspace)\*?\s*\{[^{}]*\})")


def _sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _escaped(text, position):
    backslashes = 0
    position -= 1
    while position >= 0 and text[position] == "\\":
        backslashes += 1
        position -= 1
    return backslashes % 2 == 1


def _pure_format(text):
    text = text.strip()
    if not text:
        return False
    position = 0
    while position < len(text):
        match = FORMAT.match(text, position)
        if not match:
            return False
        position = match.end()
        while position < len(text) and text[position].isspace():
            position += 1
    return True


def augment_inventory(inventory):
    """Return a new inventory; preserve all existing physical-unit source fields."""
    check_sources(inventory)
    result = copy.deepcopy(inventory)
    root = Path(result["root"]).resolve()
    files, aliases = {}, {}
    # Declared aliases may live in a local style file, outside parser text units.
    paths = {root / file for file in result["source_files"]}
    paths.update(root.rglob("*.tex"))
    paths.update(root.rglob("*.sty"))
    for path in sorted(paths):
        path = path.resolve()
        if not path.is_relative_to(root) or not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        with path.open(encoding="utf8", newline="") as handle:
            text = handle.read()
        clean = strip_comments(text)
        files[relative] = (text, clean)
        declarations = list(THEOREM.finditer(clean))
        if relative in result["source_files"] or declarations:
            result["source_files"][relative] = hashlib.sha256(path.read_bytes()).hexdigest()
        for declaration in declarations:
            name = declaration["name"].strip()
            aliases.setdefault(name, []).append({"file": relative, "offset_start": declaration.start(),
                "offset_end": declaration.end(), "line_start": text.count("\n", 0, declaration.start()) + 1,
                "title": declaration["title"], "text": text[declaration.start():declaration.end()],
                "sha256": _sha(text[declaration.start():declaration.end()]), "source_file_sha256": result["source_files"][relative]})
    result["environment_aliases"] = {name: {"declarations": declarations,
        "status": "declared_static" if len({d["title"] for d in declarations}) == 1 else "ambiguous_declarations",
        "kind": "theorem_statement", "limitation": "Static local newtheorem declaration; conditional activation and macro expansion not evaluated"}
        for name, declarations in aliases.items()}
    result["objects"] = {}
    units = result["units"]
    for unit in units.values():
        unit["envelope_refs"] = []
        if _pure_format(unit["prose_text"]):
            unit["content_kind"] = "source_metadata"
            unit["metadata_basis"] = "Entire comment-free unit consists of whitelisted non-prose formatting/label/bibliography commands"

    def add_object(file, start, end, env, status, reason=None):
        raw, clean = files[file]
        text = raw[start:end]
        object_id = f"{result['paper_id']}:object:{file}:{start}:{_sha(text)[:12]}"
        overlaps = [u for u in units.values() if u["file"] == file and u["offset_start"] < end and start < u["offset_end"]]
        if not overlaps:
            return  # Style/preamble declarations are not reading-context objects.
        first = min(overlaps, key=lambda u: (u["logical_order"], u["offset_start"]))
        alias = result["environment_aliases"].get(env.rstrip("*"))
        if alias and alias["status"] != "declared_static" and status == "complete":
            status, reason = "unresolved", "ambiguous newtheorem declarations"
        kind = STANDARD.get(env.rstrip("*"), "theorem_statement" if alias else "unknown_environment")
        obj = {"object_id": object_id, "unit_id": object_id, "instance_id": object_id,
            "paper_id": result["paper_id"], "file": file, "offset_start": start, "offset_end": end,
            "line_start": raw.count("\n", 0, start) + 1, "line_end": raw.count("\n", 0, max(start, end - 1)) + 1,
            "text": text, "prose_text": clean[start:end], "sha256": _sha(text), "prose_sha256": _sha(clean[start:end]),
            "section_id": first["section_id"], "section_path": first.get("section_path", []),
            "section_type": first.get("section_type"), "logical_order": first["logical_order"],
            "content_kind": "insertion_object", "env_kind": env, "object_kind": kind,
            "status": status, "complete": status == "complete", "unresolved_reason": reason,
            "alias_provenance": alias, "covered_unit_instance_ids": [u["instance_id"] for u in overlaps],
            "fully_covered_unit_instance_ids": [], "labels": [m[1] for m in LABEL.finditer(clean, start, end)],
            "boundary_limitation": "Complete static same-file envelope" if status == "complete" else "Unresolved source envelope; not a complete context object"}
        for unit in overlaps:
            unit["envelope_refs"].append(object_id)
            outside = clean[unit["offset_start"]:min(start, unit["offset_end"])] + clean[max(end, unit["offset_start"]):unit["offset_end"]]
            if status == "complete" and not outside.strip():
                obj["fully_covered_unit_instance_ids"].append(unit["instance_id"])
                if unit["content_kind"] != "source_metadata":
                    unit["content_kind"] = "insertion_object"
        result["objects"][object_id] = obj

    for file in sorted({u["file"] for u in units.values()}):
        _, clean = files[file]
        stack = []
        for token in TAG.finditer(clean):
            if _escaped(clean, token.start()):
                continue
            display = token["display"]
            name = token["name"] if not display else "displaymath"
            if name == "document":
                continue
            action = token["action"] if not display else ("begin" if display == r"\[" or (display == "$$" and not (stack and stack[-1]["delimiter"] == "$$")) else "end")
            delimiter = "$$" if display == "$$" else "bracket" if display else "environment"
            recognized = name.rstrip("*") in STANDARD or name.rstrip("*") in aliases
            if action == "begin":
                stack.append({"name": name, "start": token.start(), "recognized": recognized, "delimiter": delimiter})
            elif stack and stack[-1]["name"] == name and stack[-1]["delimiter"] == delimiter:
                opening = stack.pop()
                if opening["recognized"]:
                    add_object(file, opening["start"], token.end(), name, "complete")
            else:
                # Do not repair misnesting into an apparently complete envelope.
                for opening in stack:
                    if opening["recognized"]:
                        add_object(file, opening["start"], token.end(), opening["name"], "unresolved", "mismatched or cross-file environment end")
                stack.clear()
        for opening in stack:
            if opening["recognized"]:
                add_object(file, opening["start"], len(clean), opening["name"], "unresolved", "missing same-file environment end")

    labels = {}
    for file in sorted({u["file"] for u in units.values()}):
        raw, clean = files[file]
        for match in LABEL.finditer(clean):
            enclosing = [o for o in result["objects"].values() if o["file"] == file and o["offset_start"] <= match.start() < o["offset_end"]]
            objects = sorted(enclosing, key=lambda o: o["offset_end"] - o["offset_start"])
            section_matches = [s for s in result["sections"] if s.get("file") == file and s.get("offset_start", 0) <= match.start()]
            section = max(section_matches, key=lambda s: s["offset_start"]) if section_matches else None
            # A label is a section label only when immediately after its heading,
            # with no intervening prose; arbitrary nearby labels are not guessed.
            section_target = section if section and not clean[section["offset_end"]:match.start()].strip() else None
            labels.setdefault(match[1], []).append({"label": match[1], "file": file,
                "offset_start": match.start(), "offset_end": match.end(), "line_start": raw.count("\n", 0, match.start()) + 1,
                "object_id": objects[0]["object_id"] if objects else None,
                "section_id": section_target["section_id"] if section_target else None})
    result["labels"] = labels
    result["context_sources_version"] = 1
    result["limitations"] = list(result.get("limitations", [])) + ["Context objects use conservative static same-file TeX envelopes; macro expansion, conditionals and cross-file envelopes are not certified."]
    result["inventory_hash"] = digest({k: v for k, v in result.items() if k not in ("root", "inventory_hash")})
    return result


def resolve_references(inventory, unit_ids):
    """Resolve explicit labels only to unique, complete source objects/scopes."""
    check_sources(inventory)
    if "context_sources_version" not in inventory:
        raise ValueError("augment_inventory is required before resolving context references")
    units = inventory["units"]
    sections = {s["section_id"]: s for s in inventory["sections"]}
    resolved, unresolved, seen = [], [], set()
    for requested in unit_ids:
        matches = [u for key, u in units.items() if key == requested or u["unit_id"] == requested]
        if not matches:
            unresolved.append({"source_unit_id": requested, "status": "UNK", "reason": "source unit not found"})
        for unit in matches:
            for reference in REFERENCE.finditer(unit["prose_text"]):
                for label in reference[1].split(","):
                    label = label.strip()
                    claim = {"source_unit_id": unit["unit_id"], "source_unit_instance_id": unit["instance_id"], "label": label,
                        "reference_offset": unit["offset_start"] + reference.start()}
                    targets = inventory["labels"].get(label, [])
                    if len(targets) != 1:
                        unresolved.append({**claim, "status": "UNK", "reason": "missing label" if not targets else "ambiguous duplicate label"})
                        continue
                    target = targets[0]
                    obj = inventory["objects"].get(target["object_id"])
                    if obj and not obj["complete"]:
                        unresolved.append({**claim, "status": "UNK", "reason": "target envelope incomplete or ambiguous", "target": target})
                        continue
                    if obj:
                        target_source, kind, order = obj, "object", obj["logical_order"]
                    elif target["section_id"]:
                        section = sections[target["section_id"]]
                        scoped_units = [units[i] for i in section["all_unit_instances"]]
                        target_source = {"section": section, "units": scoped_units,
                            "objects": [o for o in inventory["objects"].values() if any(i in section["all_unit_instances"] for i in o["covered_unit_instance_ids"])]}
                        kind, order = "section_scope", min((u["logical_order"] for u in scoped_units), default=float("inf"))
                    else:
                        unresolved.append({**claim, "status": "UNK", "reason": "label has no complete object or unambiguous section scope", "target": target})
                        continue
                    later = (target["offset_start"] >= claim["reference_offset"]) if target["file"] == unit["file"] else order >= unit["logical_order"]
                    if obj:
                        complete_before = obj["offset_end"] <= claim["reference_offset"] if obj["file"] == unit["file"] else obj["logical_order"] < unit["logical_order"]
                    else:
                        complete_before = bool(scoped_units) and all(u["logical_order"] < unit["logical_order"] for u in scoped_units)
                    key = (unit["instance_id"], label, claim["reference_offset"])
                    if key not in seen:
                        seen.add(key)
                        resolved.append({**claim, "status": "resolved_source", "target_kind": kind,
                            "temporal_relation": "later" if later else "earlier", "reader_prior": not later and complete_before,
                            "target_complete_before_reference": complete_before,
                            "target": target_source})
    return {"resolved": resolved, "unresolved": unresolved}
