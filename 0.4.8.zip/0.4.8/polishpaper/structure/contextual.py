"""V2 contextual observation. The old extraction API and trial artifacts stay unchanged."""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import json,hashlib
from .inventory import digest,save,load,public_unit,section_key,check_sources
from .extract import plan,cached_call,StructureInputBudget
from .contracts import UNIT_SCHEMA,SECTION_SCHEMA,QUOTE,contract,bind_quote,validate_units,validate_section,StructureValidationError
from .context import prior_context,artifact_binding,assert_context_fresh
from .context_sources import resolve_references

PROMPTS=Path(__file__).parents[1]/'prompts'
ASSERTION={'type':'object','required':['assertion_id','role','epistemic_status','statement','evidence','depends_on_src_ids','inference_kind','missing_information'],'properties':{'assertion_id':{'type':'string'},'role':{'enum':['reader_before','reader_after','incoming','outgoing','section_context','other']},'epistemic_status':{'enum':['SRC','INF','UNK']},'statement':{'type':'string','minLength':1},'evidence':{'type':'array','items':QUOTE},'depends_on_src_ids':{'type':'array','items':{'type':'string'}},'inference_kind':{'type':'string'},'missing_information':{'type':'string'}},'additionalProperties':False}
UNIT_V2=deepcopy(UNIT_SCHEMA)
UNIT_V2['required']+=['context_bundle_id'];UNIT_V2['properties']['context_bundle_id']={'type':'string'}
UNIT_V2['properties']['records']['items']['required']+=['context_assertions'];UNIT_V2['properties']['records']['items']['properties']['context_assertions']={'type':'array','items':ASSERTION}
SECTION_V2=deepcopy(SECTION_SCHEMA)
SECTION_V2['required']+=['context_bundle_id','context_assertions'];SECTION_V2['properties'].update({'context_bundle_id':{'type':'string'},'context_assertions':{'type':'array','minItems':1,'items':ASSERTION}})


def view(inventory):return {**inventory,'units':{**inventory['units'],**inventory.get('objects',{})}}

def clean(value):
    if isinstance(value,dict):return {k:clean(v) for k,v in value.items() if not (k=='text' and 'prose_text' in value)}
    if isinstance(value,list):return [clean(v) for v in value]
    return value


def position(quote,inventory):
    uid=quote['unit_instance_id']
    if uid in inventory['units']:return (inventory['units'][uid]['logical_order'],quote['end'])
    obj=inventory['objects'][uid];absolute=obj['offset_start']+quote['end'];covered=[inventory['units'][u] for u in obj.get('covered_unit_instance_ids',[]) if inventory['units'][u]['offset_start']<absolute]
    if not covered:raise StructureValidationError('Object quote has no logical source position')
    unit=max(covered,key=lambda u:u['logical_order'])
    return (unit['logical_order'],max(0,absolute-unit['offset_start']))


def anchor(inventory,uid,start=0,end=None):
    unit=view(inventory)['units'][uid];end=len(unit['prose_text']) if end is None else end
    quote=bind_quote({'unit_instance_id':uid,'text':unit['prose_text'][start:end],'start':start,'end':end},view(inventory),{uid})
    return {'entry_id':'SRC:literal:'+digest({'source':unit['sha256'],'id':uid,'start':start,'end':end})[:24],'epistemic_status':'SRC','entry_kind':'verbatim_source_container_not_scientific_fact','statement':'Only the exact supplied source span is asserted; no scientific interpretation or truth is established.','evidence':[quote],'established_position':list(position(quote,inventory)),'semantic_status':'not_a_scientific_verification'}


def neighbor_units(inventory,uid,count=1):
    ordered=list(inventory['units']);at=ordered.index(uid);result=[]
    for step in (-1,1):
        chosen=0;cursor=at+step
        while 0<=cursor<len(ordered) and chosen<count:
            other=inventory['units'][ordered[cursor]]
            if other['content_kind']=='prose_fragment' and other['prose_text'].strip():result.append(public_unit(other));chosen+=1
            cursor+=step
    return result


def make_bundle(inventory,ledger,chunks,incremental=None,neighbor_count=1,whole_section=None):
    targets=list(dict.fromkeys(c['unit_instance_id'] for c in chunks));source_view=view(inventory);priors={};neighbors={};anchors={};dependency_units=whole_section['all_unit_instances'] if whole_section else targets;refs=resolve_references(inventory,dependency_units)
    # Own preservation envelopes are supplied even when no ref command points to them.
    own_ids=sorted({oid for uid in dependency_units for oid in inventory['units'][uid].get('envelope_refs',[])})
    objects={oid:clean(inventory['objects'][oid]) for oid in own_ids if inventory['objects'][oid].get('complete')}
    missing=[{'status':'UNK','reason':'Own preservation envelope is incomplete','object_id':oid} for oid in own_ids if not inventory['objects'][oid].get('complete')]
    available=set(targets);full_units=set(targets);visible={}
    for resolved in refs['resolved']:
        target=resolved['target']
        if resolved['target_kind']=='object':objects[target['object_id']]=clean(target)
        else:
            for unit in target.get('units',[]):available.add(unit['instance_id']);full_units.add(unit['instance_id'])
            for obj in target.get('objects',[]):
                if obj.get('complete'):objects[obj['object_id']]=clean(obj)
    for chunk in chunks:
        uid=chunk['unit_instance_id'];prior=prior_context(inventory,ledger,uid,chunk['start']);prior['incremental_INF_observations']=[e for e in incremental or [] if tuple(e['established_position'])<=(inventory['units'][uid]['logical_order'],chunk['start'])]
        priors[chunk['chunk_id']]=prior
        for entry in prior['source_entries']:
            for q in entry['evidence']+entry.get('condition_evidence',[]):
                available.add(q['unit_instance_id']);visible.setdefault(q['unit_instance_id'],[]).append([q['start'],q['end']])
        for neighbor in neighbor_units(inventory,uid,neighbor_count):neighbors[neighbor['instance_id']]=neighbor;available.add(neighbor['instance_id']);full_units.add(neighbor['instance_id'])
        literal=anchor(inventory,uid,chunk['start'],chunk['end']);anchors[literal['entry_id']]=literal
    if whole_section:
        for uid in whole_section['all_unit_instances']:available.add(uid);full_units.add(uid)
    for uid in sorted(full_units,key=lambda u:inventory['units'][u]['logical_order']):
        if not inventory['units'][uid]['prose_text'].strip():continue
        literal=anchor(inventory,uid);anchors[literal['entry_id']]=literal;visible[uid]=[[0,len(inventory['units'][uid]['prose_text'])]]
    for oid in objects:
        available.add(oid);literal=anchor(inventory,oid);anchors[literal['entry_id']]=literal;visible[oid]=[[0,len(inventory['objects'][oid]['prose_text'])]]
    bundle={'context_version':2,'inventory_hash':inventory['inventory_hash'],'ledger_scan_id':ledger['scan_id'],'ledger_scope':'selected_not_exhaustive','absence_rule':'Not supplied in the selected context does not mean not established in the paper.','prior_by_chunk':priors,'neighbor_prose_units':list(neighbors.values()),'source_anchors':list(anchors.values()),'dependency_sources':clean(refs['resolved']),'dependency_unknowns':refs['unresolved']+missing,'complete_preservation_objects':list(objects.values()),'target_chunk_ids':[c['chunk_id'] for c in chunks],'source_availability':sorted(available),'available_spans':visible,'future_dependency_rule':'Later referenced source may be read as a supplied dependency, never treated as already read/established before its logical position.','known_limitations':['Section-level cards are INF pending human, not scientific SRC facts.','Selected ledger and local windows are not exhaustive prior-paper knowledge.','Source conditions may require unresolved further dependencies; do not invent them.']}
    bundle['context_bundle_id']=digest(bundle)
    return bundle


def source_entries(bundle):
    result={a['entry_id']:a for a in bundle['source_anchors']}
    for prior in bundle['prior_by_chunk'].values():
        for e in prior['source_entries']:result[e['entry_id']]=e
    return result


def visible_quote(quote,inventory,bundle):
    bound=bind_quote(quote,view(inventory),set(bundle['source_availability']))
    if not any(a<=bound['start'] and bound['end']<=b for a,b in bundle['available_spans'].get(bound['unit_instance_id'],[])):raise StructureValidationError('Quote refers beyond the actually supplied source span')
    return bound

def validate_assertions(assertions,inventory,bundle,namespace,cutoff_before=None,cutoff_after=None):
    known=source_entries(bundle);bound=[];local={a['assertion_id']:namespace+':'+a['assertion_id'] for a in assertions}
    if len(local)!=len(assertions):raise StructureValidationError('Duplicate context assertion ID')
    allowed=set(bundle['source_availability'])
    # Register explicitly quoted SRC statements, while preserving their true logical positions.
    for a in assertions:
        if a['epistemic_status']=='SRC':
            if not a['evidence']:raise StructureValidationError('SRC assertion requires literal source evidence')
            evidence=[visible_quote(q,inventory,bundle) for q in a['evidence']]
            known[local[a['assertion_id']]]={'entry_id':local[a['assertion_id']],'epistemic_status':'SRC','evidence':evidence,'established_position':list(max(position(q,inventory) for q in evidence))}
    for a in assertions:
        evidence=[visible_quote(q,inventory,bundle) for q in a['evidence']];deps=[local.get(i,i) for i in a['depends_on_src_ids']]
        if a['epistemic_status']=='INF' and (not deps or not a['inference_kind'].strip()):raise StructureValidationError('INF requires SRC dependencies and inference kind')
        if any(d not in known or known[d].get('epistemic_status')!='SRC' for d in deps):raise StructureValidationError('INF/SRC dependency missing or is an interpretation rather than SRC')
        if a['epistemic_status']=='UNK' and not a['missing_information'].strip():raise StructureValidationError('UNK requires missing-information explanation, not paper-absence inference')
        cutoff=cutoff_before if a['role']=='reader_before' else cutoff_after if a['role']=='reader_after' else None
        positions=[position(q,inventory) for q in evidence]+[tuple(known[d]['established_position']) for d in deps]
        if cutoff is not None and any(p>cutoff for p in positions):raise StructureValidationError('Future source cannot be treated as prior/finished reader knowledge')
        bound.append({**a,'assertion_id':local[a['assertion_id']],'evidence':evidence,'depends_on_src_ids':deps,'semantic_status':'pending_human','truth_status':'SRC is direct source, not verified scientific truth; INF is interpretation; UNK is input limitation.'})
    return bound


def validate_context_units(value,chunks,inventory,bundle):
    contract(value,UNIT_V2)
    if value['context_bundle_id']!=bundle['context_bundle_id']:raise StructureValidationError('Wrong unit context bundle')
    base=deepcopy(value);base.pop('context_bundle_id');assertions=[r.pop('context_assertions') for r in base['records']];slots=[r['scientific_slots'] for r in base['records']]
    for r in base['records']:r['scientific_slots']=[]
    verified=validate_units(base,chunks,view(inventory),set(bundle['source_availability']))
    for record,chunk,claims,scientific in zip(verified['records'],chunks,assertions,slots):
        typed=validate_assertions(claims,inventory,bundle,'CTX:'+bundle['context_bundle_id'][:16]+':'+digest(chunk['chunk_id'])[:8],(inventory['units'][chunk['unit_instance_id']]['logical_order'],chunk['start']),(inventory['units'][chunk['unit_instance_id']]['logical_order'],chunk['end']))
        for role,string in [('reader_before',record['reading_task']['reader_before']),('reader_after',record['reading_task']['reader_after']),('incoming',record['context_links']['incoming']['observation']),('outgoing',record['context_links']['outgoing']['observation'])]:
            matched=[a for a in typed if a['role']==role]
            if len(matched)!=1 or matched[0]['statement']!=string:raise StructureValidationError('Each reader/context statement needs one exact SRC/INF/UNK assertion: '+role)
        record['context_assertions']=typed;record['scientific_slots']=[{**s,'evidence':visible_quote(s['evidence'],inventory,bundle),'source_statement_status':'SRC_not_scientific_truth_verification','preservation_instruction_status':'INF_pending_human'} for s in scientific]
    return {**verified,'context_bundle_id':bundle['context_bundle_id']}


def validate_context_section(value,section,inventory,unit_states,child_states,bundle):
    contract(value,SECTION_V2)
    if value['context_bundle_id']!=bundle['context_bundle_id']:raise StructureValidationError('Wrong section context bundle')
    base=deepcopy(value);assertions=base.pop('context_assertions');base.pop('context_bundle_id')
    result=validate_section(base,section,view(inventory),unit_states,child_states)
    typed=validate_assertions(assertions,inventory,bundle,'CTX:'+bundle['context_bundle_id'][:16])
    if not any(a['role']=='section_context' and a['statement']==result['section_task']['observation'] for a in typed):raise StructureValidationError('Section task requires a matching typed context assertion')
    result.update(context_bundle_id=bundle['context_bundle_id'],context_assertions=typed,editorial_interpretation_status='INF_pending_human')
    return result


def messages(name,packet,schema):return [{'role':'system','content':(PROMPTS/name).read_text()},{'role':'user','content':json.dumps({**packet,'output_json_schema':schema},ensure_ascii=False)}]


def compact_bundle(bundle):
    """The full bundle is persisted; source anchors avoid duplicating already supplied text."""
    result=deepcopy(bundle)
    result['source_anchors']=[{k:v for k,v in a.items() if k!='evidence'}|{'source_spans':[{'unit_instance_id':q['unit_instance_id'],'start':q['start'],'end':q['end'],'projection_span_sha256':q['source']['projection_span_sha256']} for q in a['evidence']]} for a in bundle['source_anchors']]
    return result


def run(inventory,section,client,directory,ledger_path,provider='sonnet',max_chunk_chars=6000,max_batch_chars=12000,max_synthesis_chars=1000000,recursive=True,retry_failed=False,max_batch_units=3,neighbor_count=1):
    from .extract import run as old_run
    # Reuse exact deterministic source-metadata handling without invoking any model.
    check_sources(inventory);ledger=load(ledger_path)
    if ledger['inventory_hash']!=inventory['inventory_hash']:raise ValueError('Context scan inventory does not match v2 source')
    home=Path(directory)/section_key(section);home.mkdir(parents=True,exist_ok=True);planned=plan(inventory,section,max_chunk_chars,max_batch_chars,max_batch_units)
    save(home/'v2_plan.json',{**planned,'inventory_hash':inventory['inventory_hash'],'neighbor_count':neighbor_count,'max_complete_input_chars':max_synthesis_chars,'context_version':2})
    if not section['all_unit_instances']:return {'section_id':section['section_id'],'inventory_hash':inventory['inventory_hash'],'status':'skipped','review_status':'machine_proposed','semantic_status':'pending_human','units':[],'section_observation':None}
    child_results={};byid={s['section_id']:s for s in inventory['sections']}
    for child in section['children']:
        if recursive:child_results[child]=run(inventory,byid[child],client,directory,ledger_path,provider,max_chunk_chars,max_batch_chars,max_synthesis_chars,recursive,retry_failed,max_batch_units,neighbor_count)
    records=[];bindings=[artifact_binding(ledger_path,'source_ledger')];incremental=[]
    for uid in planned['metadata_units']:
        u=inventory['units'][uid];q=bind_quote({'unit_instance_id':uid,'text':u['prose_text'].strip()},view(inventory),{uid})
        records.append({'chunk_id':uid+':metadata','unit_instance_id':uid,'status':'skipped','reading_task':{'observation':'Not applicable: source formatting/label metadata.','reader_before':'not applicable','reader_after':'not applicable','evidence':[q]},'segments':[],'context_links':{d:{'observation':'not applicable: source metadata','evidence':[]} for d in ('incoming','outgoing')},'scientific_slots':[],'limitations':['Non-prose source metadata.'],'reason':'Mechanically accounted source anchor/formatting, no rhetorical judgment.','analysis_origin':'deterministic_source_metadata','context_assertions':[]})
    for batch_no,chunks in enumerate(planned['batches'],1):
        bundle=make_bundle(inventory,ledger,chunks,incremental,neighbor_count)
        packet={'inventory_hash':inventory['inventory_hash'],'paper_id':inventory['paper_id'],'authorship':inventory['metadata'],'section':{k:section[k] for k in ('section_id','section_path','section_type','title')},'chunks':chunks,'complete_unit_contexts':[public_unit(inventory['units'][uid]) for uid in dict.fromkeys(c['unit_instance_id'] for c in chunks)],'context':compact_bundle(bundle),'effective_budgets':{'max_chunk_chars':max_chunk_chars,'max_batch_chars':max_batch_chars,'max_batch_units':max_batch_units,'max_input_chars':max_synthesis_chars,'neighbor_count':neighbor_count}}
        call_messages=messages('paragraph_context_observe.md',packet,UNIT_V2)
        from .order_migration import select_historical
        call_messages,bundle=select_historical(call_messages,bundle,home,client,provider)
        bundle_path=home/'context_bundles'/(bundle['context_bundle_id']+'.json')
        if bundle_path.exists() and load(bundle_path)!=bundle:raise ValueError('Existing exact context bundle differs')
        if not bundle_path.exists():save(bundle_path,bundle)
        bindings.append(artifact_binding(bundle_path,'context_bundle'))
        if sum(len(m['content']) for m in call_messages)>max_synthesis_chars:raise StructureInputBudget('Complete contextual unit request exceeds explicit budget; source not truncated')
        result=cached_call(client,provider,call_messages,home,'structure_v2_unit_observation',lambda v:validate_context_units(v,chunks,inventory,bundle),retry_failed)
        records.extend(result['records']);save(home/f'batch_{batch_no:03d}.json',{'inventory_hash':inventory['inventory_hash'],'context_version':2,'records':result['records']})
        for record in result['records']:
            unit=inventory['units'][record['unit_instance_id']];evidence=record['reading_task']['evidence']
            incremental.append({'entry_id':'INF:unit:'+digest(record)[:24],'epistemic_status':'INF','statement':record['reading_task']['observation'],'evidence':evidence,'established_position':[unit['logical_order'],max((q['end'] for q in evidence if q['unit_instance_id']==unit['instance_id']),default=len(unit['prose_text']))],'semantic_status':'pending_human','scope':'Editorial interpretation from actual source-bound Sonnet observation; never a scientific SRC fact.'})
    records.sort(key=lambda r:(inventory['units'][r['unit_instance_id']]['logical_order'],next((s['quote']['start'] for s in r['segments']),0)))
    states={uid:('analyzed' if all(r['status']=='analyzed' for r in records if r['unit_instance_id']==uid) else 'skipped' if inventory['units'][uid]['content_kind']=='source_metadata' else 'partial') for uid in planned['unit_instances']};child_states={cid:child_results[cid]['status'] if cid in child_results else 'unresolved' for cid in section['children']}
    first=section['all_unit_instances'][0];last=section['all_unit_instances'][-1]
    section_chunk={'chunk_id':section['section_id']+':section_context','unit_instance_id':first,'start':0,'end':len(inventory['units'][first]['prose_text']),'text':inventory['units'][first]['prose_text']}
    bundle=make_bundle(inventory,ledger,[section_chunk],incremental,neighbor_count,section);bundle_path=home/'context_bundles'/(bundle['context_bundle_id']+'.json');save(bundle_path,bundle);bindings.append(artifact_binding(bundle_path,'context_bundle'))
    packet={'inventory_hash':inventory['inventory_hash'],'paper_id':inventory['paper_id'],'authorship':inventory['metadata'],'section':section,'full_source_units':[public_unit(inventory['units'][uid]) for uid in section['all_unit_instances']],'verified_chunk_observations':records,'unit_machine_states':states,'child_machine_states':child_states,'child_section_observations':child_results,'context':compact_bundle(bundle),'effective_budgets':{'max_chunk_chars':max_chunk_chars,'max_batch_chars':max_batch_chars,'max_batch_units':max_batch_units,'max_input_chars':max_synthesis_chars,'neighbor_count':neighbor_count}}
    call_messages=messages('section_context_observe.md',packet,SECTION_V2);chars=sum(len(m['content']) for m in call_messages)
    if chars>max_synthesis_chars:raise StructureInputBudget('Complete contextual section exceeds explicit budget; no source omitted')
    observation=cached_call(client,provider,call_messages,home,'structure_v2_section_observation',lambda v:validate_context_section(v,section,inventory,states,child_states,bundle),retry_failed)
    provenance={'version':2,'inventory_hash':inventory['inventory_hash'],'source_ledger':bindings[0],'artifact_bindings':bindings,'ledger_scope':'selected_not_exhaustive','truth_status':'Source statements are not verified scientific truths; interpretations remain INF pending human.','temporal_rule':'Prior-reader claims may use only SRC evidence established at or before the target cutoff.'};assert_context_fresh(provenance,inventory)
    result={'context_version':2,'section_id':section['section_id'],'inventory_hash':inventory['inventory_hash'],'status':observation['status'],'review_status':'machine_proposed','semantic_status':'pending_human','units':records,'unit_states':states,'child_states':child_states,'section_observation':observation,'complete_synthesis_input_chars':chars,'complete_source_supplied':True,'context_provenance':provenance};save(home/'analysis.json',result);return result
