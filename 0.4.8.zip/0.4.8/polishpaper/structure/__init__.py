"""Independent, source-bound paragraph and real-section observation layer."""
