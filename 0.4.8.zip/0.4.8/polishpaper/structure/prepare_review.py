"""Prepare explicitly selected original analyses for human review, never activation."""
from __future__ import annotations
from pathlib import Path
from .inventory import MAIN_TYPES, check_sources, digest, load, save
from .delivery import _binding, _check_analysis, stage_registry, StructureRegistryError, _quotes, _check_quote
from .review import review_pack


def prepare_review(entries, output_dir, target_author='Wolfram Wiesemann', phrase_audit=None, inventory_paths=None):
    """Freeze valid originals; keep missing/in-progress selections visibly not ready.

    Entries use stage_registry's explicit original paths. Partial section results
    remain partial. No trial relabeling, active pointer or human attestation occurs.
    """
    inventories={};paths={};ready=[];selections=[];sidecars=[];physical=set();partial_batches={}
    for path in inventory_paths or []:
        inv=load(path);check_sources(inv);inventories[inv['inventory_hash']]=inv
    for entry in entries:
        ip=Path(entry['inventory_path']).resolve();ap=Path(entry['analysis_path']).resolve()
        inv=load(ip);check_sources(inv)
        existing=inventories.get(inv['inventory_hash'])
        if existing is not None and existing!=inv:raise StructureRegistryError('Conflicting inventories for one fingerprint')
        inventories[inv['inventory_hash']]=inv
        row={'inventory':_binding(ip),'analysis_path':str(ap),'status':'not_ready','reason':'analysis_missing','concepts':entry.get('concepts',[])}
        section_id=entry.get('section_id')
        if ap.is_file():
            value=load(ap);row['analysis']=_binding(ap)
            if value.get('review_status')!='machine_proposed' or value.get('semantic_status')!='pending_human':raise StructureRegistryError('Selected machine analysis cannot self-approve')
            if value.get('inventory_hash')!=inv['inventory_hash']:raise StructureRegistryError('Selected analysis belongs to another inventory')
            if section_id and value.get('section_id')!=section_id:raise StructureRegistryError('Selected analysis belongs to another expected section')
            section_id=value.get('section_id')
            if value.get('section_observation'):
                _check_analysis(value,inv)
                row.update(status='ready_for_human_review',reason=None,machine_status=value['status'])
                paths[(inv['inventory_hash'],section_id)]=ap
                ready.append({**entry,'inventory_path':ip,'analysis_path':ap})
                sidecars.extend(entry.get('atomic_sidecar_paths',[]))
            else:row['reason']='section_observation_not_completed'
        if not section_id or not any(s['section_id']==section_id for s in inv['sections']):raise StructureRegistryError('Every selection needs an exact real section identity')
        identity=(inv['paper_id'],section_id)
        if identity in physical:raise StructureRegistryError('Duplicate physical section selection')
        physical.add(identity)
        section=next(s for s in inv['sections'] if s['section_id']==section_id)
        row.update(paper_id=inv['paper_id'],section_id=section_id,section_type=section['section_type'])
        if row['status']=='not_ready':
            batches=[]
            for batch_path in sorted(ap.parent.glob('batch_*.json')):
                batch=load(batch_path)
                if batch.get('inventory_hash')!=inv['inventory_hash']:raise StructureRegistryError('Partial batch belongs to another inventory')
                for record in batch.get('records',[]):
                    if record['unit_instance_id'] not in section['all_unit_instances']:raise StructureRegistryError('Partial batch belongs to another section')
                    for quote in _quotes(record):_check_quote(quote,inv)
                batches.append(_binding(batch_path))
            if batches:
                row.update(reason='unit_batches_only_no_section_observation',partial_unit_batches=len(batches),batch_bindings=batches)
                partial_batches[(inv['inventory_hash'],section_id)]=batches
        selections.append(row)
    fingerprint=digest({'selections':selections,'target_author':target_author,'phrase_audit':_binding(phrase_audit) if phrase_audit else None,'sidecars':[_binding(p) for p in sidecars],'inventories':sorted(inventories)})
    home=Path(output_dir).resolve()/fingerprint[:20]
    registry=stage_registry(ready,home/'staged_registry.json',target_author)
    packet=review_pack(list(inventories.values()),None,home/'human_review',target_author,phrase_audit,sidecars,analysis_paths=paths,partial_batches=partial_batches)
    template={'packet_hash':registry['packet_hash'],'decision_origin':None,'reviewer':None,'reviewed_at':None,
        'instructions':'Blank template only. Actual human reviewers supply their own provenance and decisions; code/models must not attest human approval.',
        'decisions':[{'entry_id':e['entry_id'],'analysis_sha256':e['analysis']['sha256'],'inventory_sha256':e['inventory']['sha256'],'decision':None,'comments':''} for e in registry['entries']]}
    template_path=home/'registry_decisions.template.json'
    if not template_path.exists():save(template_path,template)
    ready_types={s['section_type'] for s in selections if s['status']=='ready_for_human_review'}
    report={'schema':'structure-review-preparation-1','selection_fingerprint':fingerprint,'selections':selections,
        'selected_sections':len(selections),'ready_for_human_review':len(ready),'not_ready':len(selections)-len(ready),
        'ready_main_types':sorted(ready_types),'missing_ready_main_types':sorted(set(MAIN_TYPES)-ready_types),
        'registry':_binding(home/'staged_registry.json'),'review_packet':packet,'decision_template':str(template_path),
        'human_approved':0,'semantic_status':'pending_human','scientific_truth':'unverified','activated':False,
        'limitations':['Representative selected sections do not establish full-corpus analysis coverage.','Mechanical atomic sidecars do not complete partial semantic fragment maps.','Human review, Level 3 acceptance and paired writing-quality tasks remain separate unfinished gates.']}
    save(home/'preparation.json',report);save(Path(output_dir)/'latest_preparation.json',report)
    return report
