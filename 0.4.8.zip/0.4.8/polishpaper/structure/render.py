"""Literal Markdown rendering of stored observations; no model judgments are added."""
from __future__ import annotations
import hashlib,json


def anchor(uid):return 'unit-'+hashlib.sha256(uid.encode()).hexdigest()[:16]
def text(value):return value if isinstance(value,str) else json.dumps(value,ensure_ascii=False)
def quoted(evidence):
    lines=[]
    for quote in evidence:
        source=quote.get('source',{});lines+=['```latex',quote['text'],'```',f"Source: `{quote['unit_instance_id']}`; `{source.get('file','')}:{source.get('line_start','')}-{source.get('line_end','')}`; projection span `{quote.get('start','')},{quote.get('end','')}`.",'']
    return lines

def observation(value):return [text(value['observation']),'',*quoted(value['evidence'])]

def unit_markdown(unit,records):
    uid=unit['instance_id'];lines=[f'<a id="{anchor(uid)}"></a>',f"## Source unit: {uid}",'',f"Kind: `{unit['content_kind']}`; `{unit['file']}:{unit['line_start']}-{unit['line_end']}`.",f"Raw SHA256: `{unit['sha256']}`; projection SHA256: `{unit['prose_sha256']}`.",'','### Original comment-free source projection','','```latex',unit['prose_text'],'```','']
    for record in records:
        lines += [f"### Observation: {record['chunk_id']}",'',f"Machine status: `{record['status']}`; semantic judgment: pending human."]
        if record.get('analysis_origin'):lines+=['Analysis origin: '+record['analysis_origin']]
        task=record['reading_task'];lines+=['','**Concrete reading task**',*observation(task),'**Reader before**',task['reader_before'],'','**Reader after**',task['reader_after'],'','**Continuous functional fragments**','']
        for segment in record['segments']:
            lines += ['#### '+segment['segment_id'],'',*quoted([segment['quote']]),'Function:',segment['function'],'','Advances from previous:',segment['advances_from_previous'],'']
        for direction in ('incoming','outgoing'):lines+=['**'+direction+'**',*observation(record['context_links'][direction])]
        if 'context_assertions' in record:
            lines+=context_markdown(record['context_assertions'],4,'SRC / INF / UNK context assertions and prior-reader basis')
        lines+=['**Scientific/source slots to preserve**','']
        for slot in record['scientific_slots']:lines += [slot['kind'],'',*quoted([slot['evidence']]),slot['preserve'],'']
        if not record['scientific_slots']:lines+=['[]','']
        lines+=['**Limitations (stored output)**','',*['- '+v for v in record['limitations']],'','Reason (stored output):',record['reason'],'']
    return lines

def section_markdown(section_observation):
    value=section_observation;lines=['## Whole-section observation','',f"Status: `{value['status']}`; scope: `{value['observation_scope']}`; review status: `{value['review_status']}`; semantic status: `{value.get('semantic_status','pending_human')}`; human approval: pending.",'','### Section task','',*observation(value['section_task']),'### Ordered direct units and child-section placeholders','']
    for item in value['ordered_items']:
        lines += [f"- `{item['item_id']}` — `{item['kind']}` / `{item['status']}`",'',item['reading_task'],'',*quoted(item['evidence'])]
    lines+=['### Section functions and source-specific development','']
    for item in value['observations']:
        lines += ['#### '+item['observation_id'],'','Function:',item['function'],'','Concrete observation:',item['concrete_observation'],'','Source items:','',*['- `'+uid+'`' for uid in item['item_ids']],'',*quoted(item['evidence']),'Applicability:',item['applicability'],'','Limitations:','',*['- '+v for v in item['limitations']],'']
    lines+=['### Every adjacent pair checked','']
    for pair in value['transitions']:
        lines += [f"#### {pair['from_item_id']} → {pair['to_item_id']}",'','Status: `'+pair['status']+'`','',pair['observation'],'',*quoted(pair['evidence'])]
    if 'context_assertions' in value:
        lines+=context_markdown(value['context_assertions'],3,'Section SRC / INF / UNK context assertions')
    lines+=['### Source-specific order variants','']
    for item in value['order_variants']:lines+=observation(item)
    lines+=['### Limitations','',*['- '+v for v in value['limitations']],'','### Unresolved','',*['- '+v for v in value['unresolved']],'']
    return lines


def context_markdown(value,level=3,label='Stored source context'):
    """Render every stored context field readably without inventing a judgment.

    SRC/INF/UNK labels and their complete dependencies stay visible. Unknown
    fields are rendered recursively rather than hidden inside a raw JSON block.
    """
    heading='#'*min(level,6)
    if value is None:return [heading+' '+label,'','Not supplied; no context claim is inferred.','']
    if not isinstance(value,(dict,list)):return [heading+' '+label,'',str(value),'']
    lines=[heading+' '+label,'']
    if isinstance(value,list):
        if not value:return lines+['No stored entries.','']
        for index,item in enumerate(value,1):lines+=context_markdown(item,level+1,f'Entry {index}')
        return lines
    if all(k in value for k in ('unit_instance_id','text','start','end')):
        return lines+quoted([value])
    if 'prose_text' in value:
        # A complete source envelope is prose evidence; raw source remains in the
        # exact JSON snapshot, with both hashes and physical coordinates visible.
        lines+=['```latex',value['prose_text'],'```','']
    for key,item in value.items():
        if key in ('prose_text','text') and 'prose_text' in value:continue
        title=key.replace('_',' ')
        if key=='epistemic_status':
            explanations={'SRC':'Direct source statement; scientific truth is not verified.','INF':'Model interpretation; inspect its SRC dependencies and conditions.','UNK':'Context is insufficient; this does not establish source absence.'}
            lines+=['**Epistemic status: `'+str(item)+'`** — '+explanations.get(item,'Stored status; no additional authority inferred.'),'']
        elif key in ('review_status','semantic_status'):
            lines+=['**'+title+': `'+str(item)+'`**','']
        elif key in ('evidence','condition_evidence') and isinstance(item,list):
            lines+=['**'+title+'**','',*quoted(item)] if item else ['**'+title+'**: none supplied.','']
        elif isinstance(item,(dict,list)):
            lines+=context_markdown(item,level+1,title)
        else:lines+=['**'+title+'**: '+str(item),'']
    return lines
